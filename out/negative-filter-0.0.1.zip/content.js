"use strict";
(() => {
  // extension/content/detect.ts
  var NON_CONTENT_TAGS = /* @__PURE__ */ new Set([
    "HEAD",
    "SCRIPT",
    "STYLE",
    "LINK",
    "META",
    "TITLE",
    "NOSCRIPT",
    "BASE",
    "TEMPLATE"
  ]);
  var MIN_GROUP_SIZE = 3;
  function signatureOf(el) {
    const classes = Array.from(el.classList).sort().join(".");
    return classes ? `${el.tagName}.${classes}` : el.tagName;
  }
  function elementChildren(parent) {
    const out = [];
    for (const child of Array.from(parent.children)) {
      if (NON_CONTENT_TAGS.has(child.tagName)) continue;
      out.push(child);
    }
    return out;
  }
  function evaluateParent(parent) {
    const children = elementChildren(parent);
    if (children.length < MIN_GROUP_SIZE) return null;
    const groups = /* @__PURE__ */ new Map();
    for (const child of children) {
      const sig = signatureOf(child);
      const list = groups.get(sig);
      if (list) list.push(child);
      else groups.set(sig, [child]);
    }
    let best = null;
    for (const [sig, group] of groups) {
      if (group.length < MIN_GROUP_SIZE) continue;
      let total = 0;
      for (const el of group) total += el.getElementsByTagName("*").length;
      const meanDescendants = total / group.length;
      const score = group.length * meanDescendants;
      if (!best || score > best.score) {
        best = { container: parent, group, signature: sig, score };
      }
    }
    return best;
  }
  function classify(container) {
    const style = getComputedStyle(container);
    const display = style.display;
    if (display === "grid" || display === "inline-grid") return "grid";
    if (display === "flex" || display === "inline-flex") {
      const direction = style.flexDirection;
      const horizontal = direction === "row" || direction === "row-reverse";
      const overflowX = style.overflowX;
      const scrolls = overflowX === "auto" || overflowX === "scroll";
      if (horizontal && scrolls) return "carousel";
    }
    return "list";
  }
  function detect(root) {
    const startEl = root instanceof Document ? root.documentElement : root;
    if (!startEl) return null;
    let best = null;
    const stack = [startEl];
    while (stack.length > 0) {
      const node = stack.pop();
      if (NON_CONTENT_TAGS.has(node.tagName)) continue;
      const cand = evaluateParent(node);
      if (cand && (!best || cand.score > best.score)) best = cand;
      for (const child of Array.from(node.children)) {
        if (!NON_CONTENT_TAGS.has(child.tagName)) stack.push(child);
      }
    }
    return best?.container ?? null;
  }

  // extension/content/fingerprint.ts
  var DEPTH = 3;
  var UTILITY_CLASS_PATTERNS = [
    /^css-[a-z0-9]{4,}$/i,
    /^_[a-z0-9_-]{3,}$/i,
    /^[a-z][\w-]*__[a-z0-9]{4,}$/i,
    /^jsx-\d{4,}$/i,
    /^sc-[a-z0-9]{4,}$/i
  ];
  function isUtilityClass(cls) {
    for (const re of UTILITY_CLASS_PATTERNS) {
      if (re.test(cls)) return true;
    }
    return false;
  }
  function nodeShape(el) {
    const classes = Array.from(el.classList).filter((c) => !isUtilityClass(c)).sort().join(".");
    return classes ? `${el.tagName}.${classes}` : el.tagName;
  }
  var NON_CONTENT_TAGS2 = /* @__PURE__ */ new Set([
    "SCRIPT",
    "STYLE",
    "LINK",
    "META",
    "NOSCRIPT",
    "TEMPLATE"
  ]);
  function elementChildren2(parent) {
    const out = [];
    for (const child of Array.from(parent.children)) {
      if (NON_CONTENT_TAGS2.has(child.tagName)) continue;
      out.push(child);
    }
    return out;
  }
  function recursiveShape(el, depth) {
    if (depth === 0) return nodeShape(el);
    const children = elementChildren2(el).map((c) => recursiveShape(c, depth - 1)).sort();
    return children.length === 0 ? nodeShape(el) : `${nodeShape(el)}(${children.join(",")})`;
  }
  function modeOf(xs) {
    if (xs.length === 0) return null;
    const counts = /* @__PURE__ */ new Map();
    for (const x of xs) counts.set(x, (counts.get(x) ?? 0) + 1);
    let best = null;
    const sorted = [...counts.entries()].sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0);
    for (const [value, count] of sorted) {
      if (!best || count > best.count) best = { value, count };
    }
    return best?.value ?? null;
  }
  function fnv1a32(s) {
    let h = 2166136261;
    for (let i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24)) >>> 0;
    }
    return h.toString(16).padStart(8, "0");
  }
  function fingerprintItemSet(itemSet) {
    const children = elementChildren2(itemSet);
    if (children.length === 0) return null;
    const childShapes = children.map((c) => recursiveShape(c, DEPTH));
    const modal = modeOf(childShapes);
    if (modal === null) return null;
    const containerShape = nodeShape(itemSet);
    return fnv1a32(`${containerShape}|${modal}`);
  }

  // extension/background/spend.ts
  var MS_PER_DAY = 24 * 60 * 60 * 1e3;

  // extension/background/llm.ts
  var NON_CONTENT_TAGS3 = /* @__PURE__ */ new Set([
    "SCRIPT",
    "STYLE",
    "LINK",
    "META",
    "NOSCRIPT",
    "TEMPLATE"
  ]);
  var REDACT_ATTRS = [
    "aria-label",
    "alt",
    "title",
    "placeholder",
    "value",
    "name",
    "for",
    "download"
  ];
  var URL_ATTRS = ["href", "src", "srcset", "action", "formaction"];
  var MAX_DEPTH = 8;
  var COLLAPSE_THRESHOLD = 3;
  var REDACTED = "\u2026";
  var INDENT = "  ";
  function shapeOf(el) {
    const classes = Array.from(el.classList).sort().join(".");
    return classes ? `${el.tagName.toLowerCase()}.${classes}` : el.tagName.toLowerCase();
  }
  function elementChildren3(parent) {
    const out = [];
    for (const child of Array.from(parent.children)) {
      if (NON_CONTENT_TAGS3.has(child.tagName)) continue;
      out.push(child);
    }
    return out;
  }
  function hasVisibleText(el) {
    for (const node of Array.from(el.childNodes)) {
      if (node.nodeType === 3 && (node.textContent ?? "").trim() !== "") return true;
    }
    return false;
  }
  function renderAttrs(el, isRoot) {
    const parts = [];
    if (el.classList.length > 0) {
      const sorted = Array.from(el.classList).sort().join(" ");
      parts.push(`class="${sorted}"`);
    }
    const role = el.getAttribute("role");
    if (role) parts.push(`role="${role}"`);
    if (isRoot && el.id) parts.push(`id="${el.id}"`);
    for (const a of REDACT_ATTRS) {
      if (el.hasAttribute(a) && (el.getAttribute(a) ?? "").trim() !== "") {
        parts.push(`${a}="${REDACTED}"`);
      }
    }
    for (const a of URL_ATTRS) {
      if (el.hasAttribute(a)) parts.push(`${a}="#${REDACTED}"`);
    }
    return parts.length ? " " + parts.join(" ") : "";
  }
  function distillNode(el, depth, isRoot) {
    const tag = el.tagName.toLowerCase();
    const attrs = renderAttrs(el, isRoot);
    const indent = INDENT.repeat(depth);
    if (depth >= MAX_DEPTH) {
      return [`${indent}<${tag}${attrs}>${REDACTED}</${tag}>`];
    }
    const children = elementChildren3(el);
    if (children.length === 0) {
      if (hasVisibleText(el)) {
        return [`${indent}<${tag}${attrs}>${REDACTED}</${tag}>`];
      }
      return [`${indent}<${tag}${attrs}/>`];
    }
    const out = [`${indent}<${tag}${attrs}>`];
    let i = 0;
    while (i < children.length) {
      const first = children[i];
      const sig = shapeOf(first);
      let j = i + 1;
      while (j < children.length && shapeOf(children[j]) === sig) j++;
      const runLen = j - i;
      out.push(...distillNode(first, depth + 1, false));
      if (runLen >= COLLAPSE_THRESHOLD) {
        const more = runLen - 1;
        out.push(`${INDENT.repeat(depth + 1)}\u2026 \xD7${more} more <${sig}>`);
      } else {
        for (let k = i + 1; k < j; k++) {
          out.push(...distillNode(children[k], depth + 1, false));
        }
      }
      i = j;
    }
    out.push(`${indent}</${tag}>`);
    return out;
  }
  function distill(root) {
    return distillNode(root, 0, true).join("\n");
  }

  // extension/content/discover.ts
  async function discover(doc, ctx2, opts = {}) {
    const itemSet = detect(doc);
    if (!itemSet) return null;
    const fingerprint = fingerprintItemSet(itemSet);
    if (!fingerprint) return null;
    const layout = classify(itemSet);
    const distilled = distill(itemSet);
    const req = { fingerprint, distilled, layout };
    if (opts.hint !== void 0) req.hint = opts.hint;
    if (opts.force === true) req.force = true;
    const schema = await ctx2.fetchSchema(req);
    return { schema, itemSet };
  }

  // extension/shared/safe-regex.ts
  var UnsafeRegexError = class extends Error {
    reason;
    pattern;
    constructor(reason, pattern) {
      super(`UnsafeRegexError: ${reason}`);
      this.name = "UnsafeRegexError";
      this.reason = reason;
      this.pattern = pattern;
    }
  };
  var MAX_REGEX_LENGTH = 256;
  var NESTED_QUANTIFIER = /\([^)]*[+*][^)]*\)\s*[+*?{]/;
  function safeCompileRegex(pattern, flags) {
    if (pattern.length === 0) {
      throw new UnsafeRegexError("empty pattern", pattern);
    }
    if (pattern.length > MAX_REGEX_LENGTH) {
      throw new UnsafeRegexError(
        `length ${pattern.length} exceeds cap ${MAX_REGEX_LENGTH}`,
        pattern
      );
    }
    if (NESTED_QUANTIFIER.test(pattern)) {
      throw new UnsafeRegexError("nested quantifier (ReDoS risk)", pattern);
    }
    try {
      return new RegExp(pattern, flags);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      throw new UnsafeRegexError(`syntax: ${msg}`, pattern);
    }
  }

  // extension/content/engine.ts
  function readField(item, fieldName, schema) {
    const field = schema.fields[fieldName];
    if (!field) return null;
    const el = item.querySelector(field.selector);
    const text = el?.textContent?.trim();
    return text && text.length > 0 ? text : null;
  }
  function parseFirstNumber(text) {
    const m = text.match(/-?\d+(?:\.\d+)?/);
    if (!m) return null;
    const n = parseFloat(m[0]);
    return Number.isFinite(n) ? n : null;
  }
  function evalPredicate(text, pred) {
    switch (pred.op) {
      case "containsAny": {
        const haystack = text.toLowerCase();
        for (const phrase of pred.phrases) {
          if (phrase.length === 0) continue;
          if (haystack.includes(phrase.toLowerCase())) {
            return { matched: true, trigger: phrase };
          }
        }
        return { matched: false };
      }
      case "regex": {
        const re = safeCompileRegex(pred.pattern, pred.flags);
        const match = re.exec(text);
        return match ? { matched: true, trigger: match[0] } : { matched: false };
      }
      case "lessThan": {
        const n = parseFirstNumber(text);
        return n !== null && n < pred.value ? { matched: true, trigger: `${n} < ${pred.value}` } : { matched: false };
      }
      case "greaterThan": {
        const n = parseFirstNumber(text);
        return n !== null && n > pred.value ? { matched: true, trigger: `${n} > ${pred.value}` } : { matched: false };
      }
      case "equals": {
        const target = typeof pred.value === "string" ? pred.value : String(pred.value);
        return text === target ? { matched: true, trigger: target } : { matched: false };
      }
      case "oneOf": {
        for (const v of pred.values) {
          const target = typeof v === "string" ? v : String(v);
          if (text === target) return { matched: true, trigger: target };
        }
        return { matched: false };
      }
    }
  }
  function evaluate(schema, items, filters) {
    const out = /* @__PURE__ */ new Map();
    const applicable = filters.filter((f) => f.fingerprint === schema.fingerprint);
    for (const item of items) {
      let verdict = { state: "passing" };
      for (const filter of applicable) {
        const text = readField(item, filter.field, schema);
        if (text === null) continue;
        const outcome = evalPredicate(text, filter.predicate);
        const excludes = filter.polarity === "exclude" && outcome.matched || filter.polarity === "keep" && !outcome.matched;
        if (excludes) {
          verdict = {
            state: "filtered",
            reason: outcome.trigger ?? filter.predicate.op
          };
          break;
        }
      }
      out.set(item, verdict);
    }
    return out;
  }
  function findItems(schema, doc = document) {
    return Array.from(doc.querySelectorAll(schema.itemSelector));
  }

  // extension/content/mutations.ts
  var MutationWatcher = class {
    constructor(opts) {
      this.opts = opts;
    }
    observer = null;
    pending = /* @__PURE__ */ new Set();
    flushScheduled = false;
    start() {
      if (this.observer) return;
      this.observer = new MutationObserver((mutations) => {
        this.queue(mutations);
      });
      this.observer.observe(this.opts.itemSet, { childList: true });
    }
    stop() {
      this.observer?.disconnect();
      this.observer = null;
      this.pending.clear();
      this.flushScheduled = false;
    }
    queue(mutations) {
      for (const m of mutations) {
        for (const node of m.addedNodes) {
          if (!(node instanceof Element)) continue;
          if (this.matchesItem(node)) this.pending.add(node);
        }
      }
      if (this.pending.size === 0) return;
      if (this.flushScheduled) return;
      this.flushScheduled = true;
      queueMicrotask(() => this.flush());
    }
    matchesItem(el) {
      try {
        return el.matches(this.opts.itemSelector);
      } catch {
        return false;
      }
    }
    flush() {
      this.flushScheduled = false;
      if (this.pending.size === 0) return;
      const added = Array.from(this.pending);
      this.pending.clear();
      this.opts.onItemsAdded(added);
    }
  };

  // extension/content/renderer.ts
  var STYLE_EL_ID = "nf-injected-styles";
  var STYLES = `
.filt > .nf-card-hidden { display: none; }
.filt > .sliver {
  display: block;
  height: 28px;
  line-height: 28px;
  padding: 0 10px;
  font: 12px/28px system-ui, -apple-system, Segoe UI, sans-serif;
  color: #57606a;
  background: #f6f8fa;
  border: 1px solid #d0d7de;
  border-radius: 6px;
  cursor: pointer;
  user-select: none;
  text-align: left;
  width: 100%;
  box-sizing: border-box;
}
.filt > .sliver:hover { background: #eaeef2; }
.filt.restored > .sliver { display: none; }
.filt.restored > .nf-card-hidden { display: block; }
.filt > .rehide { display: none; }
.filt.restored > .rehide {
  display: inline-block;
  margin-top: 4px;
  padding: 2px 8px;
  font: 11px/1 system-ui, -apple-system, Segoe UI, sans-serif;
  color: #57606a;
  background: transparent;
  border: 1px solid #d0d7de;
  border-radius: 4px;
  cursor: pointer;
}
.mode-hide > .filt:not(.restored) { display: none; }
/* Carousel layout (Slice 2.5): a narrow vertical sliver replaces the card
   width-wise so the horizontal track keeps the same flex shape; reason
   text is rotated to read top-to-bottom. */
.filt.layout-carousel {
  flex: 0 0 46px;
  width: 46px;
  min-width: 46px;
  align-self: stretch;
}
.filt.layout-carousel > .sliver-v {
  display: block;
  width: 100%;
  min-height: 120px;
  height: 100%;
  padding: 8px 6px;
  font: 12px/1.2 system-ui, -apple-system, Segoe UI, sans-serif;
  color: #57606a;
  background: #f6f8fa;
  border: 1px solid #d0d7de;
  border-radius: 6px;
  cursor: pointer;
  user-select: none;
  box-sizing: border-box;
  writing-mode: vertical-rl;
  text-align: left;
  overflow: hidden;
}
.filt.layout-carousel > .sliver-v:hover { background: #eaeef2; }
.filt.layout-carousel.restored > .sliver-v { display: none; }
/* Grid layout (Slice 2.6): wrapper still occupies exactly one grid cell so
   the column count and row pack stay stable; a .ctile placeholder fills
   the cell footprint and signals "hidden item." No flex sizing \u2014 the host
   grid template already gives the wrapper the right cell. */
.filt.layout-grid > .ctile {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 60px;
  height: 100%;
  width: 100%;
  padding: 12px;
  font: 12px/1.3 system-ui, -apple-system, Segoe UI, sans-serif;
  color: #57606a;
  background: #f6f8fa;
  border: 1px dashed #d0d7de;
  border-radius: 8px;
  cursor: pointer;
  user-select: none;
  text-align: center;
  box-sizing: border-box;
}
.filt.layout-grid > .ctile:hover { background: #eaeef2; }
.filt.layout-grid.restored > .ctile { display: none; }
/* Checking state (Slice 5.7): items mid-deep-scan get a small inline
   spinner. We add an absolutely-positioned indicator element rather
   than restyling the card so the passing-card outerHTML still snaps
   back to identical when the spinner is removed. */
.nf-check-mark {
  display: inline-block;
  margin-left: 6px;
  padding: 1px 6px;
  font: 11px/1.2 system-ui, -apple-system, Segoe UI, sans-serif;
  color: #57606a;
  background: #f6f8fa;
  border: 1px solid #d0d7de;
  border-radius: 4px;
  vertical-align: middle;
}
`;
  function injectStyles(doc) {
    if (doc.getElementById(STYLE_EL_ID)) return;
    const style = doc.createElement("style");
    style.id = STYLE_EL_ID;
    style.textContent = STYLES;
    doc.head.appendChild(style);
  }
  var Renderer = class {
    opts;
    idByItem = /* @__PURE__ */ new WeakMap();
    /** Per-item .filt wrapper — present iff the item is currently filtered. */
    wrapperByItem = /* @__PURE__ */ new WeakMap();
    /** Reverse lookup so click handlers (1.5) can resolve id → item. */
    itemById = /* @__PURE__ */ new Map();
    restored = /* @__PURE__ */ new Set();
    /** Slice 5.7: items currently in the "checking" state (deep scan in
     *  flight). Cleared once the engine apply() resolves them. */
    checking = /* @__PURE__ */ new Set();
    /** Spinner element per checking item — held so we can remove it
     *  cleanly without re-querying. */
    checkMarkById = /* @__PURE__ */ new Map();
    nextId = 0;
    lastSummaries = [];
    constructor(opts) {
      const doc = opts.doc ?? opts.itemSet.ownerDocument ?? document;
      this.opts = {
        schema: opts.schema,
        itemSet: opts.itemSet,
        doc,
        onRestoreToggle: opts.onRestoreToggle
      };
      injectStyles(doc);
    }
    /** Apply a fresh set of verdicts. Idempotent — re-applying with the same
     *  inputs is a DOM no-op. Returns one summary per item, in input order. */
    apply(verdicts) {
      const summaries = [];
      for (const [item, verdict] of verdicts) {
        this.handleRecycledItem(item);
        const id = this.ensureId(item);
        const label = this.readLabel(item);
        const wasFiltered = this.wrapperByItem.has(item);
        if (verdict.state === "filtered") {
          if (!wasFiltered) {
            this.wrap(item, verdict, id);
          } else {
            this.refreshSliver(item, verdict);
          }
        } else if (verdict.state === "passing") {
          if (wasFiltered) {
            this.unwrap(item, id);
          }
        }
        if (this.checking.has(id) && verdict.state !== "checking") {
          this.checking.delete(id);
          this.removeCheckMark(id);
        }
        const reportedState = verdict.state === "filtered" && this.restored.has(id) ? "restored" : verdict.state;
        const summary = { id, state: reportedState };
        if (verdict.reason !== void 0) summary.reason = verdict.reason;
        if (label !== void 0) summary.label = label;
        summaries.push(summary);
      }
      this.lastSummaries = summaries;
      return summaries;
    }
    /** Flip a single item's restored flag. Reflected in the DOM (the wrapper
     *  gets `.restored`) and in subsequent summaries. */
    setRestored(itemId, restored) {
      const item = this.itemById.get(itemId);
      if (!item) return;
      const wrapper = this.wrapperByItem.get(item);
      if (!wrapper) return;
      if (restored) {
        this.restored.add(itemId);
        wrapper.classList.add("restored");
      } else {
        this.restored.delete(itemId);
        wrapper.classList.remove("restored");
      }
      const summary = this.lastSummaries.find((s) => s.id === itemId);
      if (summary) summary.state = restored ? "restored" : "filtered";
    }
    /** Slice 5.7: mark an item as actively being deep-scanned. The
     *  renderer adds a small spinner indicator next to it; once the
     *  engine produces a `filtered` or `passing` verdict (next apply
     *  call), the spinner is removed and the verdict takes effect. */
    setChecking(itemId, on) {
      const item = this.itemById.get(itemId);
      if (!item) return;
      if (on) {
        if (this.checking.has(itemId)) return;
        this.checking.add(itemId);
        const mark = this.opts.doc.createElement("span");
        mark.className = "nf-check-mark";
        mark.dataset["nfId"] = itemId;
        mark.textContent = "\u23F3 checking\u2026";
        item.appendChild(mark);
        this.checkMarkById.set(itemId, mark);
        const summary = this.lastSummaries.find((s) => s.id === itemId);
        if (summary) summary.state = "checking";
      } else {
        this.checking.delete(itemId);
        this.removeCheckMark(itemId);
      }
    }
    /** Toggle the display mode on the item-set container. Slice 1.8 gate. */
    setMode(mode) {
      if (mode === "hide") this.opts.itemSet.classList.add("mode-hide");
      else this.opts.itemSet.classList.remove("mode-hide");
    }
    /** Latest summaries (state + label + reason) for every item the engine
     *  has evaluated. Survives between renderer.apply() calls. */
    summaries() {
      return this.lastSummaries;
    }
    // -------------------------------------------------------------------------
    // Internals
    // -------------------------------------------------------------------------
    ensureId(item) {
      let id = this.idByItem.get(item);
      if (id !== void 0) return id;
      const dataId = item.getAttribute("data-id");
      id = dataId && dataId.length > 0 ? dataId : `nf-${++this.nextId}`;
      this.idByItem.set(item, id);
      this.itemById.set(id, item);
      return id;
    }
    /** 6.1: identity-by-content for virtualized lists. The cached id
     *  for an element is stable as long as the element's data-id (or
     *  fallback synthetic id) stays the same. When a virtualizer
     *  recycles the element with a different data-id, we treat it as
     *  a new item — unwrap the old `.filt` wrapper (if any), drop the
     *  restored/checking flags scoped to the previous id, and clear
     *  the cache entry so ensureId() can re-mint. */
    handleRecycledItem(item) {
      const cached = this.idByItem.get(item);
      if (cached === void 0) return;
      const current = this.currentIdentityKey(item);
      if (current === null) return;
      if (cached === current) return;
      if (this.wrapperByItem.has(item)) this.unwrap(item, cached);
      this.restored.delete(cached);
      if (this.checking.has(cached)) {
        this.checking.delete(cached);
        this.removeCheckMark(cached);
      }
      this.itemById.delete(cached);
      this.idByItem.delete(item);
    }
    currentIdentityKey(item) {
      const dataId = item.getAttribute("data-id");
      return dataId && dataId.length > 0 ? dataId : null;
    }
    readLabel(item) {
      const fields = this.opts.schema.fields;
      const candidates = ["title", ...Object.keys(fields)];
      for (const name of candidates) {
        const f = fields[name];
        if (!f || f.kind !== "text") continue;
        const el = item.querySelector(f.selector);
        const text = el?.textContent?.trim();
        if (text && text.length > 0) return text;
      }
      return void 0;
    }
    wrap(item, verdict, id) {
      const doc = this.opts.doc;
      const layout = this.opts.schema.layout;
      const wrapper = doc.createElement("div");
      wrapper.className = layout === "carousel" ? "filt layout-carousel" : layout === "grid" ? "filt layout-grid" : "filt";
      wrapper.dataset["nfId"] = id;
      const sliver = doc.createElement("button");
      sliver.type = "button";
      sliver.className = layout === "carousel" ? "sliver-v" : layout === "grid" ? "ctile" : "sliver";
      sliver.dataset["nfId"] = id;
      sliver.setAttribute("aria-label", `Restore hidden item: ${this.readLabel(item) ?? id}`);
      sliver.textContent = this.sliverText(verdict);
      sliver.addEventListener("click", () => this.opts.onRestoreToggle?.(id, true));
      const rehide = doc.createElement("button");
      rehide.type = "button";
      rehide.className = "rehide";
      rehide.dataset["nfId"] = id;
      rehide.setAttribute("aria-label", `Re-hide ${this.readLabel(item) ?? id}`);
      rehide.textContent = "\u21BA re-hide";
      rehide.addEventListener("click", () => this.opts.onRestoreToggle?.(id, false));
      item.classList.add("nf-card-hidden");
      item.replaceWith(wrapper);
      wrapper.appendChild(item);
      wrapper.appendChild(sliver);
      wrapper.appendChild(rehide);
      this.wrapperByItem.set(item, wrapper);
      if (this.restored.has(id)) wrapper.classList.add("restored");
    }
    refreshSliver(item, verdict) {
      const wrapper = this.wrapperByItem.get(item);
      if (!wrapper) return;
      const sliver = wrapper.querySelector(".sliver, .sliver-v, .ctile");
      if (sliver) sliver.textContent = this.sliverText(verdict);
    }
    unwrap(item, id) {
      const wrapper = this.wrapperByItem.get(item);
      if (!wrapper) return;
      item.classList.remove("nf-card-hidden");
      wrapper.replaceWith(item);
      this.wrapperByItem.delete(item);
      this.restored.delete(id);
    }
    sliverText(verdict) {
      return verdict.reason ? `Hidden \u2014 ${verdict.reason}` : "Hidden";
    }
    removeCheckMark(itemId) {
      const mark = this.checkMarkById.get(itemId);
      if (!mark) return;
      mark.remove();
      this.checkMarkById.delete(itemId);
    }
  };

  // extension/content/schema-stub.ts
  var ROLECAST_STUB_SCHEMA = {
    fingerprint: "fixture:rolecast:v1",
    layout: "list",
    itemSetSelector: ".joblist",
    itemSelector: ".joblist > .job",
    fields: {
      title: { kind: "text", selector: ".title" },
      company: { kind: "text", selector: ".company" },
      location: { kind: "text", selector: ".location" },
      snippet: { kind: "text", selector: ".snippet" },
      // 4.4 needs a number field for the slider editor; engine's
      // parseFirstNumber reads "$180k–$220k" → 180 (lower-bound semantics).
      comp: { kind: "number", selector: ".comp" }
    },
    source: "stub",
    discoveredAt: 0
  };
  var ALL_STUBS = [ROLECAST_STUB_SCHEMA];
  function pickStubSchema(doc = document) {
    for (const schema of ALL_STUBS) {
      if (doc.querySelector(schema.itemSetSelector)) return schema;
    }
    return null;
  }

  // extension/shared/saved-filters.ts
  var KEY_PREFIX = "nf:filters:";
  function keyFor(fingerprint) {
    return KEY_PREFIX + fingerprint;
  }
  function isFilterShape(x) {
    if (typeof x !== "object" || x === null) return false;
    const r = x;
    if (typeof r["id"] !== "string") return false;
    if (typeof r["fingerprint"] !== "string") return false;
    if (r["polarity"] !== "exclude" && r["polarity"] !== "keep") return false;
    if (typeof r["field"] !== "string") return false;
    if (typeof r["predicate"] !== "object" || r["predicate"] === null) return false;
    if (typeof r["deep"] !== "boolean") return false;
    if (typeof r["saved"] !== "boolean") return false;
    return true;
  }
  async function loadSavedFilters(fingerprint) {
    const key = keyFor(fingerprint);
    const r = await chrome.storage.sync.get(key);
    const raw = r[key];
    if (!Array.isArray(raw)) return [];
    return raw.filter(isFilterShape);
  }

  // extension/shared/types.ts
  var MESSAGE_VERSION = 1;
  function hasShape(x) {
    return typeof x === "object" && x !== null && "t" in x && "v" in x;
  }
  function hasStringField(x, key) {
    return key in x && typeof x[key] === "string";
  }
  function isSwToPanel(x) {
    if (!hasShape(x)) return false;
    if (x.v !== MESSAGE_VERSION) return false;
    const r = x;
    switch (x.t) {
      case "pong":
      case "ack":
        return true;
      case "err":
        return hasStringField(x, "message");
      case "schema":
        return typeof r["schema"] === "object" && r["schema"] !== null;
      default:
        return false;
    }
  }
  function isPanelToContent(x) {
    if (!hasShape(x)) return false;
    if (x.v !== MESSAGE_VERSION) return false;
    const r = x;
    switch (x.t) {
      case "getState":
        return true;
      case "setFilters":
        return Array.isArray(r["filters"]);
      case "setDisplayMode":
        return r["mode"] === "collapse" || r["mode"] === "hide";
      case "setItemRestored":
        return hasStringField(x, "itemId") && typeof r["restored"] === "boolean";
      case "rediscover":
        return true;
      default:
        return false;
    }
  }
  async function sendToSw(msg) {
    const reply = await chrome.runtime.sendMessage(msg);
    if (!isSwToPanel(reply)) {
      throw new Error(`SW returned malformed reply: ${JSON.stringify(reply)}`);
    }
    return reply;
  }
  function pushToPanel(msg) {
    void chrome.runtime.sendMessage(msg).catch(() => void 0);
  }

  // extension/content/index.ts
  var LOG_PREFIX = "[negative-filter]";
  var ctx = null;
  async function hydrateSavedFilters(c) {
    try {
      const saved = await loadSavedFilters(c.schema.fingerprint);
      if (saved.length === 0) return;
      c.filters = saved;
      recompute(c);
      pushToPanel({
        t: "pageDetected",
        v: MESSAGE_VERSION,
        layout: c.schema.layout,
        count: c.summaries.length,
        fingerprint: c.schema.fingerprint
      });
    } catch (err) {
      console.error("[negative-filter] loadSavedFilters failed:", err);
    }
  }
  function recompute(c) {
    const verdicts = evaluate(c.schema, c.items, c.filters);
    c.summaries = c.renderer.apply(verdicts);
    pushToPanel({ t: "itemStates", v: MESSAGE_VERSION, items: c.summaries });
  }
  function emitItemStates(c) {
    c.summaries = c.renderer.summaries();
    pushToPanel({ t: "itemStates", v: MESSAGE_VERSION, items: c.summaries });
  }
  function handlePanelMessage(msg) {
    if (!ctx) {
      if (msg.t === "getState") {
        const empty = { schema: null, filters: [], mode: "collapse", items: [] };
        return { t: "state", v: MESSAGE_VERSION, state: empty };
      }
      if (msg.t === "rediscover") {
        void tryDiscover({
          ...msg.hint !== void 0 ? { hint: msg.hint } : {},
          force: true
        });
        return { t: "ack", v: MESSAGE_VERSION };
      }
      return { t: "err", v: MESSAGE_VERSION, message: "no schema for this page" };
    }
    switch (msg.t) {
      case "getState": {
        const state = {
          schema: ctx.schema,
          filters: ctx.filters,
          mode: ctx.mode,
          items: ctx.summaries
        };
        return { t: "state", v: MESSAGE_VERSION, state };
      }
      case "setFilters":
        ctx.filters = msg.filters;
        recompute(ctx);
        return { t: "ack", v: MESSAGE_VERSION };
      case "setDisplayMode":
        ctx.mode = msg.mode;
        ctx.renderer.setMode(msg.mode);
        return { t: "ack", v: MESSAGE_VERSION };
      case "setItemRestored":
        ctx.renderer.setRestored(msg.itemId, msg.restored);
        emitItemStates(ctx);
        return { t: "ack", v: MESSAGE_VERSION };
      case "rediscover":
        void tryDiscover({
          ...msg.hint !== void 0 ? { hint: msg.hint } : {},
          ...msg.force === true ? { force: true } : {}
        });
        return { t: "ack", v: MESSAGE_VERSION };
    }
  }
  function attachMessageBridge() {
    chrome.runtime.onMessage.addListener((raw, _sender, sendResponse) => {
      if (!isPanelToContent(raw)) return false;
      sendResponse(handlePanelMessage(raw));
      return false;
    });
  }
  async function roundTripPing() {
    try {
      const reply = await sendToSw({ t: "ping", v: MESSAGE_VERSION });
      console.log(`${LOG_PREFIX} SW round-trip:`, reply);
    } catch (err) {
      console.error(`${LOG_PREFIX} SW round-trip failed:`, err);
    }
  }
  function mount(schema, itemSet) {
    if (ctx) {
      ctx.watcher?.stop();
      ctx = null;
    }
    const renderer = new Renderer({
      schema,
      itemSet,
      onRestoreToggle: (id, restored) => {
        renderer.setRestored(id, restored);
        if (ctx) emitItemStates(ctx);
      }
    });
    ctx = {
      schema,
      itemSet,
      renderer,
      items: findItems(schema),
      filters: [],
      mode: "collapse",
      summaries: [],
      watcher: null
    };
    recompute(ctx);
    pushToPanel({
      t: "pageDetected",
      v: MESSAGE_VERSION,
      layout: schema.layout,
      count: ctx.summaries.length,
      fingerprint: schema.fingerprint
    });
    ctx.watcher = new MutationWatcher({
      itemSet,
      itemSelector: schema.itemSelector,
      onItemsAdded: (added) => {
        if (!ctx) return;
        ctx.items = [...ctx.items, ...added];
        recompute(ctx);
      }
    });
    ctx.watcher.start();
    void hydrateSavedFilters(ctx);
  }
  async function fetchSchemaViaSw(req) {
    const msg = {
      t: "discoverSchema",
      v: MESSAGE_VERSION,
      fingerprint: req.fingerprint,
      distilled: req.distilled,
      layout: req.layout
    };
    if (req.hint !== void 0) msg.hint = req.hint;
    if (req.force === true) msg.force = true;
    const reply = await sendToSw(msg);
    if (reply.t === "schema") return reply.schema;
    if (reply.t === "err") throw new Error(reply.message);
    throw new Error(`unexpected SW reply: ${reply.t}`);
  }
  var discoverState = {
    inFlight: false,
    succeeded: false,
    mutationObserver: null,
    giveUpTimer: null
  };
  async function attemptDiscover(opts) {
    const discoverOpts = {};
    if (opts.hint !== void 0) discoverOpts.hint = opts.hint;
    if (opts.force === true) discoverOpts.force = true;
    const result = await discover(
      document,
      { fetchSchema: (r) => fetchSchemaViaSw(r) },
      discoverOpts
    );
    if (!result) return false;
    mount(result.schema, result.itemSet);
    return true;
  }
  async function tryDiscover(opts = {}) {
    if (opts.force === true) {
      teardownDiscoverWatcher();
      discoverState.succeeded = false;
      discoverState.inFlight = false;
    }
    if (discoverState.inFlight || discoverState.succeeded) return;
    discoverState.inFlight = true;
    const delays = [0, 1e3, 3e3];
    try {
      for (const wait of delays) {
        if (wait > 0) await new Promise((r) => setTimeout(r, wait));
        try {
          if (await attemptDiscover(opts)) {
            discoverState.succeeded = true;
            return;
          }
        } catch (err) {
          emitDiscoverError(err);
          return;
        }
      }
      installDiscoverWatcher(opts);
    } finally {
      discoverState.inFlight = false;
    }
  }
  function emitDiscoverError(err) {
    const message = err instanceof Error ? err.message : String(err);
    console.error(`${LOG_PREFIX} discover failed:`, message);
    pushToPanel({
      t: "discoverError",
      v: MESSAGE_VERSION,
      message
    });
  }
  var GIVE_UP_MS = 6e4;
  var MIN_MUTATION_RETRY_INTERVAL_MS = 750;
  function installDiscoverWatcher(opts) {
    if (discoverState.mutationObserver) return;
    let lastAttemptAt = 0;
    let retryQueued = false;
    const attempt = async () => {
      if (discoverState.succeeded) return;
      if (Date.now() - lastAttemptAt < MIN_MUTATION_RETRY_INTERVAL_MS) {
        if (retryQueued) return;
        retryQueued = true;
        setTimeout(() => {
          retryQueued = false;
          void attempt();
        }, MIN_MUTATION_RETRY_INTERVAL_MS);
        return;
      }
      lastAttemptAt = Date.now();
      try {
        if (await attemptDiscover(opts)) {
          discoverState.succeeded = true;
          teardownDiscoverWatcher();
        }
      } catch (err) {
        emitDiscoverError(err);
        teardownDiscoverWatcher();
      }
    };
    const observer = new MutationObserver((records) => {
      for (const r of records) {
        if (r.addedNodes.length > 0) {
          void attempt();
          return;
        }
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
    discoverState.mutationObserver = observer;
    discoverState.giveUpTimer = setTimeout(() => {
      if (!discoverState.succeeded) {
        pushToPanel({
          t: "discoverError",
          v: MESSAGE_VERSION,
          message: "no item-set detected after 60s \u2014 try Re-discover with a one-line hint about which list to filter."
        });
      }
      teardownDiscoverWatcher();
    }, GIVE_UP_MS);
  }
  function teardownDiscoverWatcher() {
    discoverState.mutationObserver?.disconnect();
    discoverState.mutationObserver = null;
    if (discoverState.giveUpTimer !== null) {
      clearTimeout(discoverState.giveUpTimer);
      discoverState.giveUpTimer = null;
    }
  }
  function init() {
    attachMessageBridge();
    const schema = pickStubSchema();
    if (schema) {
      const itemSet = document.querySelector(schema.itemSetSelector);
      if (itemSet) mount(schema, itemSet);
    } else {
      void tryDiscover();
    }
    void roundTripPing();
  }
  init();
})();
//# sourceMappingURL=content.js.map
