"use strict";
(() => {
  // extension/background/spend.ts
  var DEFAULT_CAPS = { daily: 50, monthly: 1e3 };
  var MS_PER_DAY = 24 * 60 * 60 * 1e3;
  function epochDay(now) {
    return Math.floor(now / MS_PER_DAY);
  }
  function epochMonth(now) {
    const d = new Date(now);
    return d.getUTCFullYear() * 12 + d.getUTCMonth();
  }
  function rollLedger(ledger, now) {
    const d = epochDay(now);
    const m = epochMonth(now);
    let next = ledger;
    if (d !== ledger.dailyEpoch) {
      next = { ...next, dailyEpoch: d, dailyCount: 0 };
    }
    if (m !== ledger.monthlyEpoch) {
      next = { ...next, monthlyEpoch: m, monthlyCount: 0 };
    }
    return next;
  }
  function checkLedger(ledger, caps, now) {
    const rolled = rollLedger(ledger, now);
    if (rolled.dailyCount >= caps.daily) {
      return { ok: false, reason: "spend-cap-reached", period: "day" };
    }
    if (rolled.monthlyCount >= caps.monthly) {
      return { ok: false, reason: "spend-cap-reached", period: "month" };
    }
    return { ok: true };
  }
  function incrementLedger(ledger, now) {
    const rolled = rollLedger(ledger, now);
    return {
      ...rolled,
      dailyCount: rolled.dailyCount + 1,
      monthlyCount: rolled.monthlyCount + 1
    };
  }
  function memorySpendChecker(initial, caps = DEFAULT_CAPS) {
    let ledger = initial;
    return {
      async canSpend(now) {
        return checkLedger(ledger, caps, now);
      },
      async recordSpend(now) {
        ledger = incrementLedger(ledger, now);
      }
    };
  }
  var SpendCapError = class extends Error {
    reason = "spend-cap-reached";
    period;
    constructor(period) {
      super(`spend-cap-reached:${period}`);
      this.name = "SpendCapError";
      this.period = period;
    }
  };

  // extension/background/llm.ts
  var NON_CONTENT_TAGS = /* @__PURE__ */ new Set([
    "SCRIPT",
    "STYLE",
    "LINK",
    "META",
    "NOSCRIPT",
    "TEMPLATE"
  ]);
  var REDACT_ATTRS = [
    "aria-label",
    "alt",
    "title",
    "placeholder",
    "value",
    "name",
    "for",
    "download"
  ];
  var URL_ATTRS = ["href", "src", "srcset", "action", "formaction"];
  var MAX_DEPTH = 8;
  var COLLAPSE_THRESHOLD = 3;
  var REDACTED = "\u2026";
  var INDENT = "  ";
  function shapeOf(el) {
    const classes = Array.from(el.classList).sort().join(".");
    return classes ? `${el.tagName.toLowerCase()}.${classes}` : el.tagName.toLowerCase();
  }
  function elementChildren(parent) {
    const out = [];
    for (const child of Array.from(parent.children)) {
      if (NON_CONTENT_TAGS.has(child.tagName)) continue;
      out.push(child);
    }
    return out;
  }
  function hasVisibleText(el) {
    for (const node of Array.from(el.childNodes)) {
      if (node.nodeType === 3 && (node.textContent ?? "").trim() !== "") return true;
    }
    return false;
  }
  function renderAttrs(el, isRoot) {
    const parts = [];
    if (el.classList.length > 0) {
      const sorted = Array.from(el.classList).sort().join(" ");
      parts.push(`class="${sorted}"`);
    }
    const role = el.getAttribute("role");
    if (role) parts.push(`role="${role}"`);
    if (isRoot && el.id) parts.push(`id="${el.id}"`);
    for (const a of REDACT_ATTRS) {
      if (el.hasAttribute(a) && (el.getAttribute(a) ?? "").trim() !== "") {
        parts.push(`${a}="${REDACTED}"`);
      }
    }
    for (const a of URL_ATTRS) {
      if (el.hasAttribute(a)) parts.push(`${a}="#${REDACTED}"`);
    }
    return parts.length ? " " + parts.join(" ") : "";
  }
  function distillNode(el, depth, isRoot) {
    const tag = el.tagName.toLowerCase();
    const attrs = renderAttrs(el, isRoot);
    const indent = INDENT.repeat(depth);
    if (depth >= MAX_DEPTH) {
      return [`${indent}<${tag}${attrs}>${REDACTED}</${tag}>`];
    }
    const children = elementChildren(el);
    if (children.length === 0) {
      if (hasVisibleText(el)) {
        return [`${indent}<${tag}${attrs}>${REDACTED}</${tag}>`];
      }
      return [`${indent}<${tag}${attrs}/>`];
    }
    const out = [`${indent}<${tag}${attrs}>`];
    let i = 0;
    while (i < children.length) {
      const first = children[i];
      const sig = shapeOf(first);
      let j = i + 1;
      while (j < children.length && shapeOf(children[j]) === sig) j++;
      const runLen = j - i;
      out.push(...distillNode(first, depth + 1, false));
      if (runLen >= COLLAPSE_THRESHOLD) {
        const more = runLen - 1;
        out.push(`${INDENT.repeat(depth + 1)}\u2026 \xD7${more} more <${sig}>`);
      } else {
        for (let k = i + 1; k < j; k++) {
          out.push(...distillNode(children[k], depth + 1, false));
        }
      }
      i = j;
    }
    out.push(`${indent}</${tag}>`);
    return out;
  }
  function distill(root) {
    return distillNode(root, 0, true).join("\n");
  }
  var SchemaParseError = class extends Error {
    reason;
    raw;
    constructor(reason, raw) {
      super(`SchemaParseError: ${reason}`);
      this.name = "SchemaParseError";
      this.reason = reason;
      this.raw = raw === void 0 ? void 0 : raw.slice(0, 500);
    }
  };
  var DEFAULT_MODEL = {
    anthropic: "claude-sonnet-4-5",
    openai: "gpt-4o"
  };
  var VALID_LAYOUTS = /* @__PURE__ */ new Set(["list", "carousel", "grid"]);
  var VALID_FIELD_KINDS = /* @__PURE__ */ new Set([
    "text",
    "number",
    "date",
    "enum",
    "flag"
  ]);
  function buildPrompt(distilled, hint) {
    const hintLine = hint && hint.trim() !== "" ? `
User hint: ${hint.trim()}
` : "";
    return `You are inspecting the structure of a web page to write CSS selectors that pick out a list of similar items.

Output ONLY a single JSON object \u2014 no prose, no markdown fences \u2014 matching this shape exactly:

{
  "layout": "list" | "carousel" | "grid",
  "itemSetSelector": <CSS selector for the outer container>,
  "itemSelector": <CSS selector for one repeating item within the container>,
  "fields": {
    "<fieldName>": { "kind": "text"|"number"|"date"|"enum"|"flag", "selector": <CSS selector inside one item> }
  },
  "detailLinkSelector"?: <CSS selector for the anchor \u2192 detail page>,
  "detailFieldSelectors"?: { "<fieldName>": <CSS selector on the detail page> }
}

The skeleton below has had text content redacted (\`\u2026\`) and per-item attributes (data-*, ids, styles) stripped. Class names and structure are intact \u2014 base your selectors on those.

Skeleton:
${distilled}
${hintLine}`;
  }
  function extractJsonObject(text) {
    const trimmed = text.trim();
    const fence = trimmed.match(/^```(?:json)?\s*([\s\S]*?)\s*```\s*$/);
    if (fence?.[1]) return fence[1].trim();
    const first = trimmed.indexOf("{");
    const last = trimmed.lastIndexOf("}");
    if (first >= 0 && last > first) return trimmed.slice(first, last + 1);
    return trimmed;
  }
  function isNonEmptyString(x) {
    return typeof x === "string" && x.trim() !== "";
  }
  function isFieldSpec(x) {
    if (typeof x !== "object" || x === null) return false;
    const r = x;
    if (!isNonEmptyString(r["selector"])) return false;
    if (typeof r["kind"] !== "string" || !VALID_FIELD_KINDS.has(r["kind"])) {
      return false;
    }
    if ("deep" in r && r["deep"] !== void 0 && typeof r["deep"] !== "boolean") {
      return false;
    }
    return true;
  }
  function isStringRecord(x) {
    if (typeof x !== "object" || x === null) return false;
    for (const v of Object.values(x)) {
      if (typeof v !== "string") return false;
    }
    return true;
  }
  function validateSchemaShape(obj, fingerprint, now, raw) {
    if (typeof obj !== "object" || obj === null) {
      throw new SchemaParseError("response is not a JSON object", raw);
    }
    const r = obj;
    if (typeof r["layout"] !== "string" || !VALID_LAYOUTS.has(r["layout"])) {
      throw new SchemaParseError(`invalid layout: ${JSON.stringify(r["layout"])}`, raw);
    }
    if (!isNonEmptyString(r["itemSetSelector"])) {
      throw new SchemaParseError("itemSetSelector missing or empty", raw);
    }
    if (!isNonEmptyString(r["itemSelector"])) {
      throw new SchemaParseError("itemSelector missing or empty", raw);
    }
    if (typeof r["fields"] !== "object" || r["fields"] === null) {
      throw new SchemaParseError("fields missing or not an object", raw);
    }
    const fields = {};
    for (const [name, spec] of Object.entries(r["fields"])) {
      if (!isFieldSpec(spec)) {
        throw new SchemaParseError(`field "${name}" has invalid FieldSpec`, raw);
      }
      fields[name] = spec;
    }
    if (Object.keys(fields).length === 0) {
      throw new SchemaParseError("fields object is empty", raw);
    }
    const schema = {
      fingerprint,
      layout: r["layout"],
      itemSetSelector: r["itemSetSelector"],
      itemSelector: r["itemSelector"],
      fields,
      source: "llm",
      discoveredAt: now
    };
    if ("detailLinkSelector" in r && r["detailLinkSelector"] !== void 0) {
      if (!isNonEmptyString(r["detailLinkSelector"])) {
        throw new SchemaParseError("detailLinkSelector present but not a string", raw);
      }
      schema.detailLinkSelector = r["detailLinkSelector"];
    }
    if ("detailFieldSelectors" in r && r["detailFieldSelectors"] !== void 0) {
      if (!isStringRecord(r["detailFieldSelectors"])) {
        throw new SchemaParseError("detailFieldSelectors must be string\u2192string", raw);
      }
      schema.detailFieldSelectors = r["detailFieldSelectors"];
    }
    return schema;
  }
  function joinUrl(base, path) {
    return `${base.replace(/\/+$/, "")}/${path.replace(/^\/+/, "")}`;
  }
  async function callAnthropic(prompt, opts, fetcher) {
    const base = opts.baseUrl ?? "https://api.anthropic.com";
    const res = await fetcher(joinUrl(base, "/v1/messages"), {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": opts.apiKey,
        authorization: `Bearer ${opts.apiKey}`,
        "anthropic-version": "2023-06-01",
        "anthropic-dangerous-direct-browser-access": "true"
      },
      body: JSON.stringify({
        model: opts.model ?? DEFAULT_MODEL.anthropic,
        max_tokens: 1024,
        messages: [{ role: "user", content: prompt }]
      })
    });
    if (!res.ok) {
      const body = await res.text().catch(() => "");
      throw new SchemaParseError(`Anthropic ${res.status}: ${body.slice(0, 200)}`, body);
    }
    const json = await res.json();
    const text = (json.content ?? []).filter((b) => b.type === "text" && typeof b.text === "string").map((b) => b.text).join("");
    if (text === "") {
      throw new SchemaParseError("Anthropic response had no text content", JSON.stringify(json));
    }
    return { text };
  }
  async function callOpenAI(prompt, opts, fetcher) {
    const base = opts.baseUrl ?? "https://api.openai.com";
    const res = await fetcher(joinUrl(base, "/v1/chat/completions"), {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${opts.apiKey}`
      },
      body: JSON.stringify({
        model: opts.model ?? DEFAULT_MODEL.openai,
        messages: [{ role: "user", content: prompt }]
      })
    });
    if (!res.ok) {
      const body = await res.text().catch(() => "");
      throw new SchemaParseError(`OpenAI ${res.status}: ${body.slice(0, 200)}`, body);
    }
    const json = await res.json();
    const text = json.choices?.[0]?.message?.content ?? "";
    if (text === "") {
      throw new SchemaParseError("OpenAI response had no content", JSON.stringify(json));
    }
    return { text };
  }
  async function discoverSchema(distilled, opts) {
    const fetcher = opts.fetcher ?? globalThis.fetch;
    const now = opts.now ?? Date.now;
    if (opts.spend) {
      const check = await opts.spend.canSpend(now());
      if (!check.ok) throw new SpendCapError(check.period);
    }
    const prompt = buildPrompt(distilled, opts.hint);
    const result = opts.provider === "anthropic" ? await callAnthropic(prompt, opts, fetcher) : await callOpenAI(prompt, opts, fetcher);
    const jsonText = extractJsonObject(result.text);
    let parsed;
    try {
      parsed = JSON.parse(jsonText);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      throw new SchemaParseError(`response is not valid JSON: ${msg}`, result.text);
    }
    const schema = validateSchemaShape(parsed, opts.fingerprint, now(), result.text);
    if (opts.spend) await opts.spend.recordSpend(now());
    return schema;
  }
  var SUGGEST_PROMPT_HEADER = `You suggest additional phrases that match the user's exclusion intent.

Output ONLY a single JSON object with this exact shape:
{ "suggestions": ["phrase one", "phrase two", ...] }

Suggest up to 6 short, distinct phrases. Don't repeat anything in "existing". Each phrase should be a literal substring that would appear in an item's text \u2014 not regex, not bullet syntax.`;
  function buildSuggestPrompt(opts) {
    const existing = opts.existing.length === 0 ? "(none yet)" : opts.existing.join(", ");
    return `${SUGGEST_PROMPT_HEADER}

Intent: ${opts.intent}
Existing phrases: ${existing}`;
  }
  function parseSuggestions(raw) {
    const obj = JSON.parse(extractJsonObject(raw));
    if (!Array.isArray(obj.suggestions)) {
      throw new SchemaParseError("suggestions field missing or not an array", raw);
    }
    const out = [];
    for (const v of obj.suggestions) {
      if (typeof v !== "string") continue;
      const trimmed = v.trim();
      if (trimmed.length > 0 && trimmed.length <= 80) out.push(trimmed);
    }
    return out;
  }
  async function suggestPhrases(opts) {
    const fetcher = opts.fetcher ?? globalThis.fetch;
    const now = opts.now ?? Date.now;
    if (opts.spend) {
      const check = await opts.spend.canSpend(now());
      if (!check.ok) throw new SpendCapError(check.period);
    }
    const prompt = buildSuggestPrompt(opts);
    const callOpts = {
      provider: opts.provider,
      apiKey: opts.apiKey,
      // Suggestions are fingerprint-agnostic. We pass a synthetic value
      // so we can reuse the provider plumbing without forking it.
      fingerprint: "suggest",
      ...opts.model !== void 0 ? { model: opts.model } : {},
      fetcher
    };
    const result = opts.provider === "anthropic" ? await callAnthropic(prompt, callOpts, fetcher) : await callOpenAI(prompt, callOpts, fetcher);
    let suggestions;
    try {
      suggestions = parseSuggestions(result.text);
    } catch (err) {
      if (err instanceof SchemaParseError) throw err;
      const msg = err instanceof Error ? err.message : String(err);
      throw new SchemaParseError(`suggestions response is not valid JSON: ${msg}`, result.text);
    }
    if (opts.spend) await opts.spend.recordSpend(now());
    const seen = new Set(opts.existing.map((p) => p.toLowerCase()));
    const out = [];
    for (const s of suggestions) {
      const k = s.toLowerCase();
      if (seen.has(k)) continue;
      seen.add(k);
      out.push(s);
    }
    return out;
  }

  // extension/background/cache.ts
  var STORAGE_KEY_PREFIX = "nf:schema:";
  var storageKey = (fingerprint) => `${STORAGE_KEY_PREFIX}${fingerprint}`;
  function chromeStorageSchemaCache() {
    return {
      async get(fingerprint) {
        const key = storageKey(fingerprint);
        const result = await chrome.storage.local.get([key]);
        const value = result[key];
        return value && typeof value === "object" ? value : null;
      },
      async set(fingerprint, schema) {
        await chrome.storage.local.set({ [storageKey(fingerprint)]: schema });
      }
    };
  }
  function memorySchemaCache() {
    const store = /* @__PURE__ */ new Map();
    return {
      async get(fingerprint) {
        return store.get(fingerprint) ?? null;
      },
      async set(fingerprint, schema) {
        store.set(fingerprint, schema);
      }
    };
  }
  async function getOrDiscover(req, deps) {
    if (!req.force) {
      const cached = await deps.cache.get(req.fingerprint);
      if (cached) return cached;
    }
    const settings = await deps.loadSettings();
    const llm = deps.llm ?? discoverSchema;
    const llmOpts = {
      provider: settings.provider,
      apiKey: settings.apiKey,
      fingerprint: req.fingerprint
    };
    if (settings.model !== void 0) llmOpts.model = settings.model;
    if (settings.baseUrl !== void 0) llmOpts.baseUrl = settings.baseUrl;
    if (req.hint !== void 0) llmOpts.hint = req.hint;
    if (deps.fetcher !== void 0) llmOpts.fetcher = deps.fetcher;
    if (deps.now !== void 0) llmOpts.now = deps.now;
    const schema = await llm(req.distilled, llmOpts);
    await deps.cache.set(req.fingerprint, schema);
    return schema;
  }

  // extension/background/queue.ts
  var STORAGE_KEY = "nf:deep-queue";
  var ALARM_NAME = "nf-deep-queue-heartbeat";
  var HEARTBEAT_MINUTES = 1;
  var MAX_ATTEMPTS = 3;
  function keyOf(item) {
    return `${item.fingerprint}::${item.itemUrl}`;
  }
  function mergeEnqueue(existing, add, now) {
    const byKey = /* @__PURE__ */ new Map();
    for (const e of existing) byKey.set(keyOf(e), e);
    for (const a of add) {
      const k = keyOf(a);
      if (byKey.has(k)) continue;
      byKey.set(k, {
        fingerprint: a.fingerprint,
        itemUrl: a.itemUrl,
        status: "pending",
        enqueuedAt: now,
        attempts: 0
      });
    }
    return Array.from(byKey.values());
  }
  function reviveInFlight(items) {
    return items.map((i) => i.status === "in-flight" ? { ...i, status: "pending" } : i);
  }
  function nextPending(items) {
    let oldest = null;
    for (const i of items) {
      if (i.status !== "pending") continue;
      if (oldest === null || i.enqueuedAt < oldest.enqueuedAt) oldest = i;
    }
    return oldest;
  }
  function markStatus(items, key, patch) {
    return items.map((i) => keyOf(i) === key ? { ...i, ...patch } : i);
  }
  var chromeQueueIO = {
    async load() {
      const r = await chrome.storage.local.get(STORAGE_KEY);
      const raw = r[STORAGE_KEY];
      if (!Array.isArray(raw)) return [];
      const out = [];
      for (const x of raw) {
        if (typeof x !== "object" || x === null) continue;
        const o = x;
        if (typeof o["fingerprint"] !== "string") continue;
        if (typeof o["itemUrl"] !== "string") continue;
        if (o["status"] !== "pending" && o["status"] !== "in-flight" && o["status"] !== "done" && o["status"] !== "failed") continue;
        if (typeof o["enqueuedAt"] !== "number") continue;
        if (typeof o["attempts"] !== "number") continue;
        const item = {
          fingerprint: o["fingerprint"],
          itemUrl: o["itemUrl"],
          status: o["status"],
          enqueuedAt: o["enqueuedAt"],
          attempts: o["attempts"]
        };
        if (typeof o["lastError"] === "string") item.lastError = o["lastError"];
        out.push(item);
      }
      return out;
    },
    async save(items) {
      await chrome.storage.local.set({ [STORAGE_KEY]: items });
    }
  };
  function memoryQueueIO(initial = []) {
    let store = [...initial];
    return {
      async load() {
        return [...store];
      },
      async save(items) {
        store = [...items];
      }
    };
  }
  var PersistentQueue = class {
    constructor(io = chromeQueueIO, now = Date.now) {
      this.io = io;
      this.now = now;
    }
    /** Init: revive in-flight → pending so a mid-drain crash doesn't
     *  strand items. Call once on SW startup. */
    async init() {
      const items = await this.io.load();
      const revived = reviveInFlight(items);
      if (revived.some((r, i) => r !== items[i])) await this.io.save(revived);
    }
    async enqueue(batch) {
      const items = await this.io.load();
      const merged = mergeEnqueue(items, batch, this.now());
      if (merged.length !== items.length) await this.io.save(merged);
    }
    /** Pop the oldest pending item and mark it in-flight. Returns null
     *  when nothing's pending. Caller must call `markDone` or
     *  `markFailed` to settle. */
    async checkout() {
      const items = await this.io.load();
      const next = nextPending(items);
      if (!next) return null;
      const key = keyOf(next);
      const updated = markStatus(items, key, {
        status: "in-flight",
        attempts: next.attempts + 1
      });
      await this.io.save(updated);
      return { ...next, status: "in-flight", attempts: next.attempts + 1 };
    }
    async markDone(item) {
      const items = await this.io.load();
      const updated = markStatus(items, keyOf(item), { status: "done" });
      await this.io.save(updated);
    }
    async markFailed(item, error) {
      const items = await this.io.load();
      const target = items.find((i) => keyOf(i) === keyOf(item));
      if (!target) return;
      const nextStatus = target.attempts >= MAX_ATTEMPTS ? "failed" : "pending";
      const updated = markStatus(items, keyOf(item), {
        status: nextStatus,
        lastError: error.slice(0, 200)
      });
      await this.io.save(updated);
    }
    async snapshot() {
      return await this.io.load();
    }
    async pending() {
      return (await this.io.load()).filter((i) => i.status === "pending");
    }
  };
  var QUEUE_INTERNALS = {
    STORAGE_KEY,
    ALARM_NAME,
    HEARTBEAT_MINUTES,
    MAX_ATTEMPTS
  };

  // extension/background/deep-runner.ts
  var DEFAULT_TIMEOUT_MS = 15e3;
  function chromeTabsLike() {
    return {
      create: (p) => chrome.tabs.create(p),
      remove: (id) => chrome.tabs.remove(id)
    };
  }
  function defaultAwaitDetail(tabId) {
    return new Promise((resolveOuter, reject) => {
      const listener = (raw, sender) => {
        if (sender.tab?.id !== tabId) return false;
        if (typeof raw !== "object" || raw === null) return false;
        const r = raw;
        if (r["t"] !== "detailReady") return false;
        if (typeof r["fields"] !== "object" || r["fields"] === null) {
          chrome.runtime.onMessage.removeListener(listener);
          reject(new Error("detailReady missing fields"));
          return false;
        }
        chrome.runtime.onMessage.removeListener(listener);
        resolveOuter(r["fields"]);
        return false;
      };
      chrome.runtime.onMessage.addListener(listener);
    });
  }
  async function runOne(itemUrl, opts = {}) {
    const tabs = opts.tabs ?? chromeTabsLike();
    const awaitDetail = opts.awaitDetail ?? defaultAwaitDetail;
    const timeout = opts.timeoutMs ?? DEFAULT_TIMEOUT_MS;
    const now = opts.now ?? Date.now;
    const start = now();
    const tab = await tabs.create({ url: itemUrl, active: false });
    if (tab.id === void 0) {
      throw new Error("chrome.tabs.create returned a tab without an id");
    }
    const tabId = tab.id;
    let timer = null;
    const timeoutPromise = new Promise((_, reject) => {
      timer = setTimeout(() => {
        reject(new Error(`deep-runner timed out after ${timeout}ms`));
      }, timeout);
    });
    let fields;
    try {
      fields = await Promise.race([awaitDetail(tabId), timeoutPromise]);
    } finally {
      if (timer !== null) clearTimeout(timer);
      await tabs.remove(tabId).catch(() => void 0);
    }
    return {
      itemUrl,
      fields,
      durationMs: now() - start
    };
  }

  // extension/background/throttle.ts
  var DEFAULT_BACKOFF = [500, 1e3, 2e3, 4e3, 8e3];
  var Throttler = class {
    concurrency;
    jitterMs;
    backoffMs;
    sleep;
    random;
    /** In-flight count + waiter queue, per domain. */
    domains = /* @__PURE__ */ new Map();
    constructor(opts) {
      this.concurrency = opts.concurrency;
      this.jitterMs = opts.jitterMs ?? 200;
      this.backoffMs = opts.backoffMs ?? DEFAULT_BACKOFF;
      this.sleep = opts.sleep ?? ((ms) => new Promise((r) => setTimeout(r, ms)));
      this.random = opts.random ?? Math.random;
    }
    /** Acquire a slot for `domain`. Resolves when the caller may proceed.
     *  Caller MUST call the returned `release` function once (typically
     *  via try/finally) so subsequent waiters can advance. */
    async acquire(domain) {
      const state = this.stateFor(domain);
      while (state.inFlight >= this.concurrency) {
        await new Promise((r) => state.waiters.push(r));
      }
      state.inFlight += 1;
      if (state.backoffUntil > Date.now()) {
        const remaining = state.backoffUntil - Date.now();
        await this.sleep(remaining);
      }
      if (this.jitterMs > 0) {
        await this.sleep(Math.floor(this.random() * this.jitterMs));
      }
      let released = false;
      return () => {
        if (released) return;
        released = true;
        state.inFlight = Math.max(0, state.inFlight - 1);
        const next = state.waiters.shift();
        if (next) next();
      };
    }
    /** Caller signals an outcome — used to escalate / decay the backoff
     *  for that domain. */
    reportOutcome(domain, outcome) {
      const state = this.stateFor(domain);
      if (outcome === "rate-limited") {
        const idx = Math.min(state.consecutive429, this.backoffMs.length - 1);
        const delay = this.backoffMs[idx] ?? this.backoffMs[this.backoffMs.length - 1] ?? 0;
        state.consecutive429 += 1;
        state.backoffUntil = Date.now() + delay;
      } else {
        state.consecutive429 = 0;
        state.backoffUntil = 0;
      }
    }
    /** Snapshot for tests — current in-flight + backoff state. */
    inspect(domain) {
      const s = this.stateFor(domain);
      return {
        inFlight: s.inFlight,
        consecutive429: s.consecutive429,
        backoffUntil: s.backoffUntil
      };
    }
    stateFor(domain) {
      let s = this.domains.get(domain);
      if (!s) {
        s = { inFlight: 0, waiters: [], consecutive429: 0, backoffUntil: 0 };
        this.domains.set(domain, s);
      }
      return s;
    }
  };

  // extension/content/detail.ts
  function extractDetailFields(schema, doc = document) {
    const out = {};
    const map = schema.detailFieldSelectors;
    if (!map) return out;
    for (const [name, selector] of Object.entries(map)) {
      const el = doc.querySelector(selector);
      const text = el?.textContent?.trim();
      if (text && text.length > 0) out[name] = text;
    }
    return out;
  }
  function isDetailPage(schema, doc = document) {
    if (!schema.detailFieldSelectors) return false;
    if (doc.querySelector(schema.itemSetSelector)) return false;
    for (const selector of Object.values(schema.detailFieldSelectors)) {
      if (doc.querySelector(selector)) return true;
    }
    return false;
  }

  // extension/content/viewport-enqueuer.ts
  var ViewportEnqueuer = class {
    constructor(opts) {
      this.opts = opts;
    }
    observer = null;
    /** Fire-once gating per element. WeakSet so removed nodes don't
     *  pin themselves in memory. */
    fired = /* @__PURE__ */ new WeakSet();
    /** Sort buffer — collected per observer callback, drained at the
     *  end of the tick so top-down order is preserved. */
    buffer = [];
    start() {
      if (this.observer) return;
      this.observer = new IntersectionObserver(
        (entries) => this.onIntersect(entries),
        {
          rootMargin: this.opts.rootMargin ?? "100% 0px",
          threshold: this.opts.threshold ?? 0
        }
      );
      for (const item of this.opts.items) this.observer.observe(item);
    }
    stop() {
      this.observer?.disconnect();
      this.observer = null;
      this.buffer.length = 0;
    }
    /** Allow the host to add newly-appeared items (paired with the
     *  4.6 mutation observer). */
    observe(item) {
      if (!this.observer) return;
      this.observer.observe(item);
    }
    onIntersect(entries) {
      for (const e of entries) {
        if (!e.isIntersecting) continue;
        if (this.fired.has(e.target)) continue;
        this.buffer.push(e.target);
      }
      if (this.buffer.length === 0) return;
      this.buffer.sort((a, b) => {
        const ar = a.getBoundingClientRect().top;
        const br = b.getBoundingClientRect().top;
        return ar - br;
      });
      for (const el of this.buffer) {
        if (this.fired.has(el)) continue;
        this.fired.add(el);
        try {
          this.opts.onNearViewport(el);
        } catch {
        }
      }
      this.buffer.length = 0;
    }
  };

  // extension/shared/safe-regex.ts
  var UnsafeRegexError = class extends Error {
    reason;
    pattern;
    constructor(reason, pattern) {
      super(`UnsafeRegexError: ${reason}`);
      this.name = "UnsafeRegexError";
      this.reason = reason;
      this.pattern = pattern;
    }
  };
  var MAX_REGEX_LENGTH = 256;
  var NESTED_QUANTIFIER = /\([^)]*[+*][^)]*\)\s*[+*?{]/;
  function safeCompileRegex(pattern, flags) {
    if (pattern.length === 0) {
      throw new UnsafeRegexError("empty pattern", pattern);
    }
    if (pattern.length > MAX_REGEX_LENGTH) {
      throw new UnsafeRegexError(
        `length ${pattern.length} exceeds cap ${MAX_REGEX_LENGTH}`,
        pattern
      );
    }
    if (NESTED_QUANTIFIER.test(pattern)) {
      throw new UnsafeRegexError("nested quantifier (ReDoS risk)", pattern);
    }
    try {
      return new RegExp(pattern, flags);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      throw new UnsafeRegexError(`syntax: ${msg}`, pattern);
    }
  }

  // extension/content/detect.ts
  var NON_CONTENT_TAGS2 = /* @__PURE__ */ new Set([
    "HEAD",
    "SCRIPT",
    "STYLE",
    "LINK",
    "META",
    "TITLE",
    "NOSCRIPT",
    "BASE",
    "TEMPLATE"
  ]);
  var MIN_GROUP_SIZE = 3;
  function signatureOf(el) {
    const classes = Array.from(el.classList).sort().join(".");
    return classes ? `${el.tagName}.${classes}` : el.tagName;
  }
  function elementChildren2(parent) {
    const out = [];
    for (const child of Array.from(parent.children)) {
      if (NON_CONTENT_TAGS2.has(child.tagName)) continue;
      out.push(child);
    }
    return out;
  }
  function evaluateParent(parent) {
    const children = elementChildren2(parent);
    if (children.length < MIN_GROUP_SIZE) return null;
    const groups = /* @__PURE__ */ new Map();
    for (const child of children) {
      const sig = signatureOf(child);
      const list = groups.get(sig);
      if (list) list.push(child);
      else groups.set(sig, [child]);
    }
    let best = null;
    for (const [sig, group] of groups) {
      if (group.length < MIN_GROUP_SIZE) continue;
      let total = 0;
      for (const el of group) total += el.getElementsByTagName("*").length;
      const meanDescendants = total / group.length;
      const score = group.length * meanDescendants;
      if (!best || score > best.score) {
        best = { container: parent, group, signature: sig, score };
      }
    }
    return best;
  }
  function classify(container) {
    const style = getComputedStyle(container);
    const display = style.display;
    if (display === "grid" || display === "inline-grid") return "grid";
    if (display === "flex" || display === "inline-flex") {
      const direction = style.flexDirection;
      const horizontal = direction === "row" || direction === "row-reverse";
      const overflowX = style.overflowX;
      const scrolls = overflowX === "auto" || overflowX === "scroll";
      if (horizontal && scrolls) return "carousel";
    }
    return "list";
  }
  function detect(root) {
    const startEl = root instanceof Document ? root.documentElement : root;
    if (!startEl) return null;
    let best = null;
    const stack = [startEl];
    while (stack.length > 0) {
      const node = stack.pop();
      if (NON_CONTENT_TAGS2.has(node.tagName)) continue;
      const cand = evaluateParent(node);
      if (cand && (!best || cand.score > best.score)) best = cand;
      for (const child of Array.from(node.children)) {
        if (!NON_CONTENT_TAGS2.has(child.tagName)) stack.push(child);
      }
    }
    return best?.container ?? null;
  }
  function leafSelector(el) {
    const tag = el.tagName.toLowerCase();
    const classes = Array.from(el.classList);
    if (classes.length === 0) return tag;
    const escaped = classes.sort().map((c) => `.${CSS.escape(c)}`).join("");
    return `${tag}${escaped}`;
  }
  function uniqueSelectorFor(el) {
    const doc = el.ownerDocument;
    if (!doc) return leafSelector(el);
    if (el.id) {
      const idSel = `#${CSS.escape(el.id)}`;
      if (doc.querySelector(idSel) === el) return idSel;
    }
    let path = leafSelector(el);
    if (doc.querySelector(path) === el) return path;
    let cursor = el.parentElement;
    while (cursor && cursor !== doc.documentElement) {
      if (cursor.id) {
        const prefixed = `#${CSS.escape(cursor.id)} > ${path}`;
        if (doc.querySelector(prefixed) === el) return prefixed;
      }
      const ancestor = leafSelector(cursor);
      path = `${ancestor} > ${path}`;
      if (doc.querySelector(path) === el) return path;
      cursor = cursor.parentElement;
    }
    return path;
  }
  function generalize(picked) {
    const parent = picked.parentElement;
    if (!parent) return null;
    const leaf = leafSelector(picked);
    const sameShapeSiblings = Array.from(parent.children).filter(
      (c) => leafSelector(c) === leaf
    );
    if (sameShapeSiblings.length < MIN_GROUP_SIZE) return null;
    const itemSetSelector = uniqueSelectorFor(parent);
    const itemSelector = `${itemSetSelector} > ${leaf}`;
    const doc = picked.ownerDocument;
    if (doc) {
      const matched = Array.from(doc.querySelectorAll(itemSelector));
      if (matched.length !== sameShapeSiblings.length) return null;
      for (const sib of sameShapeSiblings) {
        if (!matched.includes(sib)) return null;
      }
    }
    return { itemSetSelector, itemSelector };
  }

  // extension/content/fingerprint.ts
  var DEPTH = 3;
  var UTILITY_CLASS_PATTERNS = [
    /^css-[a-z0-9]{4,}$/i,
    /^_[a-z0-9_-]{3,}$/i,
    /^[a-z][\w-]*__[a-z0-9]{4,}$/i,
    /^jsx-\d{4,}$/i,
    /^sc-[a-z0-9]{4,}$/i
  ];
  function isUtilityClass(cls) {
    for (const re of UTILITY_CLASS_PATTERNS) {
      if (re.test(cls)) return true;
    }
    return false;
  }
  function nodeShape(el) {
    const classes = Array.from(el.classList).filter((c) => !isUtilityClass(c)).sort().join(".");
    return classes ? `${el.tagName}.${classes}` : el.tagName;
  }
  var NON_CONTENT_TAGS3 = /* @__PURE__ */ new Set([
    "SCRIPT",
    "STYLE",
    "LINK",
    "META",
    "NOSCRIPT",
    "TEMPLATE"
  ]);
  function elementChildren3(parent) {
    const out = [];
    for (const child of Array.from(parent.children)) {
      if (NON_CONTENT_TAGS3.has(child.tagName)) continue;
      out.push(child);
    }
    return out;
  }
  function recursiveShape(el, depth) {
    if (depth === 0) return nodeShape(el);
    const children = elementChildren3(el).map((c) => recursiveShape(c, depth - 1)).sort();
    return children.length === 0 ? nodeShape(el) : `${nodeShape(el)}(${children.join(",")})`;
  }
  function modeOf(xs) {
    if (xs.length === 0) return null;
    const counts = /* @__PURE__ */ new Map();
    for (const x of xs) counts.set(x, (counts.get(x) ?? 0) + 1);
    let best = null;
    const sorted = [...counts.entries()].sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0);
    for (const [value, count] of sorted) {
      if (!best || count > best.count) best = { value, count };
    }
    return best?.value ?? null;
  }
  function fnv1a32(s) {
    let h = 2166136261;
    for (let i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24)) >>> 0;
    }
    return h.toString(16).padStart(8, "0");
  }
  function fingerprintItemSet(itemSet) {
    const children = elementChildren3(itemSet);
    if (children.length === 0) return null;
    const childShapes = children.map((c) => recursiveShape(c, DEPTH));
    const modal = modeOf(childShapes);
    if (modal === null) return null;
    const containerShape = nodeShape(itemSet);
    return fnv1a32(`${containerShape}|${modal}`);
  }

  // extension/content/discover.ts
  async function discover(doc, ctx, opts = {}) {
    const itemSet = detect(doc);
    if (!itemSet) return null;
    const fingerprint = fingerprintItemSet(itemSet);
    if (!fingerprint) return null;
    const layout = classify(itemSet);
    const distilled = distill(itemSet);
    const req = { fingerprint, distilled, layout };
    if (opts.hint !== void 0) req.hint = opts.hint;
    if (opts.force === true) req.force = true;
    const schema = await ctx.fetchSchema(req);
    return { schema, itemSet };
  }

  // extension/panel/components/page-status.ts
  function renderPageStatus(host, state) {
    host.replaceChildren();
    const h = document.createElement("h2");
    h.className = "section-h";
    h.textContent = "Page";
    host.appendChild(h);
    const status = document.createElement("p");
    status.className = "section-meta";
    if (state.schema) {
      status.textContent = `Detected: ${state.schema.layout} \xB7 ${state.itemCount} item${state.itemCount === 1 ? "" : "s"}`;
    } else {
      status.textContent = "No list detected.";
    }
    host.appendChild(status);
    if (!state.schema) return;
    const toggle = document.createElement("div");
    toggle.className = "mode-toggle";
    toggle.dataset["role"] = "display-mode";
    toggle.setAttribute("role", "group");
    toggle.setAttribute("aria-label", "Display mode");
    for (const m of ["collapse", "hide"]) {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "mode-btn";
      btn.dataset["mode"] = m;
      btn.textContent = m === "collapse" ? "Collapse" : "Hide";
      btn.setAttribute("aria-pressed", String(state.mode === m));
      if (state.mode === m) btn.classList.add("active");
      btn.onclick = () => state.onModeChange(m);
      toggle.appendChild(btn);
    }
    host.appendChild(toggle);
    if (state.onRediscover) {
      const rediscoverHandler = state.onRediscover;
      const rediscover = document.createElement("div");
      rediscover.className = "rediscover";
      rediscover.dataset["role"] = "rediscover";
      const hintInput = document.createElement("input");
      hintInput.type = "text";
      hintInput.dataset["input"] = "rediscover-hint";
      hintInput.placeholder = 'Hint (optional, e.g. "title is in the h3")';
      hintInput.className = "rediscover-hint";
      rediscover.appendChild(hintInput);
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "rediscover-btn";
      btn.dataset["action"] = "rediscover";
      btn.textContent = "Re-discover";
      btn.addEventListener("click", () => {
        const hint = hintInput.value.trim();
        const payload = { force: true };
        if (hint !== "") payload.hint = hint;
        rediscoverHandler(payload);
      });
      rediscover.appendChild(btn);
      host.appendChild(rediscover);
    }
  }

  // extension/content/engine.ts
  function readField(item, fieldName, schema) {
    const field = schema.fields[fieldName];
    if (!field) return null;
    const el = item.querySelector(field.selector);
    const text = el?.textContent?.trim();
    return text && text.length > 0 ? text : null;
  }
  function parseFirstNumber(text) {
    const m = text.match(/-?\d+(?:\.\d+)?/);
    if (!m) return null;
    const n = parseFloat(m[0]);
    return Number.isFinite(n) ? n : null;
  }
  function evalPredicate(text, pred) {
    switch (pred.op) {
      case "containsAny": {
        const haystack = text.toLowerCase();
        for (const phrase of pred.phrases) {
          if (phrase.length === 0) continue;
          if (haystack.includes(phrase.toLowerCase())) {
            return { matched: true, trigger: phrase };
          }
        }
        return { matched: false };
      }
      case "regex": {
        const re = safeCompileRegex(pred.pattern, pred.flags);
        const match = re.exec(text);
        return match ? { matched: true, trigger: match[0] } : { matched: false };
      }
      case "lessThan": {
        const n = parseFirstNumber(text);
        return n !== null && n < pred.value ? { matched: true, trigger: `${n} < ${pred.value}` } : { matched: false };
      }
      case "greaterThan": {
        const n = parseFirstNumber(text);
        return n !== null && n > pred.value ? { matched: true, trigger: `${n} > ${pred.value}` } : { matched: false };
      }
      case "equals": {
        const target = typeof pred.value === "string" ? pred.value : String(pred.value);
        return text === target ? { matched: true, trigger: target } : { matched: false };
      }
      case "oneOf": {
        for (const v of pred.values) {
          const target = typeof v === "string" ? v : String(v);
          if (text === target) return { matched: true, trigger: target };
        }
        return { matched: false };
      }
    }
  }
  function evaluate(schema, items, filters) {
    const out = /* @__PURE__ */ new Map();
    const applicable = filters.filter((f) => f.fingerprint === schema.fingerprint);
    for (const item of items) {
      let verdict = { state: "passing" };
      for (const filter of applicable) {
        const text = readField(item, filter.field, schema);
        if (text === null) continue;
        const outcome = evalPredicate(text, filter.predicate);
        const excludes = filter.polarity === "exclude" && outcome.matched || filter.polarity === "keep" && !outcome.matched;
        if (excludes) {
          verdict = {
            state: "filtered",
            reason: outcome.trigger ?? filter.predicate.op
          };
          break;
        }
      }
      out.set(item, verdict);
    }
    return out;
  }
  function findItems(schema, doc = document) {
    return Array.from(doc.querySelectorAll(schema.itemSelector));
  }

  // extension/content/picker.ts
  var OVERLAY_ID = "nf-pick-outline";
  var Picker = class {
    overlay = null;
    active = false;
    lastTarget = null;
    opts;
    // Stable bound refs so removeEventListener actually matches on stop().
    onMove = (ev) => this.handleMove(ev);
    onScrollOrResize = () => this.repositionOverlay();
    constructor(opts = {}) {
      this.opts = opts;
    }
    isActive() {
      return this.active;
    }
    /** Begin pick mode. Idempotent — calling twice is a no-op. */
    start() {
      if (this.active) return;
      this.active = true;
      const overlay = document.createElement("div");
      overlay.id = OVERLAY_ID;
      Object.assign(overlay.style, {
        position: "fixed",
        pointerEvents: "none",
        zIndex: "2147483646",
        // one below the max — keeps any future toast above us
        boxSizing: "border-box",
        outline: "2px solid #1f6feb",
        outlineOffset: "0px",
        background: "rgba(31, 111, 235, 0.08)",
        transition: "top 60ms linear, left 60ms linear, width 60ms linear, height 60ms linear",
        display: "none",
        // hidden until first hover with a real target
        top: "0px",
        left: "0px",
        width: "0px",
        height: "0px"
      });
      document.body.appendChild(overlay);
      this.overlay = overlay;
      document.addEventListener("mousemove", this.onMove, true);
      window.addEventListener("scroll", this.onScrollOrResize, true);
      window.addEventListener("resize", this.onScrollOrResize, true);
    }
    /** End pick mode. Removes the overlay and all listeners. Idempotent. */
    stop() {
      if (!this.active) return;
      this.active = false;
      document.removeEventListener("mousemove", this.onMove, true);
      window.removeEventListener("scroll", this.onScrollOrResize, true);
      window.removeEventListener("resize", this.onScrollOrResize, true);
      if (this.overlay && this.overlay.parentNode) {
        this.overlay.parentNode.removeChild(this.overlay);
      }
      this.overlay = null;
      this.lastTarget = null;
    }
    handleMove(ev) {
      if (!this.active || !this.overlay) return;
      const target = document.elementFromPoint(ev.clientX, ev.clientY);
      if (!target || target === this.lastTarget) return;
      this.lastTarget = target;
      this.paint(target);
      this.opts.onHover?.(target);
    }
    paint(target) {
      if (!this.overlay) return;
      const rect = target.getBoundingClientRect();
      const o = this.overlay.style;
      o.display = "block";
      o.top = `${rect.top}px`;
      o.left = `${rect.left}px`;
      o.width = `${rect.width}px`;
      o.height = `${rect.height}px`;
    }
    repositionOverlay() {
      if (!this.active || !this.lastTarget) return;
      this.paint(this.lastTarget);
    }
  };

  // extension/content/renderer.ts
  var STYLE_EL_ID = "nf-injected-styles";
  var STYLES = `
.filt > .nf-card-hidden { display: none; }
.filt > .sliver {
  display: block;
  height: 28px;
  line-height: 28px;
  padding: 0 10px;
  font: 12px/28px system-ui, -apple-system, Segoe UI, sans-serif;
  color: #57606a;
  background: #f6f8fa;
  border: 1px solid #d0d7de;
  border-radius: 6px;
  cursor: pointer;
  user-select: none;
  text-align: left;
  width: 100%;
  box-sizing: border-box;
}
.filt > .sliver:hover { background: #eaeef2; }
.filt.restored > .sliver { display: none; }
.filt.restored > .nf-card-hidden { display: block; }
.filt > .rehide { display: none; }
.filt.restored > .rehide {
  display: inline-block;
  margin-top: 4px;
  padding: 2px 8px;
  font: 11px/1 system-ui, -apple-system, Segoe UI, sans-serif;
  color: #57606a;
  background: transparent;
  border: 1px solid #d0d7de;
  border-radius: 4px;
  cursor: pointer;
}
.mode-hide > .filt:not(.restored) { display: none; }
/* Carousel layout (Slice 2.5): a narrow vertical sliver replaces the card
   width-wise so the horizontal track keeps the same flex shape; reason
   text is rotated to read top-to-bottom. */
.filt.layout-carousel {
  flex: 0 0 46px;
  width: 46px;
  min-width: 46px;
  align-self: stretch;
}
.filt.layout-carousel > .sliver-v {
  display: block;
  width: 100%;
  min-height: 120px;
  height: 100%;
  padding: 8px 6px;
  font: 12px/1.2 system-ui, -apple-system, Segoe UI, sans-serif;
  color: #57606a;
  background: #f6f8fa;
  border: 1px solid #d0d7de;
  border-radius: 6px;
  cursor: pointer;
  user-select: none;
  box-sizing: border-box;
  writing-mode: vertical-rl;
  text-align: left;
  overflow: hidden;
}
.filt.layout-carousel > .sliver-v:hover { background: #eaeef2; }
.filt.layout-carousel.restored > .sliver-v { display: none; }
/* Grid layout (Slice 2.6): wrapper still occupies exactly one grid cell so
   the column count and row pack stay stable; a .ctile placeholder fills
   the cell footprint and signals "hidden item." No flex sizing \u2014 the host
   grid template already gives the wrapper the right cell. */
.filt.layout-grid > .ctile {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 60px;
  height: 100%;
  width: 100%;
  padding: 12px;
  font: 12px/1.3 system-ui, -apple-system, Segoe UI, sans-serif;
  color: #57606a;
  background: #f6f8fa;
  border: 1px dashed #d0d7de;
  border-radius: 8px;
  cursor: pointer;
  user-select: none;
  text-align: center;
  box-sizing: border-box;
}
.filt.layout-grid > .ctile:hover { background: #eaeef2; }
.filt.layout-grid.restored > .ctile { display: none; }
/* Checking state (Slice 5.7): items mid-deep-scan get a small inline
   spinner. We add an absolutely-positioned indicator element rather
   than restyling the card so the passing-card outerHTML still snaps
   back to identical when the spinner is removed. */
.nf-check-mark {
  display: inline-block;
  margin-left: 6px;
  padding: 1px 6px;
  font: 11px/1.2 system-ui, -apple-system, Segoe UI, sans-serif;
  color: #57606a;
  background: #f6f8fa;
  border: 1px solid #d0d7de;
  border-radius: 4px;
  vertical-align: middle;
}
`;
  function injectStyles(doc) {
    if (doc.getElementById(STYLE_EL_ID)) return;
    const style = doc.createElement("style");
    style.id = STYLE_EL_ID;
    style.textContent = STYLES;
    doc.head.appendChild(style);
  }
  var Renderer = class {
    opts;
    idByItem = /* @__PURE__ */ new WeakMap();
    /** Per-item .filt wrapper — present iff the item is currently filtered. */
    wrapperByItem = /* @__PURE__ */ new WeakMap();
    /** Reverse lookup so click handlers (1.5) can resolve id → item. */
    itemById = /* @__PURE__ */ new Map();
    restored = /* @__PURE__ */ new Set();
    /** Slice 5.7: items currently in the "checking" state (deep scan in
     *  flight). Cleared once the engine apply() resolves them. */
    checking = /* @__PURE__ */ new Set();
    /** Spinner element per checking item — held so we can remove it
     *  cleanly without re-querying. */
    checkMarkById = /* @__PURE__ */ new Map();
    nextId = 0;
    lastSummaries = [];
    constructor(opts) {
      const doc = opts.doc ?? opts.itemSet.ownerDocument ?? document;
      this.opts = {
        schema: opts.schema,
        itemSet: opts.itemSet,
        doc,
        onRestoreToggle: opts.onRestoreToggle
      };
      injectStyles(doc);
    }
    /** Apply a fresh set of verdicts. Idempotent — re-applying with the same
     *  inputs is a DOM no-op. Returns one summary per item, in input order. */
    apply(verdicts) {
      const summaries = [];
      for (const [item, verdict] of verdicts) {
        this.handleRecycledItem(item);
        const id = this.ensureId(item);
        const label = this.readLabel(item);
        const wasFiltered = this.wrapperByItem.has(item);
        if (verdict.state === "filtered") {
          if (!wasFiltered) {
            this.wrap(item, verdict, id);
          } else {
            this.refreshSliver(item, verdict);
          }
        } else if (verdict.state === "passing") {
          if (wasFiltered) {
            this.unwrap(item, id);
          }
        }
        if (this.checking.has(id) && verdict.state !== "checking") {
          this.checking.delete(id);
          this.removeCheckMark(id);
        }
        const reportedState = verdict.state === "filtered" && this.restored.has(id) ? "restored" : verdict.state;
        const summary = { id, state: reportedState };
        if (verdict.reason !== void 0) summary.reason = verdict.reason;
        if (label !== void 0) summary.label = label;
        summaries.push(summary);
      }
      this.lastSummaries = summaries;
      return summaries;
    }
    /** Flip a single item's restored flag. Reflected in the DOM (the wrapper
     *  gets `.restored`) and in subsequent summaries. */
    setRestored(itemId, restored) {
      const item = this.itemById.get(itemId);
      if (!item) return;
      const wrapper = this.wrapperByItem.get(item);
      if (!wrapper) return;
      if (restored) {
        this.restored.add(itemId);
        wrapper.classList.add("restored");
      } else {
        this.restored.delete(itemId);
        wrapper.classList.remove("restored");
      }
      const summary = this.lastSummaries.find((s) => s.id === itemId);
      if (summary) summary.state = restored ? "restored" : "filtered";
    }
    /** Slice 5.7: mark an item as actively being deep-scanned. The
     *  renderer adds a small spinner indicator next to it; once the
     *  engine produces a `filtered` or `passing` verdict (next apply
     *  call), the spinner is removed and the verdict takes effect. */
    setChecking(itemId, on) {
      const item = this.itemById.get(itemId);
      if (!item) return;
      if (on) {
        if (this.checking.has(itemId)) return;
        this.checking.add(itemId);
        const mark = this.opts.doc.createElement("span");
        mark.className = "nf-check-mark";
        mark.dataset["nfId"] = itemId;
        mark.textContent = "\u23F3 checking\u2026";
        item.appendChild(mark);
        this.checkMarkById.set(itemId, mark);
        const summary = this.lastSummaries.find((s) => s.id === itemId);
        if (summary) summary.state = "checking";
      } else {
        this.checking.delete(itemId);
        this.removeCheckMark(itemId);
      }
    }
    /** Toggle the display mode on the item-set container. Slice 1.8 gate. */
    setMode(mode) {
      if (mode === "hide") this.opts.itemSet.classList.add("mode-hide");
      else this.opts.itemSet.classList.remove("mode-hide");
    }
    /** Latest summaries (state + label + reason) for every item the engine
     *  has evaluated. Survives between renderer.apply() calls. */
    summaries() {
      return this.lastSummaries;
    }
    // -------------------------------------------------------------------------
    // Internals
    // -------------------------------------------------------------------------
    ensureId(item) {
      let id = this.idByItem.get(item);
      if (id !== void 0) return id;
      const dataId = item.getAttribute("data-id");
      id = dataId && dataId.length > 0 ? dataId : `nf-${++this.nextId}`;
      this.idByItem.set(item, id);
      this.itemById.set(id, item);
      return id;
    }
    /** 6.1: identity-by-content for virtualized lists. The cached id
     *  for an element is stable as long as the element's data-id (or
     *  fallback synthetic id) stays the same. When a virtualizer
     *  recycles the element with a different data-id, we treat it as
     *  a new item — unwrap the old `.filt` wrapper (if any), drop the
     *  restored/checking flags scoped to the previous id, and clear
     *  the cache entry so ensureId() can re-mint. */
    handleRecycledItem(item) {
      const cached = this.idByItem.get(item);
      if (cached === void 0) return;
      const current = this.currentIdentityKey(item);
      if (current === null) return;
      if (cached === current) return;
      if (this.wrapperByItem.has(item)) this.unwrap(item, cached);
      this.restored.delete(cached);
      if (this.checking.has(cached)) {
        this.checking.delete(cached);
        this.removeCheckMark(cached);
      }
      this.itemById.delete(cached);
      this.idByItem.delete(item);
    }
    currentIdentityKey(item) {
      const dataId = item.getAttribute("data-id");
      return dataId && dataId.length > 0 ? dataId : null;
    }
    readLabel(item) {
      const fields = this.opts.schema.fields;
      const candidates = ["title", ...Object.keys(fields)];
      for (const name of candidates) {
        const f = fields[name];
        if (!f || f.kind !== "text") continue;
        const el = item.querySelector(f.selector);
        const text = el?.textContent?.trim();
        if (text && text.length > 0) return text;
      }
      return void 0;
    }
    wrap(item, verdict, id) {
      const doc = this.opts.doc;
      const layout = this.opts.schema.layout;
      const wrapper = doc.createElement("div");
      wrapper.className = layout === "carousel" ? "filt layout-carousel" : layout === "grid" ? "filt layout-grid" : "filt";
      wrapper.dataset["nfId"] = id;
      const sliver = doc.createElement("button");
      sliver.type = "button";
      sliver.className = layout === "carousel" ? "sliver-v" : layout === "grid" ? "ctile" : "sliver";
      sliver.dataset["nfId"] = id;
      sliver.setAttribute("aria-label", `Restore hidden item: ${this.readLabel(item) ?? id}`);
      sliver.textContent = this.sliverText(verdict);
      sliver.addEventListener("click", () => this.opts.onRestoreToggle?.(id, true));
      const rehide = doc.createElement("button");
      rehide.type = "button";
      rehide.className = "rehide";
      rehide.dataset["nfId"] = id;
      rehide.setAttribute("aria-label", `Re-hide ${this.readLabel(item) ?? id}`);
      rehide.textContent = "\u21BA re-hide";
      rehide.addEventListener("click", () => this.opts.onRestoreToggle?.(id, false));
      item.classList.add("nf-card-hidden");
      item.replaceWith(wrapper);
      wrapper.appendChild(item);
      wrapper.appendChild(sliver);
      wrapper.appendChild(rehide);
      this.wrapperByItem.set(item, wrapper);
      if (this.restored.has(id)) wrapper.classList.add("restored");
    }
    refreshSliver(item, verdict) {
      const wrapper = this.wrapperByItem.get(item);
      if (!wrapper) return;
      const sliver = wrapper.querySelector(".sliver, .sliver-v, .ctile");
      if (sliver) sliver.textContent = this.sliverText(verdict);
    }
    unwrap(item, id) {
      const wrapper = this.wrapperByItem.get(item);
      if (!wrapper) return;
      item.classList.remove("nf-card-hidden");
      wrapper.replaceWith(item);
      this.wrapperByItem.delete(item);
      this.restored.delete(id);
    }
    sliverText(verdict) {
      return verdict.reason ? `Hidden \u2014 ${verdict.reason}` : "Hidden";
    }
    removeCheckMark(itemId) {
      const mark = this.checkMarkById.get(itemId);
      if (!mark) return;
      mark.remove();
      this.checkMarkById.delete(itemId);
    }
  };

  // extension/content/schema-stub.ts
  var ROLECAST_STUB_SCHEMA = {
    fingerprint: "fixture:rolecast:v1",
    layout: "list",
    itemSetSelector: ".joblist",
    itemSelector: ".joblist > .job",
    fields: {
      title: { kind: "text", selector: ".title" },
      company: { kind: "text", selector: ".company" },
      location: { kind: "text", selector: ".location" },
      snippet: { kind: "text", selector: ".snippet" },
      // 4.4 needs a number field for the slider editor; engine's
      // parseFirstNumber reads "$180k–$220k" → 180 (lower-bound semantics).
      comp: { kind: "number", selector: ".comp" }
    },
    source: "stub",
    discoveredAt: 0
  };
  var ALL_STUBS = [ROLECAST_STUB_SCHEMA];
  function pickStubSchema(doc = document) {
    for (const schema of ALL_STUBS) {
      if (doc.querySelector(schema.itemSetSelector)) return schema;
    }
    return null;
  }

  // tests/testbed/runtime.ts
  function tallyVerdicts(verdicts) {
    const counts = {};
    for (const v of verdicts.values()) counts[v.state] = (counts[v.state] ?? 0) + 1;
    return counts;
  }
  function makeFilter(overrides) {
    return {
      fingerprint: ROLECAST_STUB_SCHEMA.fingerprint,
      polarity: "exclude",
      deep: false,
      saved: false,
      ...overrides
    };
  }
  function mountRenderer(filters) {
    const schema = pickStubSchema();
    if (!schema) throw new Error("mountRenderer: no stub schema matched this document");
    const itemSet = document.querySelector(schema.itemSetSelector);
    if (!itemSet) throw new Error(`mountRenderer: no item-set found for ${schema.itemSetSelector}`);
    const renderer = new Renderer({
      schema,
      itemSet,
      onRestoreToggle: (id, restored) => renderer.setRestored(id, restored)
    });
    const items = findItems(schema);
    const verdicts = evaluate(schema, items, filters);
    const summaries = renderer.apply(verdicts);
    globalThis.__nfRenderer = renderer;
    return { renderer, schema, summaries };
  }
  var api = {
    chromeStorageSchemaCache,
    classify,
    detect,
    discover,
    discoverSchema,
    distill,
    evaluate,
    findItems,
    fingerprintItemSet,
    generalize,
    getOrDiscover,
    memorySchemaCache,
    renderPageStatus,
    safeCompileRegex,
    SchemaParseError,
    UnsafeRegexError,
    Picker,
    pickStubSchema,
    Renderer,
    ROLECAST_STUB_SCHEMA,
    checkLedger,
    incrementLedger,
    memorySpendChecker,
    rollLedger,
    SpendCapError,
    suggestPhrases,
    memoryQueueIO,
    PersistentQueue,
    QUEUE_INTERNALS,
    runOne,
    Throttler,
    extractDetailFields,
    isDetailPage,
    ViewportEnqueuer,
    tallyVerdicts,
    makeFilter,
    mountRenderer
  };
  globalThis.__nf = api;
})();
//# sourceMappingURL=runtime.js.map
