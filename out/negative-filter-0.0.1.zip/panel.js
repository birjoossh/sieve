"use strict";
(() => {
  // extension/panel/components/settings.ts
  var BTN_SELECTOR = 'button[data-action="enable-site"]';
  function renderEnableButton(host, state2) {
    let btn = host.querySelector(BTN_SELECTOR);
    if (!btn) {
      btn = document.createElement("button");
      btn.dataset["action"] = "enable-site";
      btn.className = "enable-site";
      host.appendChild(btn);
    }
    if (state2.origin === null) {
      btn.textContent = "No enableable site";
      btn.disabled = true;
      btn.onclick = null;
      btn.dataset["enabled"] = "false";
      return;
    }
    const origin = state2.origin;
    btn.disabled = false;
    if (state2.enabled) {
      btn.textContent = `Disable on ${origin}`;
      btn.dataset["enabled"] = "true";
      btn.onclick = () => state2.onDisable?.(origin);
    } else {
      btn.textContent = `Enable on ${origin}`;
      btn.dataset["enabled"] = "false";
      btn.onclick = () => state2.onEnable?.(origin);
    }
  }

  // extension/panel/components/filter-list.ts
  function renderFilterList(host, state2) {
    host.replaceChildren();
    const h = document.createElement("h2");
    h.className = "section-h";
    h.textContent = "Filters";
    host.appendChild(h);
    if (!state2.enabled) {
      const p = document.createElement("p");
      p.className = "section-meta";
      p.textContent = "Enable a site with a detected list to filter.";
      host.appendChild(p);
      return;
    }
    const meta = document.createElement("p");
    meta.className = "section-meta";
    meta.textContent = "Hide items whose snippet contains any of:";
    host.appendChild(meta);
    const chips = document.createElement("div");
    chips.className = "chips";
    chips.dataset["role"] = "phrase-chips";
    for (const phrase of state2.phrases) {
      const chip = document.createElement("span");
      chip.className = "chip";
      chip.dataset["phrase"] = phrase;
      const label = document.createElement("span");
      label.className = "chip-label";
      label.textContent = phrase;
      chip.appendChild(label);
      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "chip-remove";
      remove.dataset["action"] = "remove-phrase";
      remove.dataset["phrase"] = phrase;
      remove.setAttribute("aria-label", `remove ${phrase}`);
      remove.textContent = "\xD7";
      remove.onclick = () => state2.onChange(state2.phrases.filter((p) => p !== phrase));
      chip.appendChild(remove);
      chips.appendChild(chip);
    }
    host.appendChild(chips);
    const form = document.createElement("form");
    form.className = "phrase-form";
    form.dataset["role"] = "add-phrase";
    const input = document.createElement("input");
    input.type = "text";
    input.className = "phrase-input";
    input.placeholder = "add a phrase\u2026";
    input.dataset["input"] = "phrase";
    input.autocomplete = "off";
    form.appendChild(input);
    const add = document.createElement("button");
    add.type = "submit";
    add.className = "phrase-add";
    add.textContent = "Add";
    form.appendChild(add);
    form.onsubmit = (e) => {
      e.preventDefault();
      const value = input.value.trim();
      if (value.length === 0) return;
      if (state2.phrases.includes(value)) {
        input.value = "";
        return;
      }
      state2.onChange([...state2.phrases, value]);
      input.value = "";
    };
    host.appendChild(form);
    if (state2.onSuggest) {
      const suggestRow = document.createElement("div");
      suggestRow.className = "suggest-row";
      suggestRow.dataset["role"] = "suggest-row";
      const suggestBtn = document.createElement("button");
      suggestBtn.type = "button";
      suggestBtn.className = "suggest-btn";
      suggestBtn.dataset["action"] = "suggest-phrases";
      suggestBtn.textContent = state2.suggesting ? "\u2726 \u2026" : "\u2726 Suggest phrases";
      suggestBtn.disabled = !!state2.suggesting;
      suggestBtn.onclick = () => state2.onSuggest?.();
      suggestRow.appendChild(suggestBtn);
      if (state2.suggestError) {
        const err = document.createElement("span");
        err.className = "suggest-error";
        err.dataset["role"] = "suggest-error";
        err.textContent = state2.suggestError;
        suggestRow.appendChild(err);
      }
      host.appendChild(suggestRow);
      if (state2.suggestions && state2.suggestions.length > 0) {
        const list = document.createElement("div");
        list.className = "suggest-list";
        list.dataset["role"] = "suggest-list";
        for (const s of state2.suggestions) {
          const pill = document.createElement("span");
          pill.className = "suggest-pill";
          pill.dataset["suggestion"] = s;
          const label = document.createElement("span");
          label.className = "suggest-label";
          label.textContent = s;
          pill.appendChild(label);
          const accept = document.createElement("button");
          accept.type = "button";
          accept.className = "suggest-accept";
          accept.dataset["action"] = "accept-suggestion";
          accept.dataset["suggestion"] = s;
          accept.setAttribute("aria-label", `accept ${s}`);
          accept.textContent = "+";
          accept.onclick = () => state2.onAcceptSuggestion?.(s);
          pill.appendChild(accept);
          list.appendChild(pill);
        }
        if (state2.onDismissSuggestions) {
          const dismiss = document.createElement("button");
          dismiss.type = "button";
          dismiss.className = "suggest-dismiss";
          dismiss.dataset["action"] = "dismiss-suggestions";
          dismiss.textContent = "Dismiss";
          dismiss.onclick = () => state2.onDismissSuggestions?.();
          list.appendChild(dismiss);
        }
        host.appendChild(list);
      }
    }
    if (state2.onSave) {
      const actions = document.createElement("div");
      actions.className = "filter-actions";
      actions.dataset["role"] = "save-row";
      const saveBtn = document.createElement("button");
      saveBtn.type = "button";
      saveBtn.className = "filter-save";
      saveBtn.dataset["action"] = "save-filters";
      saveBtn.textContent = "Save filters";
      saveBtn.onclick = () => state2.onSave?.();
      actions.appendChild(saveBtn);
      if (state2.onClearSaved && state2.savedExists) {
        const clearBtn = document.createElement("button");
        clearBtn.type = "button";
        clearBtn.className = "filter-clear-saved";
        clearBtn.dataset["action"] = "clear-saved-filters";
        clearBtn.textContent = "Clear saved";
        clearBtn.onclick = () => state2.onClearSaved?.();
        actions.appendChild(clearBtn);
      }
      if (state2.savedExists) {
        const badge = document.createElement("span");
        badge.className = "filter-saved-badge";
        badge.dataset["role"] = "saved-badge";
        badge.textContent = "saved";
        actions.appendChild(badge);
      }
      if (state2.onExport) {
        const exportBtn = document.createElement("button");
        exportBtn.type = "button";
        exportBtn.className = "filter-export";
        exportBtn.dataset["action"] = "export-filters";
        exportBtn.textContent = "Export";
        exportBtn.onclick = () => state2.onExport?.();
        actions.appendChild(exportBtn);
      }
      if (state2.onImport) {
        const importLabel = document.createElement("label");
        importLabel.className = "filter-import";
        importLabel.dataset["role"] = "import-row";
        importLabel.textContent = "Import ";
        const importInput = document.createElement("input");
        importInput.type = "file";
        importInput.dataset["input"] = "import-file";
        importInput.accept = "application/json,.json";
        importInput.onchange = () => {
          const file = importInput.files?.[0];
          if (file) state2.onImport?.(file);
          importInput.value = "";
        };
        importLabel.appendChild(importInput);
        actions.appendChild(importLabel);
      }
      host.appendChild(actions);
    }
  }

  // extension/panel/components/hidden-list.ts
  function renderHiddenList(host, state2) {
    host.replaceChildren();
    const hidden = state2.items.filter(
      (i) => i.state === "filtered" || i.state === "restored"
    );
    const restoredCount = hidden.filter((i) => i.state === "restored").length;
    const allRestored = hidden.length > 0 && restoredCount === hidden.length;
    const allHidden = hidden.length > 0 && restoredCount === 0;
    const h = document.createElement("h2");
    h.className = "section-h";
    h.textContent = `Hidden (${hidden.length})`;
    host.appendChild(h);
    if (hidden.length === 0) {
      const p = document.createElement("p");
      p.className = "section-meta";
      p.textContent = "Nothing hidden yet.";
      host.appendChild(p);
      return;
    }
    const bulk = document.createElement("div");
    bulk.className = "bulk-actions";
    const restoreAll = document.createElement("button");
    restoreAll.type = "button";
    restoreAll.className = "bulk-btn";
    restoreAll.dataset["action"] = "restore-all";
    restoreAll.textContent = "Restore all";
    restoreAll.disabled = allRestored;
    restoreAll.onclick = () => state2.onSetAll(true);
    bulk.appendChild(restoreAll);
    const hideAll = document.createElement("button");
    hideAll.type = "button";
    hideAll.className = "bulk-btn";
    hideAll.dataset["action"] = "hide-all";
    hideAll.textContent = "Hide all";
    hideAll.disabled = allHidden;
    hideAll.onclick = () => state2.onSetAll(false);
    bulk.appendChild(hideAll);
    host.appendChild(bulk);
    const ul = document.createElement("ul");
    ul.className = "hidden-list";
    ul.dataset["role"] = "hidden-list";
    for (const item of hidden) {
      const li = document.createElement("li");
      li.className = `hidden-row state-${item.state}`;
      li.dataset["itemId"] = item.id;
      li.dataset["state"] = item.state;
      const label = document.createElement("span");
      label.className = "item-label";
      label.textContent = item.label ?? item.id;
      li.appendChild(label);
      if (item.reason !== void 0) {
        const reason = document.createElement("span");
        reason.className = "item-reason";
        reason.textContent = ` \u2014 ${item.reason}`;
        li.appendChild(reason);
      }
      const restored = item.state === "restored";
      const toggle = document.createElement("button");
      toggle.type = "button";
      toggle.className = "row-toggle";
      toggle.dataset["action"] = restored ? "hide" : "restore";
      toggle.dataset["itemId"] = item.id;
      toggle.textContent = restored ? "hide" : "restore";
      toggle.onclick = () => state2.onSetItem(item.id, !restored);
      li.appendChild(toggle);
      ul.appendChild(li);
    }
    host.appendChild(ul);
  }

  // extension/panel/components/llm-settings.ts
  var PROVIDERS = ["anthropic", "openai"];
  var PROVIDER_LABEL = {
    anthropic: "Anthropic",
    openai: "OpenAI"
  };
  function renderLlmSettings(host, state2) {
    host.innerHTML = "";
    const fieldset = document.createElement("fieldset");
    fieldset.className = "llm-settings";
    fieldset.dataset["role"] = "llm-settings";
    const legend = document.createElement("legend");
    legend.textContent = "LLM provider (BYO key)";
    fieldset.appendChild(legend);
    const providerRow = document.createElement("label");
    providerRow.className = "llm-row";
    providerRow.textContent = "Provider: ";
    const select = document.createElement("select");
    select.dataset["input"] = "provider";
    for (const p of PROVIDERS) {
      const opt = document.createElement("option");
      opt.value = p;
      opt.textContent = PROVIDER_LABEL[p];
      if (state2.current?.provider === p) opt.selected = true;
      select.appendChild(opt);
    }
    if (state2.current === null) {
      select.value = "anthropic";
    }
    providerRow.appendChild(select);
    fieldset.appendChild(providerRow);
    const keyRow = document.createElement("label");
    keyRow.className = "llm-row";
    keyRow.textContent = "API key: ";
    const keyInput = document.createElement("input");
    keyInput.type = "password";
    keyInput.dataset["input"] = "api-key";
    keyInput.placeholder = "sk-...";
    keyInput.value = state2.current?.apiKey ?? "";
    keyInput.autocomplete = "off";
    keyRow.appendChild(keyInput);
    fieldset.appendChild(keyRow);
    const modelRow = document.createElement("label");
    modelRow.className = "llm-row";
    modelRow.textContent = "Model (optional): ";
    const modelInput = document.createElement("input");
    modelInput.type = "text";
    modelInput.dataset["input"] = "model";
    modelInput.placeholder = "default";
    modelInput.value = state2.current?.model ?? "";
    modelRow.appendChild(modelInput);
    fieldset.appendChild(modelRow);
    const baseUrlRow = document.createElement("label");
    baseUrlRow.className = "llm-row";
    baseUrlRow.textContent = "Base URL (optional): ";
    const baseUrlInput = document.createElement("input");
    baseUrlInput.type = "text";
    baseUrlInput.dataset["input"] = "base-url";
    baseUrlInput.placeholder = "https://api.anthropic.com or https://openrouter.ai/api";
    baseUrlInput.value = state2.current?.baseUrl ?? "";
    baseUrlInput.autocomplete = "off";
    baseUrlRow.appendChild(baseUrlInput);
    fieldset.appendChild(baseUrlRow);
    const buttons = document.createElement("div");
    buttons.className = "llm-actions";
    const saveBtn = document.createElement("button");
    saveBtn.type = "button";
    saveBtn.className = "llm-save";
    saveBtn.dataset["action"] = "save-llm-settings";
    saveBtn.textContent = "Save";
    saveBtn.addEventListener("click", () => {
      const next = {
        provider: select.value,
        apiKey: keyInput.value
      };
      const model = modelInput.value.trim();
      if (model !== "") next.model = model;
      const baseUrl = baseUrlInput.value.trim();
      if (baseUrl !== "") next.baseUrl = baseUrl;
      state2.onSave(next);
    });
    buttons.appendChild(saveBtn);
    if (state2.onClear) {
      const clearBtn = document.createElement("button");
      clearBtn.type = "button";
      clearBtn.className = "llm-clear";
      clearBtn.dataset["action"] = "clear-llm-settings";
      clearBtn.textContent = "Clear";
      clearBtn.addEventListener("click", () => state2.onClear?.());
      buttons.appendChild(clearBtn);
    }
    fieldset.appendChild(buttons);
    const status = document.createElement("span");
    status.className = "llm-status";
    status.dataset["role"] = "llm-status";
    status.textContent = state2.current === null ? "(not configured)" : "(saved)";
    fieldset.appendChild(status);
    if (state2.spend) {
      const usage = document.createElement("p");
      usage.className = "llm-spend";
      usage.dataset["role"] = "spend-usage";
      usage.textContent = `${state2.spend.dailyUsed} / ${state2.spend.dailyCap} today \xB7 ${state2.spend.monthlyUsed} / ${state2.spend.monthlyCap} this month`;
      fieldset.appendChild(usage);
      if (state2.spend.capReached) {
        const warn = document.createElement("p");
        warn.className = "llm-spend-warn";
        warn.dataset["role"] = "spend-cap-warning";
        warn.textContent = state2.spend.cappedPeriod === "day" ? "Daily spend cap reached \u2014 discovery calls are paused until tomorrow." : "Monthly spend cap reached \u2014 discovery calls are paused until next month.";
        fieldset.appendChild(warn);
      }
    }
    host.appendChild(fieldset);
  }

  // extension/panel/components/numeric-filter.ts
  var OP_LABELS = {
    lessThan: "<",
    greaterThan: ">"
  };
  function renderNumericFilter(host, state2) {
    host.replaceChildren();
    const h = document.createElement("h2");
    h.className = "section-h";
    h.textContent = "Numeric filter";
    host.appendChild(h);
    if (!state2.enabled) {
      const p = document.createElement("p");
      p.className = "section-meta";
      p.textContent = "Enable a site with numeric fields to filter.";
      host.appendChild(p);
      return;
    }
    const enableRow = document.createElement("label");
    enableRow.className = "numeric-enable";
    const enableInput = document.createElement("input");
    enableInput.type = "checkbox";
    enableInput.dataset["input"] = "numeric-enabled";
    enableInput.checked = state2.current.enabled;
    enableInput.onchange = () => {
      state2.onChange({ ...state2.current, enabled: enableInput.checked });
    };
    enableRow.appendChild(enableInput);
    enableRow.appendChild(document.createTextNode(" Filter by comp"));
    host.appendChild(enableRow);
    const sliderRow = document.createElement("div");
    sliderRow.className = "numeric-row";
    sliderRow.dataset["role"] = "numeric-slider-row";
    const opSelect = document.createElement("select");
    opSelect.className = "numeric-op";
    opSelect.dataset["input"] = "numeric-op";
    for (const op of ["lessThan", "greaterThan"]) {
      const opt = document.createElement("option");
      opt.value = op;
      opt.textContent = OP_LABELS[op];
      if (op === state2.current.op) opt.selected = true;
      opSelect.appendChild(opt);
    }
    opSelect.onchange = () => {
      state2.onChange({ ...state2.current, op: opSelect.value });
    };
    sliderRow.appendChild(opSelect);
    const slider = document.createElement("input");
    slider.type = "range";
    slider.className = "numeric-slider";
    slider.dataset["input"] = "numeric-value";
    slider.min = String(state2.min);
    slider.max = String(state2.max);
    slider.step = String(state2.step);
    slider.value = String(state2.current.value);
    slider.oninput = () => {
      const n = Number(slider.value);
      if (Number.isFinite(n)) {
        readout.textContent = `${n} ${state2.unit}`;
        state2.onChange({ ...state2.current, value: n });
      }
    };
    sliderRow.appendChild(slider);
    const readout = document.createElement("span");
    readout.className = "numeric-readout";
    readout.dataset["role"] = "numeric-readout";
    readout.textContent = `${state2.current.value} ${state2.unit}`;
    sliderRow.appendChild(readout);
    host.appendChild(sliderRow);
  }

  // extension/panel/components/page-status.ts
  function renderPageStatus(host, state2) {
    host.replaceChildren();
    const h = document.createElement("h2");
    h.className = "section-h";
    h.textContent = "Page";
    host.appendChild(h);
    const status = document.createElement("p");
    status.className = "section-meta";
    if (state2.schema) {
      status.textContent = `Detected: ${state2.schema.layout} \xB7 ${state2.itemCount} item${state2.itemCount === 1 ? "" : "s"}`;
    } else {
      status.textContent = "No list detected.";
    }
    host.appendChild(status);
    if (!state2.schema) return;
    const toggle = document.createElement("div");
    toggle.className = "mode-toggle";
    toggle.dataset["role"] = "display-mode";
    toggle.setAttribute("role", "group");
    toggle.setAttribute("aria-label", "Display mode");
    for (const m of ["collapse", "hide"]) {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "mode-btn";
      btn.dataset["mode"] = m;
      btn.textContent = m === "collapse" ? "Collapse" : "Hide";
      btn.setAttribute("aria-pressed", String(state2.mode === m));
      if (state2.mode === m) btn.classList.add("active");
      btn.onclick = () => state2.onModeChange(m);
      toggle.appendChild(btn);
    }
    host.appendChild(toggle);
    if (state2.onRediscover) {
      const rediscoverHandler = state2.onRediscover;
      const rediscover = document.createElement("div");
      rediscover.className = "rediscover";
      rediscover.dataset["role"] = "rediscover";
      const hintInput = document.createElement("input");
      hintInput.type = "text";
      hintInput.dataset["input"] = "rediscover-hint";
      hintInput.placeholder = 'Hint (optional, e.g. "title is in the h3")';
      hintInput.className = "rediscover-hint";
      rediscover.appendChild(hintInput);
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "rediscover-btn";
      btn.dataset["action"] = "rediscover";
      btn.textContent = "Re-discover";
      btn.addEventListener("click", () => {
        const hint = hintInput.value.trim();
        const payload = { force: true };
        if (hint !== "") payload.hint = hint;
        rediscoverHandler(payload);
      });
      rediscover.appendChild(btn);
      host.appendChild(rediscover);
    }
  }

  // extension/shared/settings.ts
  var STORAGE_KEY = "nf:llm-settings";
  async function loadLlmSettings() {
    const r = await chrome.storage.local.get([STORAGE_KEY]);
    const v = r[STORAGE_KEY];
    if (!v || typeof v !== "object") return null;
    const obj = v;
    if (obj["provider"] !== "anthropic" && obj["provider"] !== "openai") return null;
    if (typeof obj["apiKey"] !== "string") return null;
    const out = {
      provider: obj["provider"],
      apiKey: obj["apiKey"]
    };
    if (typeof obj["model"] === "string" && obj["model"].trim() !== "") {
      out.model = obj["model"];
    }
    if (typeof obj["baseUrl"] === "string" && obj["baseUrl"].trim() !== "") {
      out.baseUrl = obj["baseUrl"].trim();
    }
    return out;
  }
  async function saveLlmSettings(settings) {
    await chrome.storage.local.set({ [STORAGE_KEY]: settings });
  }
  async function clearLlmSettings() {
    await chrome.storage.local.remove(STORAGE_KEY);
  }

  // extension/shared/saved-filters.ts
  var KEY_PREFIX = "nf:filters:";
  function keyFor(fingerprint) {
    return KEY_PREFIX + fingerprint;
  }
  function isFilterShape(x) {
    if (typeof x !== "object" || x === null) return false;
    const r = x;
    if (typeof r["id"] !== "string") return false;
    if (typeof r["fingerprint"] !== "string") return false;
    if (r["polarity"] !== "exclude" && r["polarity"] !== "keep") return false;
    if (typeof r["field"] !== "string") return false;
    if (typeof r["predicate"] !== "object" || r["predicate"] === null) return false;
    if (typeof r["deep"] !== "boolean") return false;
    if (typeof r["saved"] !== "boolean") return false;
    return true;
  }
  async function loadSavedFilters(fingerprint) {
    const key = keyFor(fingerprint);
    const r = await chrome.storage.sync.get(key);
    const raw = r[key];
    if (!Array.isArray(raw)) return [];
    return raw.filter(isFilterShape);
  }
  async function saveFilters(fingerprint, filters) {
    const saved = filters.map((f) => ({ ...f, saved: true }));
    await chrome.storage.sync.set({ [keyFor(fingerprint)]: saved });
  }
  async function clearSavedFilters(fingerprint) {
    await chrome.storage.sync.remove(keyFor(fingerprint));
  }

  // extension/shared/filter-io.ts
  var FILTER_EXPORT_VERSION = 1;
  function serializeExport(sets, now) {
    const env = {
      v: FILTER_EXPORT_VERSION,
      exportedAt: now,
      sets
    };
    return JSON.stringify(env, null, 2);
  }
  function parseExport(raw) {
    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch (err) {
      throw new Error(`import: not valid JSON \u2014 ${err instanceof Error ? err.message : err}`);
    }
    if (typeof parsed !== "object" || parsed === null) {
      throw new Error("import: top-level value is not an object");
    }
    const r = parsed;
    if (r["v"] !== FILTER_EXPORT_VERSION) {
      throw new Error(`import: unsupported version ${String(r["v"])}`);
    }
    if (typeof r["sets"] !== "object" || r["sets"] === null) {
      throw new Error('import: missing "sets" object');
    }
    const sets = r["sets"];
    const out = {};
    for (const [fp, value] of Object.entries(sets)) {
      if (!Array.isArray(value)) continue;
      out[fp] = value;
    }
    return {
      v: FILTER_EXPORT_VERSION,
      exportedAt: typeof r["exportedAt"] === "number" ? r["exportedAt"] : 0,
      sets: out
    };
  }

  // extension/background/spend.ts
  var DEFAULT_CAPS = { daily: 50, monthly: 1e3 };
  var STORAGE_KEY2 = "nf:spend-ledger";
  var MS_PER_DAY = 24 * 60 * 60 * 1e3;
  function epochDay(now) {
    return Math.floor(now / MS_PER_DAY);
  }
  function epochMonth(now) {
    const d = new Date(now);
    return d.getUTCFullYear() * 12 + d.getUTCMonth();
  }
  function emptyLedger(now) {
    return {
      dailyEpoch: epochDay(now),
      dailyCount: 0,
      monthlyEpoch: epochMonth(now),
      monthlyCount: 0
    };
  }
  function rollLedger(ledger, now) {
    const d = epochDay(now);
    const m = epochMonth(now);
    let next = ledger;
    if (d !== ledger.dailyEpoch) {
      next = { ...next, dailyEpoch: d, dailyCount: 0 };
    }
    if (m !== ledger.monthlyEpoch) {
      next = { ...next, monthlyEpoch: m, monthlyCount: 0 };
    }
    return next;
  }
  function checkLedger(ledger, caps, now) {
    const rolled = rollLedger(ledger, now);
    if (rolled.dailyCount >= caps.daily) {
      return { ok: false, reason: "spend-cap-reached", period: "day" };
    }
    if (rolled.monthlyCount >= caps.monthly) {
      return { ok: false, reason: "spend-cap-reached", period: "month" };
    }
    return { ok: true };
  }
  async function loadLedger(now = Date.now()) {
    const r = await chrome.storage.local.get(STORAGE_KEY2);
    const raw = r[STORAGE_KEY2];
    if (!raw || typeof raw !== "object") return emptyLedger(now);
    const obj = raw;
    if (typeof obj["dailyEpoch"] !== "number" || typeof obj["dailyCount"] !== "number" || typeof obj["monthlyEpoch"] !== "number" || typeof obj["monthlyCount"] !== "number") {
      return emptyLedger(now);
    }
    return rollLedger(
      {
        dailyEpoch: obj["dailyEpoch"],
        dailyCount: obj["dailyCount"],
        monthlyEpoch: obj["monthlyEpoch"],
        monthlyCount: obj["monthlyCount"]
      },
      now
    );
  }
  async function getSpendStatus(now = Date.now(), caps = DEFAULT_CAPS) {
    const ledger = rollLedger(await loadLedger(now), now);
    const check = checkLedger(ledger, caps, now);
    return {
      dailyUsed: ledger.dailyCount,
      dailyCap: caps.daily,
      monthlyUsed: ledger.monthlyCount,
      monthlyCap: caps.monthly,
      capReached: !check.ok,
      cappedPeriod: check.ok ? null : check.period
    };
  }
  var SpendCapError = class extends Error {
    reason = "spend-cap-reached";
    period;
    constructor(period) {
      super(`spend-cap-reached:${period}`);
      this.name = "SpendCapError";
      this.period = period;
    }
  };

  // extension/background/llm.ts
  var SchemaParseError = class extends Error {
    reason;
    raw;
    constructor(reason, raw) {
      super(`SchemaParseError: ${reason}`);
      this.name = "SchemaParseError";
      this.reason = reason;
      this.raw = raw === void 0 ? void 0 : raw.slice(0, 500);
    }
  };
  var DEFAULT_MODEL = {
    anthropic: "claude-sonnet-4-5",
    openai: "gpt-4o"
  };
  function extractJsonObject(text) {
    const trimmed = text.trim();
    const fence = trimmed.match(/^```(?:json)?\s*([\s\S]*?)\s*```\s*$/);
    if (fence?.[1]) return fence[1].trim();
    const first = trimmed.indexOf("{");
    const last = trimmed.lastIndexOf("}");
    if (first >= 0 && last > first) return trimmed.slice(first, last + 1);
    return trimmed;
  }
  function joinUrl(base, path) {
    return `${base.replace(/\/+$/, "")}/${path.replace(/^\/+/, "")}`;
  }
  async function callAnthropic(prompt, opts, fetcher) {
    const base = opts.baseUrl ?? "https://api.anthropic.com";
    const res = await fetcher(joinUrl(base, "/v1/messages"), {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": opts.apiKey,
        authorization: `Bearer ${opts.apiKey}`,
        "anthropic-version": "2023-06-01",
        "anthropic-dangerous-direct-browser-access": "true"
      },
      body: JSON.stringify({
        model: opts.model ?? DEFAULT_MODEL.anthropic,
        max_tokens: 1024,
        messages: [{ role: "user", content: prompt }]
      })
    });
    if (!res.ok) {
      const body = await res.text().catch(() => "");
      throw new SchemaParseError(`Anthropic ${res.status}: ${body.slice(0, 200)}`, body);
    }
    const json = await res.json();
    const text = (json.content ?? []).filter((b) => b.type === "text" && typeof b.text === "string").map((b) => b.text).join("");
    if (text === "") {
      throw new SchemaParseError("Anthropic response had no text content", JSON.stringify(json));
    }
    return { text };
  }
  async function callOpenAI(prompt, opts, fetcher) {
    const base = opts.baseUrl ?? "https://api.openai.com";
    const res = await fetcher(joinUrl(base, "/v1/chat/completions"), {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${opts.apiKey}`
      },
      body: JSON.stringify({
        model: opts.model ?? DEFAULT_MODEL.openai,
        messages: [{ role: "user", content: prompt }]
      })
    });
    if (!res.ok) {
      const body = await res.text().catch(() => "");
      throw new SchemaParseError(`OpenAI ${res.status}: ${body.slice(0, 200)}`, body);
    }
    const json = await res.json();
    const text = json.choices?.[0]?.message?.content ?? "";
    if (text === "") {
      throw new SchemaParseError("OpenAI response had no content", JSON.stringify(json));
    }
    return { text };
  }
  var SUGGEST_PROMPT_HEADER = `You suggest additional phrases that match the user's exclusion intent.

Output ONLY a single JSON object with this exact shape:
{ "suggestions": ["phrase one", "phrase two", ...] }

Suggest up to 6 short, distinct phrases. Don't repeat anything in "existing". Each phrase should be a literal substring that would appear in an item's text \u2014 not regex, not bullet syntax.`;
  function buildSuggestPrompt(opts) {
    const existing = opts.existing.length === 0 ? "(none yet)" : opts.existing.join(", ");
    return `${SUGGEST_PROMPT_HEADER}

Intent: ${opts.intent}
Existing phrases: ${existing}`;
  }
  function parseSuggestions(raw) {
    const obj = JSON.parse(extractJsonObject(raw));
    if (!Array.isArray(obj.suggestions)) {
      throw new SchemaParseError("suggestions field missing or not an array", raw);
    }
    const out = [];
    for (const v of obj.suggestions) {
      if (typeof v !== "string") continue;
      const trimmed = v.trim();
      if (trimmed.length > 0 && trimmed.length <= 80) out.push(trimmed);
    }
    return out;
  }
  async function suggestPhrases(opts) {
    const fetcher = opts.fetcher ?? globalThis.fetch;
    const now = opts.now ?? Date.now;
    if (opts.spend) {
      const check = await opts.spend.canSpend(now());
      if (!check.ok) throw new SpendCapError(check.period);
    }
    const prompt = buildSuggestPrompt(opts);
    const callOpts = {
      provider: opts.provider,
      apiKey: opts.apiKey,
      // Suggestions are fingerprint-agnostic. We pass a synthetic value
      // so we can reuse the provider plumbing without forking it.
      fingerprint: "suggest",
      ...opts.model !== void 0 ? { model: opts.model } : {},
      fetcher
    };
    const result = opts.provider === "anthropic" ? await callAnthropic(prompt, callOpts, fetcher) : await callOpenAI(prompt, callOpts, fetcher);
    let suggestions;
    try {
      suggestions = parseSuggestions(result.text);
    } catch (err) {
      if (err instanceof SchemaParseError) throw err;
      const msg = err instanceof Error ? err.message : String(err);
      throw new SchemaParseError(`suggestions response is not valid JSON: ${msg}`, result.text);
    }
    if (opts.spend) await opts.spend.recordSpend(now());
    const seen = new Set(opts.existing.map((p) => p.toLowerCase()));
    const out = [];
    for (const s of suggestions) {
      const k = s.toLowerCase();
      if (seen.has(k)) continue;
      seen.add(k);
      out.push(s);
    }
    return out;
  }

  // extension/shared/deep-prefs.ts
  var STORAGE_KEY3 = "nf:deep-warning-dismissed";
  async function isDeepWarningDismissed() {
    const r = await chrome.storage.local.get(STORAGE_KEY3);
    return r[STORAGE_KEY3] === true;
  }
  async function dismissDeepWarning() {
    await chrome.storage.local.set({ [STORAGE_KEY3]: true });
  }

  // extension/panel/components/deep-toggle.ts
  function renderDeepToggle(host, state2) {
    host.replaceChildren();
    if (!state2.enabled) return;
    const row = document.createElement("label");
    row.className = "deep-toggle";
    row.dataset["role"] = "deep-toggle-row";
    const input = document.createElement("input");
    input.type = "checkbox";
    input.dataset["input"] = "deep-scan";
    input.checked = state2.deepOn;
    input.onchange = () => state2.onToggleDeep(input.checked);
    row.appendChild(input);
    row.appendChild(document.createTextNode(" Deep scan (opens hidden tabs)"));
    host.appendChild(row);
    if (state2.modalOpen) {
      const modal = document.createElement("div");
      modal.className = "deep-modal";
      modal.dataset["role"] = "deep-warning-modal";
      modal.setAttribute("role", "dialog");
      modal.setAttribute("aria-modal", "true");
      const title = document.createElement("h3");
      title.className = "deep-modal-title";
      title.textContent = "Deep scan opens hidden tabs";
      modal.appendChild(title);
      const body = document.createElement("p");
      body.className = "deep-modal-body";
      body.textContent = "Deep filters fetch each item\u2019s detail page in a hidden background tab. Some sites prohibit automated access in their Terms of Service \u2014 using deep scan there may violate those terms. You alone are responsible for compliance with the sites you visit.";
      modal.appendChild(body);
      const dismiss = document.createElement("button");
      dismiss.type = "button";
      dismiss.className = "deep-modal-dismiss";
      dismiss.dataset["action"] = "dismiss-deep-warning";
      dismiss.textContent = "I understand";
      dismiss.onclick = () => state2.onDismissWarning();
      modal.appendChild(dismiss);
      host.appendChild(modal);
    }
  }

  // extension/panel/components/error-panel.ts
  var TITLES = {
    "missing-schema": "No filterable list on this page",
    "spend-cap": "Spend cap reached",
    "llm-error": "LLM call failed",
    "unsafe-regex": "Filter regex rejected"
  };
  var HINTS = {
    "missing-schema": "Use Re-discover (above) with a one-line hint like \u201Cjob cards in the main column\u201D to teach the layout.",
    "spend-cap": "Discovery calls are paused until the cap window resets. Use saved filters in the meantime.",
    "llm-error": "Re-try; if it persists, recheck your provider key under LLM provider.",
    "unsafe-regex": "The filter regex was rejected by the safety pre-check (length or nested quantifier). Tighten the pattern."
  };
  function renderErrorPanel(host, state2) {
    host.replaceChildren();
    if (state2.errors.length === 0) return;
    const h = document.createElement("h2");
    h.className = "section-h";
    h.textContent = "Heads up";
    host.appendChild(h);
    for (const err of state2.errors) {
      const row = document.createElement("div");
      row.className = `panel-error error-${err.kind}`;
      row.dataset["error"] = err.kind;
      row.setAttribute("role", "status");
      const title = document.createElement("strong");
      title.className = "panel-error-title";
      title.textContent = TITLES[err.kind];
      row.appendChild(title);
      const msg = document.createElement("p");
      msg.className = "panel-error-message";
      msg.textContent = err.message;
      row.appendChild(msg);
      const hint = document.createElement("p");
      hint.className = "panel-error-hint";
      hint.textContent = HINTS[err.kind];
      row.appendChild(hint);
      host.appendChild(row);
    }
  }

  // extension/shared/types.ts
  var MESSAGE_VERSION = 1;
  function hasShape(x) {
    return typeof x === "object" && x !== null && "t" in x && "v" in x;
  }
  function hasStringField(x, key) {
    return key in x && typeof x[key] === "string";
  }
  function isSwToPanel(x) {
    if (!hasShape(x)) return false;
    if (x.v !== MESSAGE_VERSION) return false;
    const r = x;
    switch (x.t) {
      case "pong":
      case "ack":
        return true;
      case "err":
        return hasStringField(x, "message");
      case "schema":
        return typeof r["schema"] === "object" && r["schema"] !== null;
      default:
        return false;
    }
  }
  function isContentReply(x) {
    if (!hasShape(x)) return false;
    if (x.v !== MESSAGE_VERSION) return false;
    const r = x;
    switch (x.t) {
      case "ack":
        return true;
      case "err":
        return hasStringField(x, "message");
      case "state":
        return typeof r["state"] === "object" && r["state"] !== null;
      default:
        return false;
    }
  }
  function isContentToPanel(x) {
    if (!hasShape(x)) return false;
    if (x.v !== MESSAGE_VERSION) return false;
    const r = x;
    switch (x.t) {
      case "itemStates":
        return Array.isArray(r["items"]);
      case "pageDetected":
        return hasStringField(x, "fingerprint") && typeof r["count"] === "number";
      case "discoverError":
        return hasStringField(x, "message");
      default:
        return false;
    }
  }
  function scriptIdFor(origin) {
    return `nf:${origin}`;
  }
  function originMatchPattern(origin) {
    return `${origin}/*`;
  }
  async function sendToSw(msg) {
    const reply = await chrome.runtime.sendMessage(msg);
    if (!isSwToPanel(reply)) {
      throw new Error(`SW returned malformed reply: ${JSON.stringify(reply)}`);
    }
    return reply;
  }
  async function sendToContent(tabId, msg) {
    const reply = await chrome.tabs.sendMessage(tabId, msg);
    if (!isContentReply(reply)) {
      throw new Error(`content returned malformed reply: ${JSON.stringify(reply)}`);
    }
    return reply;
  }

  // extension/panel/panel.ts
  var SLICE1_FILTER_ID = "panel-phrase-filter";
  var NUMERIC_FILTER_ID = "panel-numeric-filter";
  var NUMERIC_FIELD = "comp";
  var NUMERIC_DEFAULT = {
    enabled: false,
    op: "lessThan",
    value: 100
  };
  var state = {
    activeTabId: null,
    origin: null,
    enabled: false,
    schema: null,
    phrases: [],
    numeric: { ...NUMERIC_DEFAULT },
    mode: "collapse",
    items: [],
    llmSettings: null,
    savedExists: false,
    spend: null,
    suggesting: false,
    suggestions: [],
    suggestError: null,
    discoverError: null,
    deepOn: false,
    deepWarningDismissed: false,
    deepModalOpen: false
  };
  var ENABLEABLE_PROTOCOLS = /* @__PURE__ */ new Set(["http:", "https:"]);
  function originOf(tab) {
    if (!tab?.url) return null;
    try {
      const url = new URL(tab.url);
      if (!ENABLEABLE_PROTOCOLS.has(url.protocol)) return null;
      return url.origin;
    } catch {
      return null;
    }
  }
  async function activeContentTab() {
    const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    return tabs[0];
  }
  async function isOriginEnabled(origin) {
    const id = scriptIdFor(origin);
    const scripts = await chrome.scripting.getRegisteredContentScripts({ ids: [id] });
    return scripts.length > 0;
  }
  function buildFilters(schema, phrases, numeric) {
    if (!schema) return [];
    const out = [];
    if (phrases.length > 0) {
      out.push({
        id: SLICE1_FILTER_ID,
        fingerprint: schema.fingerprint,
        polarity: "exclude",
        field: "snippet",
        predicate: { op: "containsAny", phrases },
        deep: false,
        saved: false
      });
    }
    if (numeric.enabled && schema.fields[NUMERIC_FIELD]) {
      out.push({
        id: NUMERIC_FILTER_ID,
        fingerprint: schema.fingerprint,
        polarity: "exclude",
        field: NUMERIC_FIELD,
        predicate: numeric.op === "lessThan" ? { op: "lessThan", value: numeric.value } : { op: "greaterThan", value: numeric.value },
        deep: false,
        saved: false
      });
    }
    return out;
  }
  async function pushFilters() {
    if (state.activeTabId === null) return;
    const filters = buildFilters(state.schema, state.phrases, state.numeric);
    try {
      await sendToContent(state.activeTabId, {
        t: "setFilters",
        v: MESSAGE_VERSION,
        filters
      });
    } catch (err) {
      console.error("[negative-filter] setFilters failed:", err);
    }
  }
  async function pushPhrases(phrases) {
    state.phrases = phrases;
    await pushFilters();
    render();
  }
  async function pushNumeric(next) {
    state.numeric = next;
    await pushFilters();
    render();
  }
  async function pushMode(mode) {
    state.mode = mode;
    if (state.activeTabId === null) {
      render();
      return;
    }
    try {
      await sendToContent(state.activeTabId, {
        t: "setDisplayMode",
        v: MESSAGE_VERSION,
        mode
      });
    } catch (err) {
      console.error("[negative-filter] setDisplayMode failed:", err);
    }
    render();
  }
  async function pushItemRestored(id, restored) {
    if (state.activeTabId === null) return;
    try {
      await sendToContent(state.activeTabId, {
        t: "setItemRestored",
        v: MESSAGE_VERSION,
        itemId: id,
        restored
      });
    } catch (err) {
      console.error("[negative-filter] setItemRestored failed:", err);
    }
  }
  async function pushAllRestored(restored) {
    const targets = state.items.filter((i) => restored ? i.state === "filtered" : i.state === "restored").map((i) => i.id);
    await Promise.all(targets.map((id) => pushItemRestored(id, restored)));
  }
  async function handleEnable(origin) {
    const granted = await chrome.permissions.request({
      origins: [originMatchPattern(origin)]
    });
    if (!granted) return;
    const reply = await sendToSw({ t: "enableDomain", v: MESSAGE_VERSION, origin });
    if (reply.t === "err") {
      console.error("[negative-filter] enableDomain failed:", reply.message);
      return;
    }
    void refresh();
  }
  async function handleDisable(origin) {
    const reply = await sendToSw({ t: "disableDomain", v: MESSAGE_VERSION, origin });
    if (reply.t === "err") {
      console.error("[negative-filter] disableDomain failed:", reply.message);
      return;
    }
    await chrome.permissions.remove({ origins: [originMatchPattern(origin)] }).catch(() => void 0);
    void refresh();
  }
  async function refresh() {
    const tab = await activeContentTab();
    state.activeTabId = tab?.id ?? null;
    state.origin = originOf(tab);
    state.enabled = state.origin === null ? false : await isOriginEnabled(state.origin);
    state.llmSettings = await loadLlmSettings();
    if (state.activeTabId !== null && state.enabled) {
      try {
        const reply = await sendToContent(state.activeTabId, {
          t: "getState",
          v: MESSAGE_VERSION
        });
        if (reply.t === "state") {
          state.schema = reply.state.schema;
          state.mode = reply.state.mode;
          state.items = reply.state.items;
          const phraseFilter = reply.state.filters.find(
            (f) => f.id === SLICE1_FILTER_ID && f.predicate.op === "containsAny"
          );
          state.phrases = phraseFilter && phraseFilter.predicate.op === "containsAny" ? [...phraseFilter.predicate.phrases] : [];
          const numericFilter = reply.state.filters.find((f) => f.id === NUMERIC_FILTER_ID);
          if (numericFilter && (numericFilter.predicate.op === "lessThan" || numericFilter.predicate.op === "greaterThan")) {
            state.numeric = {
              enabled: true,
              op: numericFilter.predicate.op,
              value: numericFilter.predicate.value
            };
          } else {
            state.numeric = { ...NUMERIC_DEFAULT };
          }
        } else if (reply.t === "err") {
          state.schema = null;
          state.items = [];
        }
      } catch {
        state.schema = null;
        state.items = [];
      }
    } else {
      state.schema = null;
      state.items = [];
      state.phrases = [];
    }
    try {
      state.deepWarningDismissed = await isDeepWarningDismissed();
    } catch {
      state.deepWarningDismissed = false;
    }
    try {
      state.spend = await getSpendStatus();
    } catch {
      state.spend = null;
    }
    if (state.schema) {
      try {
        const saved = await loadSavedFilters(state.schema.fingerprint);
        state.savedExists = saved.length > 0;
      } catch {
        state.savedExists = false;
      }
    } else {
      state.savedExists = false;
    }
    render();
  }
  async function handleSuggest() {
    if (state.suggesting) return;
    if (!state.llmSettings || state.llmSettings.apiKey.trim() === "") {
      state.suggestError = "Add a provider key in LLM settings to fetch suggestions.";
      render();
      return;
    }
    state.suggesting = true;
    state.suggestError = null;
    render();
    try {
      const fetcher = globalThis.__nfFetcher;
      const next = await suggestPhrases({
        provider: state.llmSettings.provider,
        apiKey: state.llmSettings.apiKey,
        existing: state.phrases,
        intent: "phrases to add to a negative filter on this page",
        ...state.llmSettings.model !== void 0 ? { model: state.llmSettings.model } : {},
        ...fetcher ? { fetcher } : {}
      });
      state.suggestions = next;
    } catch (err) {
      state.suggestError = err instanceof Error ? err.message : String(err);
    } finally {
      state.suggesting = false;
      render();
    }
  }
  function handleAcceptSuggestion(phrase) {
    if (state.phrases.includes(phrase)) {
      state.suggestions = state.suggestions.filter((s) => s !== phrase);
      render();
      return;
    }
    state.suggestions = state.suggestions.filter((s) => s !== phrase);
    void pushPhrases([...state.phrases, phrase]);
  }
  function handleDismissSuggestions() {
    state.suggestions = [];
    state.suggestError = null;
    render();
  }
  function handleToggleDeep(next) {
    state.deepOn = next;
    if (next && !state.deepWarningDismissed) {
      state.deepModalOpen = true;
    }
    render();
  }
  async function handleDismissDeepWarning() {
    try {
      await dismissDeepWarning();
    } catch (err) {
      console.error("[negative-filter] dismissDeepWarning failed:", err);
    }
    state.deepWarningDismissed = true;
    state.deepModalOpen = false;
    render();
  }
  async function handleSaveFilters() {
    if (!state.schema) return;
    const filters = buildFilters(state.schema, state.phrases, state.numeric);
    await saveFilters(state.schema.fingerprint, filters);
    state.savedExists = true;
    render();
  }
  async function handleExportFilters() {
    const all = await chrome.storage.sync.get(null);
    const sets = {};
    for (const [k, v] of Object.entries(all)) {
      if (!k.startsWith("nf:filters:")) continue;
      if (!Array.isArray(v)) continue;
      sets[k.replace(/^nf:filters:/, "")] = v;
    }
    const json = serializeExport(sets, Date.now());
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `negative-filter-export-${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1e3);
  }
  async function handleImportFilters(file) {
    let env;
    try {
      const text = await file.text();
      env = parseExport(text);
    } catch (err) {
      console.error("[negative-filter] import failed:", err);
      return;
    }
    for (const [fp, set] of Object.entries(env.sets)) {
      await saveFilters(fp, set);
    }
    void refresh();
  }
  async function handleClearSavedFilters() {
    if (!state.schema) return;
    await clearSavedFilters(state.schema.fingerprint);
    state.savedExists = false;
    render();
  }
  async function handleSaveLlmSettings(next) {
    await saveLlmSettings(next);
    state.llmSettings = next;
    render();
  }
  async function handleClearLlmSettings() {
    await clearLlmSettings();
    state.llmSettings = null;
    render();
  }
  function render() {
    const settingsHost = document.getElementById("settings");
    if (settingsHost) {
      renderEnableButton(settingsHost, {
        origin: state.origin,
        enabled: state.enabled,
        onEnable: handleEnable,
        onDisable: handleDisable
      });
    }
    const llmHost = document.getElementById("llm-settings");
    if (llmHost) {
      renderLlmSettings(llmHost, {
        current: state.llmSettings,
        onSave: (next) => void handleSaveLlmSettings(next),
        onClear: () => void handleClearLlmSettings(),
        ...state.spend ? { spend: state.spend } : {}
      });
    }
    const pageHost = document.getElementById("page-status");
    if (pageHost) {
      renderPageStatus(pageHost, {
        schema: state.schema,
        itemCount: state.items.length,
        mode: state.mode,
        onModeChange: (m) => void pushMode(m),
        // Slice 3.5 + production wire-up: send rediscover to content,
        // which runs detect/distill/fetchSchema via SW and emits the
        // resulting pageDetected (or discoverError) push.
        onRediscover: (payload) => {
          void (async () => {
            if (state.activeTabId === null) return;
            try {
              await sendToContent(state.activeTabId, {
                t: "rediscover",
                v: MESSAGE_VERSION,
                ...payload.hint !== void 0 ? { hint: payload.hint } : {},
                force: payload.force
              });
            } catch (err) {
              console.error("[negative-filter] rediscover failed:", err);
            }
          })();
        }
      });
    }
    const filterHost = document.getElementById("filter-list");
    if (filterHost) {
      renderFilterList(filterHost, {
        enabled: state.enabled && state.schema !== null,
        phrases: state.phrases,
        onChange: (p) => void pushPhrases(p),
        onSave: () => void handleSaveFilters(),
        onClearSaved: () => void handleClearSavedFilters(),
        savedExists: state.savedExists,
        onExport: () => void handleExportFilters(),
        onImport: (f) => void handleImportFilters(f),
        onSuggest: () => void handleSuggest(),
        suggestions: state.suggestions,
        suggesting: state.suggesting,
        ...state.suggestError ? { suggestError: state.suggestError } : {},
        onAcceptSuggestion: handleAcceptSuggestion,
        onDismissSuggestions: handleDismissSuggestions
      });
    }
    const errors = [];
    if (state.enabled && state.schema === null) {
      errors.push({
        kind: "missing-schema",
        message: "We didn't detect a list on this page yet."
      });
    }
    if (state.spend?.capReached) {
      errors.push({
        kind: "spend-cap",
        message: state.spend.cappedPeriod === "day" ? `${state.spend.dailyUsed}/${state.spend.dailyCap} calls used today.` : `${state.spend.monthlyUsed}/${state.spend.monthlyCap} calls used this month.`
      });
    }
    if (state.suggestError) {
      errors.push({ kind: "llm-error", message: state.suggestError });
    }
    if (state.discoverError) {
      errors.push({ kind: "llm-error", message: state.discoverError });
    }
    const errorHost = document.getElementById("error-panel");
    if (errorHost) renderErrorPanel(errorHost, { errors });
    const numericHost = document.getElementById("numeric-filter");
    if (numericHost) {
      renderNumericFilter(numericHost, {
        enabled: state.enabled && state.schema !== null && state.schema.fields[NUMERIC_FIELD] !== void 0,
        current: state.numeric,
        unit: "k$",
        min: 0,
        max: 300,
        step: 10,
        onChange: (next) => void pushNumeric(next)
      });
    }
    const deepHost = document.getElementById("deep-toggle");
    if (deepHost) {
      renderDeepToggle(deepHost, {
        enabled: state.enabled && state.schema !== null,
        deepOn: state.deepOn,
        warningDismissed: state.deepWarningDismissed,
        modalOpen: state.deepModalOpen,
        onToggleDeep: handleToggleDeep,
        onDismissWarning: () => void handleDismissDeepWarning()
      });
    }
    const hiddenHost = document.getElementById("hidden-list");
    if (hiddenHost) {
      renderHiddenList(hiddenHost, {
        items: state.items,
        onSetItem: (id, restored) => void pushItemRestored(id, restored),
        onSetAll: (restored) => void pushAllRestored(restored)
      });
    }
  }
  chrome.runtime.onMessage.addListener((raw, _sender, _sendResponse) => {
    if (!isContentToPanel(raw)) return false;
    switch (raw.t) {
      case "itemStates":
        state.items = raw.items;
        render();
        break;
      case "pageDetected":
        state.discoverError = null;
        void refresh();
        break;
      case "discoverError":
        state.discoverError = raw.message;
        render();
        break;
    }
    return false;
  });
  void refresh();
  chrome.tabs.onActivated.addListener(() => {
    void refresh();
  });
  chrome.tabs.onUpdated.addListener((_id, info) => {
    if (info.status === "complete" || info.url !== void 0) {
      void refresh();
    }
  });
})();
//# sourceMappingURL=panel.js.map
