"use strict";
(() => {
  // extension/content/stable-classes.ts
  var VOLATILE_CLASS_PATTERNS = [
    /^css-[a-z0-9]{4,}$/i,
    // emotion / linaria
    /^_[a-z0-9_-]{3,}$/i,
    // leading-underscore (Next.js, CSS modules)
    /^[a-z][\w-]*__[a-z0-9]*\d[a-z0-9]*$/i,
    // CSS modules: Card__a8K2 (hash suffix
    // must contain a digit — otherwise this also ate real BEM elements like
    // `scaffold-layout__list`, merging unrelated containers on real sites)
    /^jsx-\d{4,}$/i,
    // styled-jsx
    /^sc-[a-z0-9]{4,}$/i,
    // styled-components
    /^ember\d+$/i
    // Ember view ids surfaced as classes
  ];
  function isHashToken(cls) {
    return /^[A-Za-z0-9]{10,}$/.test(cls) && /[a-z]/.test(cls) && /[A-Z]/.test(cls);
  }
  function isVolatileClass(cls) {
    if (isHashToken(cls)) return true;
    for (const re of VOLATILE_CLASS_PATTERNS) {
      if (re.test(cls)) return true;
    }
    return false;
  }
  function stableClasses(el) {
    return Array.from(el.classList).filter((c) => !isVolatileClass(c)).sort().join(".");
  }
  function stableShape(el) {
    const classes = stableClasses(el);
    return classes ? `${el.tagName}.${classes}` : el.tagName;
  }

  // extension/content/detect.ts
  var NON_CONTENT_TAGS = /* @__PURE__ */ new Set([
    "HEAD",
    "SCRIPT",
    "STYLE",
    "LINK",
    "META",
    "TITLE",
    "NOSCRIPT",
    "BASE",
    "TEMPLATE"
  ]);
  var MIN_GROUP_SIZE = 3;
  var DESCENDANT_CAP = 40;
  function signatureOf(el) {
    return stableShape(el);
  }
  function elementChildren(parent) {
    const out = [];
    for (const child of Array.from(parent.children)) {
      if (NON_CONTENT_TAGS.has(child.tagName)) continue;
      out.push(child);
    }
    return out;
  }
  function computeDescendantCounts(root) {
    const counts = /* @__PURE__ */ new Map();
    const stack = [[root, false]];
    while (stack.length > 0) {
      const [node, visited] = stack.pop();
      if (NON_CONTENT_TAGS.has(node.tagName)) continue;
      if (!visited) {
        stack.push([node, true]);
        for (const child of Array.from(node.children)) {
          if (!NON_CONTENT_TAGS.has(child.tagName)) stack.push([child, false]);
        }
      } else {
        let total = 0;
        for (const child of Array.from(node.children)) {
          if (NON_CONTENT_TAGS.has(child.tagName)) continue;
          total += 1 + (counts.get(child) ?? 0);
        }
        counts.set(node, total);
      }
    }
    return counts;
  }
  function evaluateParent(parent, counts) {
    const children = elementChildren(parent);
    if (children.length < MIN_GROUP_SIZE) return null;
    const groups = /* @__PURE__ */ new Map();
    for (const child of children) {
      const sig = signatureOf(child);
      const list = groups.get(sig);
      if (list) list.push(child);
      else groups.set(sig, [child]);
    }
    let best = null;
    for (const [sig, group] of groups) {
      if (group.length < MIN_GROUP_SIZE) continue;
      let total = 0;
      for (const el of group) total += counts.get(el) ?? 0;
      const meanDescendants = total / group.length;
      const score = group.length * Math.min(meanDescendants, DESCENDANT_CAP);
      if (!best || score > best.score) {
        best = { container: parent, group, signature: sig, score };
      }
    }
    if (!best) best = evaluateParentByTag(parent, children, counts);
    return best;
  }
  function evaluateParentByTag(parent, children, counts) {
    const groups = /* @__PURE__ */ new Map();
    for (const child of children) {
      const list = groups.get(child.tagName);
      if (list) list.push(child);
      else groups.set(child.tagName, [child]);
    }
    let best = null;
    for (const [tag, group] of groups) {
      if (group.length < MIN_GROUP_SIZE) continue;
      let total = 0;
      for (const el of group) total += counts.get(el) ?? 0;
      const meanDescendants = total / group.length;
      const score = group.length * Math.min(meanDescendants, DESCENDANT_CAP);
      if (!best || score > best.score) {
        best = { container: parent, group, signature: tag, score };
      }
    }
    return best;
  }
  function classify(container) {
    const style = getComputedStyle(container);
    const display = style.display;
    if (display === "grid" || display === "inline-grid") return "grid";
    if (display === "flex" || display === "inline-flex") {
      const direction = style.flexDirection;
      const horizontal = direction === "row" || direction === "row-reverse";
      const overflowX = style.overflowX;
      const scrolls = overflowX === "auto" || overflowX === "scroll";
      if (horizontal && scrolls) return "carousel";
    }
    return "list";
  }
  function detect(root) {
    const startEl = root instanceof Document ? root.documentElement : root;
    if (!startEl) return null;
    const counts = computeDescendantCounts(startEl);
    let best = null;
    const stack = [startEl];
    while (stack.length > 0) {
      const node = stack.pop();
      if (NON_CONTENT_TAGS.has(node.tagName)) continue;
      const cand = evaluateParent(node, counts);
      if (cand && (!best || cand.score > best.score)) best = cand;
      for (const child of Array.from(node.children)) {
        if (!NON_CONTENT_TAGS.has(child.tagName)) stack.push(child);
      }
    }
    return best?.container ?? null;
  }
  function leafSelector(el) {
    const tag = el.tagName.toLowerCase();
    const classes = stableClasses(el);
    if (classes === "") return tag;
    const escaped = classes.split(".").map((c) => `.${CSS.escape(c)}`).join("");
    return `${tag}${escaped}`;
  }
  function uniqueSelectorFor(el) {
    const doc = el.ownerDocument;
    if (!doc) return leafSelector(el);
    if (el.id) {
      const idSel = `#${CSS.escape(el.id)}`;
      if (doc.querySelector(idSel) === el) return idSel;
    }
    let path = leafSelector(el);
    if (doc.querySelector(path) === el) return path;
    let cursor = el.parentElement;
    while (cursor && cursor !== doc.documentElement) {
      if (cursor.id) {
        const prefixed = `#${CSS.escape(cursor.id)} > ${path}`;
        if (doc.querySelector(prefixed) === el) return prefixed;
      }
      const ancestor = leafSelector(cursor);
      path = `${ancestor} > ${path}`;
      if (doc.querySelector(path) === el) return path;
      cursor = cursor.parentElement;
    }
    return path;
  }
  function localizeItemSet(itemSet) {
    const children = elementChildren(itemSet);
    if (children.length < MIN_GROUP_SIZE) return null;
    const counts = /* @__PURE__ */ new Map();
    for (const child of children) {
      const sig = signatureOf(child);
      const entry = counts.get(sig);
      if (entry) entry.count += 1;
      else counts.set(sig, { count: 1, sample: child });
    }
    let modal = null;
    for (const entry of counts.values()) {
      if (!modal || entry.count > modal.count) modal = entry;
    }
    if (!modal || modal.count < MIN_GROUP_SIZE) return null;
    const doc = itemSet.ownerDocument;
    if (!doc) return null;
    const leaf = leafSelector(modal.sample);
    const itemSetSelector = uniqueSelectorFor(itemSet);
    const scoped = `${itemSetSelector} > ${leaf}`;
    const scopedCount = safeCount(doc, scoped);
    const leafCount = safeCount(itemSet, leaf);
    let itemSelector;
    let count;
    if (scopedCount >= modal.count) {
      itemSelector = scoped;
      count = scopedCount;
    } else {
      itemSelector = leaf;
      count = leafCount;
    }
    if (count < MIN_GROUP_SIZE) return null;
    return { itemSetSelector, itemSelector, count };
  }
  function safeCount(root, selector) {
    try {
      return root.querySelectorAll(selector).length;
    } catch {
      return 0;
    }
  }

  // extension/content/fingerprint.ts
  var DEPTH = 3;
  function nodeShape(el) {
    return stableShape(el);
  }
  var NON_CONTENT_TAGS2 = /* @__PURE__ */ new Set([
    "SCRIPT",
    "STYLE",
    "LINK",
    "META",
    "NOSCRIPT",
    "TEMPLATE"
  ]);
  function elementChildren2(parent) {
    const out = [];
    for (const child of Array.from(parent.children)) {
      if (NON_CONTENT_TAGS2.has(child.tagName)) continue;
      out.push(child);
    }
    return out;
  }
  function recursiveShape(el, depth) {
    if (depth === 0) return nodeShape(el);
    const children = elementChildren2(el).map((c) => recursiveShape(c, depth - 1)).sort();
    return children.length === 0 ? nodeShape(el) : `${nodeShape(el)}(${children.join(",")})`;
  }
  function modeOf(xs) {
    if (xs.length === 0) return null;
    const counts = /* @__PURE__ */ new Map();
    for (const x of xs) counts.set(x, (counts.get(x) ?? 0) + 1);
    let best = null;
    const sorted = [...counts.entries()].sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0);
    for (const [value, count] of sorted) {
      if (!best || count > best.count) best = { value, count };
    }
    return best?.value ?? null;
  }
  function fnv1a32(s) {
    let h = 2166136261;
    for (let i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24)) >>> 0;
    }
    return h.toString(16).padStart(8, "0");
  }
  function fingerprintItemSet(itemSet) {
    const children = elementChildren2(itemSet);
    if (children.length === 0) return null;
    const childShapes = children.map((c) => recursiveShape(c, DEPTH));
    const modal = modeOf(childShapes);
    if (modal === null) return null;
    const containerShape = nodeShape(itemSet);
    return fnv1a32(`${containerShape}|${modal}`);
  }

  // extension/background/spend.ts
  var MS_PER_DAY = 24 * 60 * 60 * 1e3;

  // extension/background/llm.ts
  var NON_CONTENT_TAGS3 = /* @__PURE__ */ new Set([
    "SCRIPT",
    "STYLE",
    "LINK",
    "META",
    "NOSCRIPT",
    "TEMPLATE"
  ]);
  var REDACT_ATTRS = [
    "aria-label",
    "alt",
    "title",
    "placeholder",
    "value",
    "name",
    "for",
    "download"
  ];
  var URL_ATTRS = ["href", "src", "srcset", "action", "formaction"];
  var MAX_DEPTH = 8;
  var COLLAPSE_THRESHOLD = 3;
  var REDACTED = "\u2026";
  var INDENT = "  ";
  function shapeOf(el) {
    const classes = Array.from(el.classList).sort().join(".");
    return classes ? `${el.tagName.toLowerCase()}.${classes}` : el.tagName.toLowerCase();
  }
  function elementChildren3(parent) {
    const out = [];
    for (const child of Array.from(parent.children)) {
      if (NON_CONTENT_TAGS3.has(child.tagName)) continue;
      out.push(child);
    }
    return out;
  }
  function hasVisibleText(el) {
    for (const node of Array.from(el.childNodes)) {
      if (node.nodeType === 3 && (node.textContent ?? "").trim() !== "") return true;
    }
    return false;
  }
  function renderAttrs(el, isRoot) {
    const parts = [];
    if (el.classList.length > 0) {
      const sorted = Array.from(el.classList).sort().join(" ");
      parts.push(`class="${sorted}"`);
    }
    const role = el.getAttribute("role");
    if (role) parts.push(`role="${role}"`);
    if (isRoot && el.id) parts.push(`id="${el.id}"`);
    for (const a of REDACT_ATTRS) {
      if (el.hasAttribute(a) && (el.getAttribute(a) ?? "").trim() !== "") {
        parts.push(`${a}="${REDACTED}"`);
      }
    }
    for (const a of URL_ATTRS) {
      if (el.hasAttribute(a)) parts.push(`${a}="#${REDACTED}"`);
    }
    return parts.length ? " " + parts.join(" ") : "";
  }
  function distillNode(el, depth, isRoot) {
    const tag = el.tagName.toLowerCase();
    const attrs = renderAttrs(el, isRoot);
    const indent = INDENT.repeat(depth);
    if (depth >= MAX_DEPTH) {
      return [`${indent}<${tag}${attrs}>${REDACTED}</${tag}>`];
    }
    const children = elementChildren3(el);
    if (children.length === 0) {
      if (hasVisibleText(el)) {
        return [`${indent}<${tag}${attrs}>${REDACTED}</${tag}>`];
      }
      return [`${indent}<${tag}${attrs}/>`];
    }
    const out = [`${indent}<${tag}${attrs}>`];
    let i = 0;
    while (i < children.length) {
      const first = children[i];
      const sig = shapeOf(first);
      let j = i + 1;
      while (j < children.length && shapeOf(children[j]) === sig) j++;
      const runLen = j - i;
      out.push(...distillNode(first, depth + 1, false));
      if (runLen >= COLLAPSE_THRESHOLD) {
        const more = runLen - 1;
        out.push(`${INDENT.repeat(depth + 1)}\u2026 \xD7${more} more <${sig}>`);
      } else {
        for (let k = i + 1; k < j; k++) {
          out.push(...distillNode(children[k], depth + 1, false));
        }
      }
      i = j;
    }
    out.push(`${indent}</${tag}>`);
    return out;
  }
  function distill(root) {
    return distillNode(root, 0, true).join("\n");
  }

  // extension/content/discover.ts
  function countMatches(root, selector) {
    try {
      return root.querySelectorAll(selector).length;
    } catch {
      return 0;
    }
  }
  var CURRENCY_AMOUNT_RE = /(?:[A-Z]{0,3}\$|€|£|¥|₩|₹|USD|HKD|SGD|EUR|GBP|RMB?|CNY|JPY)\s*\d[\d,]*(?:\.\d+)?/;
  var PRICE_SCAN_CAP = 250;
  function stableSelectorFor(el) {
    const classes = Array.from(el.classList).filter((c) => !isVolatileClass(c));
    if (classes.length === 0) return null;
    return `${el.tagName.toLowerCase()}.${classes.map((c) => CSS.escape(c)).join(".")}`;
  }
  function detectPriceField(itemSet, itemSelector) {
    let items;
    try {
      items = Array.from(itemSet.querySelectorAll(itemSelector)).filter(
        (el) => el.querySelector(itemSelector) === null
      );
    } catch {
      return null;
    }
    if (items.length < 2) return null;
    const coverage = /* @__PURE__ */ new Map();
    for (const item of items) {
      const seen = /* @__PURE__ */ new Set();
      const descendants = item.querySelectorAll("*");
      const cap = Math.min(descendants.length, PRICE_SCAN_CAP);
      for (let i = 0; i < cap; i++) {
        const el = descendants[i];
        const text = el.textContent ?? "";
        if (!CURRENCY_AMOUNT_RE.test(text)) continue;
        let childMatches = false;
        for (const child of el.children) {
          if (CURRENCY_AMOUNT_RE.test(child.textContent ?? "")) {
            childMatches = true;
            break;
          }
        }
        if (childMatches) continue;
        const sel = stableSelectorFor(el);
        if (sel) seen.add(sel);
      }
      for (const sel of seen) coverage.set(sel, (coverage.get(sel) ?? 0) + 1);
    }
    const required = Math.max(2, Math.ceil(items.length / 2));
    let best = null;
    let bestCount = 0;
    for (const [sel, count] of coverage) {
      if (count > bestCount) {
        best = sel;
        bestCount = count;
      }
    }
    if (best === null || bestCount < required) return null;
    let firstMatchHits = 0;
    for (const item of items) {
      const el = item.querySelector(best);
      if (el && CURRENCY_AMOUNT_RE.test(el.textContent ?? "")) firstMatchHits++;
    }
    if (firstMatchHits < required) return null;
    return { kind: "number", selector: best };
  }
  function buildLocalSchema(doc) {
    const itemSet = detect(doc);
    if (!itemSet) return null;
    const local = localizeItemSet(itemSet);
    if (!local) return null;
    const fingerprint = fingerprintItemSet(itemSet);
    if (!fingerprint) return null;
    const schema = {
      fingerprint,
      layout: classify(itemSet),
      itemSetSelector: local.itemSetSelector,
      itemSelector: local.itemSelector,
      fields: {},
      source: "local",
      discoveredAt: Date.now()
    };
    const price = detectPriceField(itemSet, local.itemSelector);
    if (price) schema.fields["price"] = price;
    return { schema, itemSet };
  }
  async function discover(doc, ctx2, opts = {}) {
    const itemSet = detect(doc);
    if (!itemSet) return null;
    const fingerprint = fingerprintItemSet(itemSet);
    if (!fingerprint) return null;
    const layout = classify(itemSet);
    const distilled = distill(itemSet);
    const req = { fingerprint, distilled, layout };
    if (opts.hint !== void 0) req.hint = opts.hint;
    if (opts.force === true) req.force = true;
    const schema = await ctx2.fetchSchema(req);
    const local = localizeItemSet(itemSet);
    if (local && local.count > countMatches(itemSet, schema.itemSelector)) {
      schema.itemSetSelector = local.itemSetSelector;
      schema.itemSelector = local.itemSelector;
    }
    const hasNumberField = Object.values(schema.fields).some((f) => f.kind === "number");
    if (!hasNumberField) {
      const price = detectPriceField(itemSet, schema.itemSelector);
      if (price) schema.fields["price"] = price;
    }
    return { schema, itemSet };
  }

  // extension/shared/safe-regex.ts
  var UnsafeRegexError = class extends Error {
    reason;
    pattern;
    constructor(reason, pattern) {
      super(`UnsafeRegexError: ${reason}`);
      this.name = "UnsafeRegexError";
      this.reason = reason;
      this.pattern = pattern;
    }
  };
  var MAX_REGEX_LENGTH = 256;
  var NESTED_QUANTIFIER = /\([^)]*[+*][^)]*\)\s*[+*?{]/;
  function safeCompileRegex(pattern, flags) {
    if (pattern.length === 0) {
      throw new UnsafeRegexError("empty pattern", pattern);
    }
    if (pattern.length > MAX_REGEX_LENGTH) {
      throw new UnsafeRegexError(
        `length ${pattern.length} exceeds cap ${MAX_REGEX_LENGTH}`,
        pattern
      );
    }
    if (NESTED_QUANTIFIER.test(pattern)) {
      throw new UnsafeRegexError("nested quantifier (ReDoS risk)", pattern);
    }
    try {
      return new RegExp(pattern, flags);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      throw new UnsafeRegexError(`syntax: ${msg}`, pattern);
    }
  }

  // extension/shared/types.ts
  var MESSAGE_VERSION = 1;
  var ALL_TEXT_FIELD = "*";
  function hasShape(x) {
    return typeof x === "object" && x !== null && "t" in x && "v" in x;
  }
  function hasStringField(x, key) {
    return key in x && typeof x[key] === "string";
  }
  function isSwToPanel(x) {
    if (!hasShape(x)) return false;
    if (x.v !== MESSAGE_VERSION) return false;
    const r = x;
    switch (x.t) {
      case "pong":
      case "ack":
        return true;
      case "err":
        return hasStringField(x, "message");
      case "schema":
        return typeof r["schema"] === "object" && r["schema"] !== null;
      case "suggestions":
        return Array.isArray(r["phrases"]);
      default:
        return false;
    }
  }
  function isPanelToContent(x) {
    if (!hasShape(x)) return false;
    if (x.v !== MESSAGE_VERSION) return false;
    const r = x;
    switch (x.t) {
      case "getState":
        return true;
      case "setFilters":
        return Array.isArray(r["filters"]);
      case "setDisplayMode":
        return r["mode"] === "collapse" || r["mode"] === "hide";
      case "setItemRestored":
        return hasStringField(x, "itemId") && typeof r["restored"] === "boolean";
      case "rediscover":
      case "getSuggestions":
        return true;
      case "spaNavigated":
        return hasStringField(x, "url");
      default:
        return false;
    }
  }
  async function sendToSw(msg) {
    const reply = await chrome.runtime.sendMessage(msg);
    if (!isSwToPanel(reply)) {
      throw new Error(`SW returned malformed reply: ${JSON.stringify(reply)}`);
    }
    return reply;
  }
  function pushToPanel(msg) {
    void chrome.runtime.sendMessage(msg).catch(() => void 0);
  }

  // extension/content/engine.ts
  function normalizeText(s) {
    return s.replace(/\s+/g, " ").trim();
  }
  function readAllText(item, detailText) {
    const cardText = normalizeText(item.textContent ?? "");
    const extra = detailText?.get(item);
    const text = extra ? `${cardText} ${normalizeText(extra)}` : cardText;
    return text.length > 0 ? text : null;
  }
  function readField(item, fieldName, schema) {
    const field = schema.fields[fieldName];
    if (!field) return null;
    let el;
    try {
      el = item.querySelector(field.selector);
    } catch {
      return null;
    }
    const text = el?.textContent?.trim();
    return text && text.length > 0 ? text : null;
  }
  function parseFirstNumber(text) {
    const grouped = text.match(/-?\d{1,3}(?:,\d{3})+(?:\.\d+)?/);
    const bare = text.match(/-?\d+(?:\.\d+)?/);
    let raw = null;
    if (grouped && (!bare || (grouped.index ?? 0) <= (bare.index ?? 0))) {
      raw = grouped[0].replace(/,/g, "");
    } else if (bare) {
      raw = bare[0];
    }
    if (raw === null) return null;
    const n = parseFloat(raw);
    return Number.isFinite(n) ? n : null;
  }
  function evalPredicate(text, pred, compiledRegex) {
    switch (pred.op) {
      case "containsAny": {
        const haystack = text.toLowerCase();
        let squashed = null;
        for (const phrase of pred.phrases) {
          if (phrase.length === 0) continue;
          const needle = phrase.toLowerCase();
          if (haystack.includes(needle)) {
            return { matched: true, trigger: phrase };
          }
          const squashedNeedle = needle.replace(/\s+/g, "");
          if (squashedNeedle.length === 0) continue;
          squashed ??= haystack.replace(/\s+/g, "");
          if (squashed.includes(squashedNeedle)) {
            return { matched: true, trigger: phrase };
          }
        }
        return { matched: false };
      }
      case "regex": {
        if (!compiledRegex) return { matched: false };
        const match = compiledRegex.exec(text);
        return match ? { matched: true, trigger: match[0] } : { matched: false };
      }
      case "lessThan": {
        const n = parseFirstNumber(text);
        return n !== null && n < pred.value ? { matched: true, trigger: `${n} < ${pred.value}` } : { matched: false };
      }
      case "greaterThan": {
        const n = parseFirstNumber(text);
        return n !== null && n > pred.value ? { matched: true, trigger: `${n} > ${pred.value}` } : { matched: false };
      }
      case "equals": {
        const target = typeof pred.value === "string" ? pred.value : String(pred.value);
        return text === target ? { matched: true, trigger: target } : { matched: false };
      }
      case "oneOf": {
        for (const v of pred.values) {
          const target = typeof v === "string" ? v : String(v);
          if (text === target) return { matched: true, trigger: target };
        }
        return { matched: false };
      }
    }
  }
  function evaluate(schema, items, filters, detailText, onFilterError) {
    const out = /* @__PURE__ */ new Map();
    const prepared = [];
    for (const filter of filters) {
      if (filter.fingerprint !== schema.fingerprint) continue;
      if (filter.predicate.op === "regex") {
        try {
          prepared.push({
            filter,
            regex: safeCompileRegex(filter.predicate.pattern, filter.predicate.flags)
          });
        } catch (err) {
          onFilterError?.({
            filterId: filter.id,
            message: err instanceof Error ? err.message : String(err)
          });
        }
        continue;
      }
      prepared.push({ filter, regex: void 0 });
    }
    for (const item of items) {
      let verdict = { state: "passing" };
      let allText;
      for (const { filter, regex } of prepared) {
        let text;
        if (filter.field === ALL_TEXT_FIELD) {
          if (allText === void 0) allText = readAllText(item, detailText);
          text = allText;
        } else {
          text = readField(item, filter.field, schema);
        }
        if (text === null) continue;
        const outcome = evalPredicate(text, filter.predicate, regex);
        const excludes = filter.polarity === "exclude" && outcome.matched || filter.polarity === "keep" && !outcome.matched;
        if (excludes) {
          verdict = {
            state: "filtered",
            reason: outcome.trigger ?? filter.predicate.op
          };
          break;
        }
      }
      out.set(item, verdict);
    }
    return out;
  }
  function findItems(schema, doc = document, knownItemSet) {
    const root = knownItemSet ?? bestRoot(schema, doc);
    let matches;
    try {
      matches = Array.from(root.querySelectorAll(schema.itemSelector));
    } catch {
      return [];
    }
    return matches.filter((el) => el.querySelector(schema.itemSelector) === null);
  }
  function bestRoot(schema, doc) {
    let candidates;
    try {
      candidates = Array.from(doc.querySelectorAll(schema.itemSetSelector));
    } catch {
      return doc;
    }
    if (candidates.length === 0) return doc;
    if (candidates.length === 1) return candidates[0];
    let best = null;
    let bestCount = 0;
    for (const c of candidates) {
      let n;
      try {
        n = c.querySelectorAll(schema.itemSelector).length;
      } catch {
        n = 0;
      }
      if (n > bestCount) {
        best = c;
        bestCount = n;
      }
    }
    return best ?? candidates[0];
  }

  // extension/content/mutations.ts
  var MutationWatcher = class {
    constructor(opts) {
      this.opts = opts;
    }
    observer = null;
    pending = /* @__PURE__ */ new Set();
    flushScheduled = false;
    start() {
      if (this.observer) return;
      this.observer = new MutationObserver((mutations) => {
        this.queue(mutations);
      });
      this.observer.observe(this.opts.itemSet, { childList: true, subtree: true });
    }
    stop() {
      this.observer?.disconnect();
      this.observer = null;
      this.pending.clear();
      this.flushScheduled = false;
    }
    queue(mutations) {
      for (const m of mutations) {
        for (const node of m.addedNodes) {
          if (!(node instanceof Element)) continue;
          if (this.isRendererNode(node)) continue;
          if (this.matchesItem(node)) {
            this.pending.add(node);
          } else if (node.childElementCount > 0) {
            for (const nested of this.queryItems(node)) {
              if (!this.isRendererNode(nested)) this.pending.add(nested);
            }
          }
        }
      }
      if (this.pending.size === 0) return;
      if (this.flushScheduled) return;
      this.flushScheduled = true;
      queueMicrotask(() => this.flush());
    }
    isRendererNode(el) {
      return el.matches(".filt, .sliver, .sliver-v, .ctile, .rehide, .nf-check-mark");
    }
    matchesItem(el) {
      try {
        return el.matches(this.opts.itemSelector);
      } catch {
        return false;
      }
    }
    queryItems(root) {
      try {
        return Array.from(root.querySelectorAll(this.opts.itemSelector));
      } catch {
        return [];
      }
    }
    flush() {
      this.flushScheduled = false;
      if (this.pending.size === 0) return;
      const added = Array.from(this.pending);
      this.pending.clear();
      this.opts.onItemsAdded(added);
    }
  };

  // extension/content/renderer.ts
  var STYLE_EL_ID = "nf-injected-styles";
  var STYLES = `
.filt > .nf-card-hidden { display: none; }
.filt > .sliver {
  display: block;
  height: 28px;
  line-height: 28px;
  padding: 0 10px;
  font: 12px/28px system-ui, -apple-system, Segoe UI, sans-serif;
  color: #57606a;
  background: #f6f8fa;
  border: 1px solid #d0d7de;
  border-radius: 6px;
  cursor: pointer;
  user-select: none;
  text-align: left;
  width: 100%;
  box-sizing: border-box;
}
.filt > .sliver:hover { background: #eaeef2; }
.filt.restored > .sliver { display: none; }
.filt.restored > .nf-card-hidden { display: block; }
.filt > .rehide { display: none; }
.filt.restored > .rehide {
  display: inline-block;
  margin-top: 4px;
  padding: 2px 8px;
  font: 11px/1 system-ui, -apple-system, Segoe UI, sans-serif;
  color: #57606a;
  background: transparent;
  border: 1px solid #d0d7de;
  border-radius: 4px;
  cursor: pointer;
}
.mode-hide > .filt:not(.restored) { display: none; }
/* Carousel layout (Slice 2.5): a narrow vertical sliver replaces the card
   width-wise so the horizontal track keeps the same flex shape; reason
   text is rotated to read top-to-bottom. */
.filt.layout-carousel {
  flex: 0 0 46px;
  width: 46px;
  min-width: 46px;
  align-self: stretch;
}
.filt.layout-carousel > .sliver-v {
  display: block;
  width: 100%;
  min-height: 120px;
  height: 100%;
  padding: 8px 6px;
  font: 12px/1.2 system-ui, -apple-system, Segoe UI, sans-serif;
  color: #57606a;
  background: #f6f8fa;
  border: 1px solid #d0d7de;
  border-radius: 6px;
  cursor: pointer;
  user-select: none;
  box-sizing: border-box;
  writing-mode: vertical-rl;
  text-align: left;
  overflow: hidden;
}
.filt.layout-carousel > .sliver-v:hover { background: #eaeef2; }
.filt.layout-carousel.restored > .sliver-v { display: none; }
/* Grid layout (Slice 2.6): wrapper still occupies exactly one grid cell so
   the column count and row pack stay stable; a .ctile placeholder fills
   the cell footprint and signals "hidden item." No flex sizing \u2014 the host
   grid template already gives the wrapper the right cell. */
.filt.layout-grid > .ctile {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 60px;
  height: 100%;
  width: 100%;
  padding: 12px;
  font: 12px/1.3 system-ui, -apple-system, Segoe UI, sans-serif;
  color: #57606a;
  background: #f6f8fa;
  border: 1px dashed #d0d7de;
  border-radius: 8px;
  cursor: pointer;
  user-select: none;
  text-align: center;
  box-sizing: border-box;
}
.filt.layout-grid > .ctile:hover { background: #eaeef2; }
.filt.layout-grid.restored > .ctile { display: none; }
/* Checking state (Slice 5.7): items mid-deep-scan get a small inline
   indicator. Rendered as a pseudo-element off a data attribute \u2014 never an
   inserted node: React-managed lists strand or duplicate foreign children
   on reconciliation, and removeAttribute() restores the passing card's
   outerHTML byte-identically with no race against a framework re-render. */
[data-nf-checking]::after {
  content: '\u23F3 checking\u2026';
  display: inline-block;
  margin-left: 6px;
  padding: 1px 6px;
  font: 11px/1.2 system-ui, -apple-system, Segoe UI, sans-serif;
  color: #57606a;
  background: #f6f8fa;
  border: 1px solid #d0d7de;
  border-radius: 4px;
  vertical-align: middle;
}
/* Detached mode: React-managed lists revert reparented rows on their next
   reconciliation pass (LinkedIn v2 LazyColumn), so filtered items are
   collapsed in place via class + data attributes only \u2014 never wrapped, no
   sibling nodes inserted into the React-owned parent. The reason text and
   both click affordances are pseudo-elements so the item subtree stays
   byte-compatible with what React expects. !important because we are
   overriding site CSS (and possibly inline virtualization sizing) on the
   site's own elements. */
.nf-filt-item:not(.nf-restored) {
  position: relative !important;
  height: 28px !important;
  min-height: 28px !important;
  max-height: 28px !important;
  padding: 0 !important;
  overflow: hidden !important;
  box-sizing: border-box !important;
  cursor: pointer;
}
.nf-filt-item:not(.nf-restored) > * {
  visibility: hidden !important;
}
.nf-filt-item:not(.nf-restored)::before {
  content: attr(data-nf-reason);
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 28px;
  padding: 0 10px;
  font: 12px/26px system-ui, -apple-system, Segoe UI, sans-serif;
  color: #57606a;
  background: #f6f8fa;
  border: 1px solid #d0d7de;
  border-radius: 6px;
  box-sizing: border-box;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  z-index: 2;
}
.nf-filt-item:not(.nf-restored):hover::before { background: #eaeef2; }
/* Restored state: the card renders normally; a small in-flow bar at the top
   (pseudo-element, so still zero inserted nodes) is the re-hide affordance.
   The click handler only honors clicks landing on the item element itself
   within the bar zone, so the card's own links/buttons keep working. */
.nf-filt-item.nf-restored::before {
  content: '\u21BA re-hide';
  display: block;
  height: 20px;
  padding: 0 10px;
  margin-bottom: 4px;
  font: 11px/18px system-ui, -apple-system, Segoe UI, sans-serif;
  color: #57606a;
  background: #f6f8fa;
  border: 1px solid #d0d7de;
  border-radius: 4px;
  box-sizing: border-box;
  cursor: pointer;
  user-select: none;
}
.mode-hide .nf-filt-item:not(.nf-restored) { display: none !important; }
/* Table rows need their own detached treatment: visibility:hidden cells
   still occupy their full height, and an absolutely-positioned reason bar
   contributes nothing to a row whose cells are gone. Hide the cells
   entirely and let the reason render as an anonymous cell so the row
   keeps a 28px footprint. No re-hide bar on restored rows \u2014 a block
   pseudo-element would be wrapped into an anonymous first cell and shift
   every real cell over by one column; the panel's HIDDEN list covers
   re-hide for tables. */
tr.nf-filt-item:not(.nf-restored) > * { display: none !important; }
tr.nf-filt-item:not(.nf-restored)::before {
  position: static;
  display: table-cell;
  height: 28px;
}
tr.nf-filt-item.nf-restored::before { content: none; }
tr.nf-companion-hidden { display: none !important; }
`;
  var DETACHED_BAR_PX = 40;
  var TABLE_PART_TAGS = /* @__PURE__ */ new Set(["TR", "TD", "TH", "TBODY", "THEAD", "TFOOT"]);
  var MAX_COMPANION_ROWS = 3;
  function injectStyles(doc) {
    if (doc.getElementById(STYLE_EL_ID)) return;
    const style = doc.createElement("style");
    style.id = STYLE_EL_ID;
    style.textContent = STYLES;
    doc.head.appendChild(style);
  }
  var Renderer = class {
    opts;
    idByItem = /* @__PURE__ */ new WeakMap();
    /** Per-item .filt wrapper — present iff the item is currently filtered. */
    wrapperByItem = /* @__PURE__ */ new WeakMap();
    /** Reverse lookup so click handlers (1.5) can resolve id → item. */
    itemById = /* @__PURE__ */ new Map();
    restored = /* @__PURE__ */ new Set();
    /** Slice 5.7: items currently in the "checking" state (deep scan in
     *  flight). Cleared once the engine apply() resolves them. */
    checking = /* @__PURE__ */ new Set();
    nextId = 0;
    lastSummaries = [];
    /** `wrap` reparents into `.filt`; `detached` only mutates class/data
     *  attributes on the item. Starts from the schema, but flips to
     *  `detached` permanently if a React reconciler is caught reverting our
     *  wrappers (auto-fallback for unknown React sites). */
    renderMode;
    /** Items currently filtered in detached mode, with their verdicts — the
     *  self-heal observer needs an iterable (WeakMap can't be walked) and the
     *  verdict to restore `data-nf-reason` after React strips it. */
    detachedFiltered = /* @__PURE__ */ new Map();
    /** HN-style tables split one logical item across several <tr>s (title
     *  row + subtext row + spacer); only the title row matches itemSelector.
     *  Companion rows are hidden/shown in lock-step with their item. */
    companionsByItem = /* @__PURE__ */ new Map();
    /** Last verdict set, kept so the heal path can re-apply after the
     *  wrap → detached fallback without waiting for the next engine pass. */
    lastVerdicts = null;
    healObserver = null;
    healQueued = false;
    constructor(opts) {
      const doc = opts.doc ?? opts.itemSet.ownerDocument ?? document;
      this.opts = {
        schema: opts.schema,
        itemSet: opts.itemSet,
        doc,
        onRestoreToggle: opts.onRestoreToggle
      };
      this.renderMode = opts.schema.renderMode ?? "wrap";
      injectStyles(doc);
      doc.addEventListener("click", this.onDocClick, true);
      this.installHealObserver();
    }
    /** Detach document listeners + the heal observer. Must be called when a
     *  new renderer replaces this one (re-mount) — a stale instance would
     *  otherwise keep healing items the new renderer no longer filters. */
    disconnect() {
      this.healObserver?.disconnect();
      this.healObserver = null;
      this.opts.doc.removeEventListener("click", this.onDocClick, true);
    }
    /** Apply a fresh set of verdicts. Idempotent — re-applying with the same
     *  inputs is a DOM no-op. Returns one summary per item, in input order. */
    apply(verdicts) {
      this.lastVerdicts = verdicts;
      this.sweepDisconnected();
      if (this.renderMode === "wrap" && this.tablePartItems(verdicts)) {
        this.switchToDetached();
      }
      if (this.renderMode === "wrap" && this.wrapRevertDetected()) {
        this.switchToDetached();
      }
      const summaries = [];
      for (const [item, verdict] of verdicts) {
        this.handleRecycledItem(item);
        const id = this.ensureId(item);
        const label = this.readLabel(item);
        if (verdict.state === "filtered") {
          if (this.renderMode === "detached") {
            this.applyDetached(item, verdict, id);
          } else if (!this.wrapperByItem.has(item)) {
            this.wrap(item, verdict, id);
          } else {
            this.refreshSliver(item, verdict);
          }
        } else if (verdict.state === "passing") {
          if (this.renderMode === "detached") {
            if (this.detachedFiltered.has(item)) this.clearDetached(item, id);
          } else if (this.wrapperByItem.has(item)) {
            this.unwrap(item, id);
          }
        }
        if (this.checking.has(id) && verdict.state !== "checking") {
          this.checking.delete(id);
          item.removeAttribute("data-nf-checking");
        }
        const reportedState = verdict.state === "filtered" && this.restored.has(id) ? "restored" : verdict.state;
        const summary = { id, state: reportedState };
        if (verdict.reason !== void 0) summary.reason = verdict.reason;
        if (label !== void 0) summary.label = label;
        summaries.push(summary);
      }
      this.lastSummaries = summaries;
      return summaries;
    }
    /** Flip a single item's restored flag. Reflected in the DOM (the wrapper
     *  gets `.restored`) and in subsequent summaries. */
    setRestored(itemId, restored) {
      const item = this.itemById.get(itemId);
      if (!item) return;
      if (this.renderMode === "detached") {
        if (!this.detachedFiltered.has(item)) return;
        if (restored) {
          this.restored.add(itemId);
          item.classList.add("nf-restored");
        } else {
          this.restored.delete(itemId);
          item.classList.remove("nf-restored");
        }
        if (item.tagName === "TR") this.syncCompanions(item, !restored);
      } else {
        const wrapper = this.wrapperByItem.get(item);
        if (!wrapper) return;
        if (restored) {
          this.restored.add(itemId);
          wrapper.classList.add("restored");
        } else {
          this.restored.delete(itemId);
          wrapper.classList.remove("restored");
        }
      }
      const summary = this.lastSummaries.find((s) => s.id === itemId);
      if (summary) summary.state = restored ? "restored" : "filtered";
    }
    /** Slice 5.7: mark an item as actively being deep-scanned. The
     *  renderer adds a small spinner indicator next to it; once the
     *  engine produces a `filtered` or `passing` verdict (next apply
     *  call), the spinner is removed and the verdict takes effect. */
    setChecking(itemId, on) {
      const item = this.itemById.get(itemId);
      if (!item) return;
      if (on) {
        if (this.checking.has(itemId)) return;
        this.checking.add(itemId);
        item.setAttribute("data-nf-checking", "");
        const summary = this.lastSummaries.find((s) => s.id === itemId);
        if (summary) summary.state = "checking";
      } else {
        this.checking.delete(itemId);
        item.removeAttribute("data-nf-checking");
      }
    }
    /** Toggle the display mode on the item-set container. Slice 1.8 gate. */
    setMode(mode) {
      if (mode === "hide") this.opts.itemSet.classList.add("mode-hide");
      else this.opts.itemSet.classList.remove("mode-hide");
    }
    /** Latest summaries (state + label + reason) for every item the engine
     *  has evaluated. Survives between renderer.apply() calls. */
    summaries() {
      return this.lastSummaries;
    }
    // -------------------------------------------------------------------------
    // Internals
    // -------------------------------------------------------------------------
    /** Drop Element-keyed entries for nodes virtualization removed from the
     *  document. Map.delete during for..of iteration is spec-safe. */
    sweepDisconnected() {
      for (const [id, el] of this.itemById) {
        if (!el.isConnected) this.itemById.delete(id);
      }
      for (const el of this.detachedFiltered.keys()) {
        if (!el.isConnected) this.detachedFiltered.delete(el);
      }
      for (const el of this.companionsByItem.keys()) {
        if (!el.isConnected) this.companionsByItem.delete(el);
      }
    }
    ensureId(item) {
      let id = this.idByItem.get(item);
      if (id !== void 0) {
        this.itemById.set(id, item);
        return id;
      }
      id = this.currentIdentityKey(item) ?? `nf-${++this.nextId}`;
      this.idByItem.set(item, id);
      this.itemById.set(id, item);
      return id;
    }
    /** 6.1: identity-by-content for virtualized lists. The cached id
     *  for an element is stable as long as the element's data-id (or
     *  fallback synthetic id) stays the same. When a virtualizer
     *  recycles the element with a different data-id, we treat it as
     *  a new item — unwrap the old `.filt` wrapper (if any), drop the
     *  restored/checking flags scoped to the previous id, and clear
     *  the cache entry so ensureId() can re-mint. */
    handleRecycledItem(item) {
      const cached = this.idByItem.get(item);
      if (cached === void 0) return;
      const current = this.currentIdentityKey(item);
      if (current === null) return;
      if (cached === current) return;
      if (this.wrapperByItem.has(item)) this.unwrap(item, cached);
      if (this.detachedFiltered.has(item)) this.clearDetached(item, cached);
      this.restored.delete(cached);
      if (this.checking.has(cached)) {
        this.checking.delete(cached);
        item.removeAttribute("data-nf-checking");
      }
      this.itemById.delete(cached);
      this.idByItem.delete(item);
    }
    currentIdentityKey(item) {
      const dataId = item.getAttribute("data-id");
      if (dataId && dataId.length > 0) return dataId;
      const componentHost = item.matches('[componentkey^="job-card-component-ref-"]') ? item : item.querySelector('[componentkey^="job-card-component-ref-"]');
      const key = componentHost?.getAttribute("componentkey");
      return key && key.length > 0 ? key : null;
    }
    readLabel(item) {
      const fields = this.opts.schema.fields;
      const candidates = ["title", ...Object.keys(fields)];
      for (const name of candidates) {
        const f = fields[name];
        if (!f || f.kind !== "text") continue;
        const el = item.querySelector(f.selector);
        const text = el?.textContent?.trim();
        if (text && text.length > 0) return text;
      }
      const whole = item.textContent?.replace(/\s+/g, " ").trim();
      if (whole && whole.length > 0) {
        return whole.length > 64 ? `${whole.slice(0, 63)}\u2026` : whole;
      }
      return void 0;
    }
    wrap(item, verdict, id) {
      const doc = this.opts.doc;
      const layout = this.opts.schema.layout;
      const wrapper = doc.createElement("div");
      wrapper.className = layout === "carousel" ? "filt layout-carousel" : layout === "grid" ? "filt layout-grid" : "filt";
      wrapper.dataset["nfId"] = id;
      const sliver = doc.createElement("button");
      sliver.type = "button";
      sliver.className = layout === "carousel" ? "sliver-v" : layout === "grid" ? "ctile" : "sliver";
      sliver.dataset["nfId"] = id;
      sliver.setAttribute("aria-label", `Restore hidden item: ${this.readLabel(item) ?? id}`);
      sliver.textContent = this.sliverText(verdict);
      sliver.addEventListener("click", () => this.opts.onRestoreToggle?.(id, true));
      const rehide = doc.createElement("button");
      rehide.type = "button";
      rehide.className = "rehide";
      rehide.dataset["nfId"] = id;
      rehide.setAttribute("aria-label", `Re-hide ${this.readLabel(item) ?? id}`);
      rehide.textContent = "\u21BA re-hide";
      rehide.addEventListener("click", () => this.opts.onRestoreToggle?.(id, false));
      item.classList.add("nf-card-hidden");
      item.replaceWith(wrapper);
      wrapper.appendChild(item);
      wrapper.appendChild(sliver);
      wrapper.appendChild(rehide);
      this.wrapperByItem.set(item, wrapper);
      if (this.restored.has(id)) wrapper.classList.add("restored");
    }
    refreshSliver(item, verdict) {
      const wrapper = this.wrapperByItem.get(item);
      if (!wrapper) return;
      const sliver = wrapper.querySelector(".sliver, .sliver-v, .ctile");
      if (sliver) sliver.textContent = this.sliverText(verdict);
    }
    unwrap(item, id) {
      const wrapper = this.wrapperByItem.get(item);
      if (!wrapper) return;
      item.classList.remove("nf-card-hidden");
      wrapper.replaceWith(item);
      this.wrapperByItem.delete(item);
      this.restored.delete(id);
    }
    // -------------------------------------------------------------------------
    // Detached mode + self-heal
    // -------------------------------------------------------------------------
    /** Idempotent: re-applying the expected state is what the heal loop does,
     *  so this must converge instead of generating fresh mutations forever —
     *  attributes are only written when they actually diverge. */
    applyDetached(item, verdict, id) {
      this.detachedFiltered.set(item, verdict);
      const reason = this.sliverText(verdict);
      if (item.getAttribute("data-nf-reason") !== reason) {
        item.setAttribute("data-nf-reason", reason);
      }
      if (item.getAttribute("data-nf-id") !== id) {
        item.setAttribute("data-nf-id", id);
      }
      item.classList.add("nf-filt-item");
      if (this.restored.has(id)) item.classList.add("nf-restored");
      else item.classList.remove("nf-restored");
      if (item.tagName === "TR") this.syncCompanions(item, !this.restored.has(id));
    }
    /** Following sibling <tr>s up to the next known item — the subtext /
     *  spacer rows that visually belong to this row. Capped so a generic
     *  table can't make the walk swallow unrelated rows. Always walked
     *  fresh: live-updating tables insert rows after the first computation,
     *  and a cached set left late-arriving companions visible (or hid rows
     *  that no longer belong) until the item was unfiltered once. */
    companionsOf(item) {
      const companions = [];
      let sib = item.nextElementSibling;
      while (sib && sib.tagName === "TR" && companions.length < MAX_COMPANION_ROWS && !(this.lastVerdicts?.has(sib) ?? false) && !sib.classList.contains("nf-filt-item")) {
        companions.push(sib);
        sib = sib.nextElementSibling;
      }
      return companions;
    }
    /** companionsByItem records what is CURRENTLY hidden for the item — the
     *  unhide path must release exactly that set, not a re-walk that might
     *  miss rows the table moved. */
    syncCompanions(item, hidden) {
      if (hidden) {
        const fresh = this.companionsOf(item);
        const prev = this.companionsByItem.get(item);
        if (prev) {
          for (const c of prev) {
            if (!fresh.includes(c)) c.classList.remove("nf-companion-hidden");
          }
        }
        for (const c of fresh) c.classList.add("nf-companion-hidden");
        this.companionsByItem.set(item, fresh);
      } else {
        const prev = this.companionsByItem.get(item) ?? this.companionsOf(item);
        for (const c of prev) c.classList.remove("nf-companion-hidden");
        this.companionsByItem.delete(item);
      }
    }
    clearDetached(item, id) {
      this.detachedFiltered.delete(item);
      item.classList.remove("nf-filt-item");
      item.classList.remove("nf-restored");
      item.removeAttribute("data-nf-reason");
      item.removeAttribute("data-nf-id");
      this.restored.delete(id);
      if (item.tagName === "TR") {
        this.syncCompanions(item, false);
        this.companionsByItem.delete(item);
      }
    }
    tablePartItems(verdicts) {
      const first = verdicts.keys().next();
      return !first.done && TABLE_PART_TAGS.has(first.value.tagName);
    }
    wrapRevertDetected() {
      for (const item of this.itemById.values()) {
        const wrapper = this.wrapperByItem.get(item);
        if (wrapper && !wrapper.isConnected && item.isConnected) return true;
      }
      return false;
    }
    /** One-way: once a reconciler has been caught reverting wrappers there is
     *  no point ever wrapping again on this page. Connected wrappers are
     *  unwound by hand (not via unwrap()) so the restored flags survive the
     *  mode flip. */
    switchToDetached() {
      this.renderMode = "detached";
      for (const item of this.itemById.values()) {
        const wrapper = this.wrapperByItem.get(item);
        if (!wrapper) continue;
        item.classList.remove("nf-card-hidden");
        if (wrapper.isConnected) wrapper.replaceWith(item);
        this.wrapperByItem.delete(item);
      }
      this.installHealObserver();
    }
    installHealObserver() {
      this.healObserver?.disconnect();
      this.healObserver = new MutationObserver(() => this.scheduleHeal());
      const init2 = this.renderMode === "detached" ? {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ["class", "data-nf-reason", "data-nf-id"]
      } : { childList: true, subtree: true };
      this.healObserver.observe(this.opts.itemSet, init2);
    }
    scheduleHeal() {
      if (this.healQueued) return;
      this.healQueued = true;
      queueMicrotask(() => {
        this.healQueued = false;
        this.heal();
      });
    }
    /** Re-establish renderer-owned state that a framework re-render stripped.
     *  Only acts when expected and actual state diverge, so the observer
     *  feedback loop terminates: our own writes converge to a no-op pass. */
    heal() {
      if (this.renderMode === "wrap") {
        if (!this.wrapRevertDetected()) return;
        this.switchToDetached();
        if (this.lastVerdicts) this.apply(this.lastVerdicts);
        return;
      }
      for (const [item, verdict] of this.detachedFiltered) {
        if (!item.isConnected) continue;
        const id = this.idByItem.get(item);
        if (id === void 0) continue;
        if (this.detachedStateDiverged(item, verdict, id)) {
          this.applyDetached(item, verdict, id);
        }
      }
    }
    detachedStateDiverged(item, verdict, id) {
      if (!item.classList.contains("nf-filt-item")) return true;
      if (item.getAttribute("data-nf-reason") !== this.sliverText(verdict)) return true;
      if (item.getAttribute("data-nf-id") !== id) return true;
      return item.classList.contains("nf-restored") !== this.restored.has(id);
    }
    onDocClick = (e) => {
      if (this.renderMode !== "detached") return;
      const target = e.target;
      if (!(target instanceof Element)) return;
      const itemEl = target.closest(".nf-filt-item");
      if (!itemEl || !this.detachedFiltered.has(itemEl)) return;
      const id = this.idByItem.get(itemEl);
      if (id === void 0) return;
      if (!itemEl.classList.contains("nf-restored")) {
        e.preventDefault();
        e.stopPropagation();
        this.opts.onRestoreToggle?.(id, true);
        return;
      }
      if (target !== itemEl) return;
      if (e.clientY - itemEl.getBoundingClientRect().top > DETACHED_BAR_PX) return;
      e.preventDefault();
      e.stopPropagation();
      this.opts.onRestoreToggle?.(id, false);
    };
    sliverText(verdict) {
      return verdict.reason ? `Hidden \u2014 ${verdict.reason}` : "Hidden";
    }
  };

  // extension/content/schema-stub.ts
  var ROLECAST_STUB_SCHEMA = {
    fingerprint: "fixture:rolecast:v1",
    layout: "list",
    itemSetSelector: ".joblist",
    itemSelector: ".joblist > .job",
    fields: {
      title: { kind: "text", selector: ".title" },
      company: { kind: "text", selector: ".company" },
      location: { kind: "text", selector: ".location" },
      snippet: { kind: "text", selector: ".snippet" },
      // 4.4 needs a number field for the slider editor; engine's
      // parseFirstNumber reads "$180k–$220k" → 180 (lower-bound semantics).
      comp: { kind: "number", selector: ".comp" }
    },
    source: "stub",
    discoveredAt: 0
  };
  var LINKEDIN_JOBS_NEW_STUB = {
    fingerprint: "site:linkedin:jobs:v2",
    layout: "list",
    itemSetSelector: '[componentkey="SearchResultsMainContent"]',
    itemSelector: '[componentkey="SearchResultsMainContent"] [role="button"][componentkey^="job-card-component-ref-"]',
    fields: {},
    // The LazyColumn is React-reconciled per row: the wrap renderer's
    // `.filt` wrappers get silently reverted on the next render pass
    // (memory.md 2026-06-06). Detached mode mutates only class/data attrs
    // on the card itself, which React's row re-render tolerates.
    renderMode: "detached",
    source: "stub",
    discoveredAt: 0
  };
  var LINKEDIN_JOBS_STUB = {
    fingerprint: "site:linkedin:jobs:v1",
    layout: "list",
    itemSetSelector: "ul:has(> li.scaffold-layout__list-item)",
    itemSelector: "li.scaffold-layout__list-item",
    fields: {},
    source: "stub",
    discoveredAt: 0
  };
  var ALL_STUBS = [
    { schema: ROLECAST_STUB_SCHEMA },
    // The NEW LazyColumn layout must win over the legacy <ul>/<li> stub when
    // both happen to be on the page — the new container is only present on
    // /jobs/search-results/, the old <ul> is only present on /jobs/search/,
    // but probing the new one first is cheap and future-proofs the order
    // against pages that briefly carry both during a SPA transition.
    { schema: LINKEDIN_JOBS_NEW_STUB, hostIncludes: "linkedin." },
    { schema: LINKEDIN_JOBS_STUB, hostIncludes: "linkedin." }
  ];
  function pickStubSchema(doc = document) {
    const host = doc.defaultView?.location?.hostname ?? "";
    for (const { schema, hostIncludes } of ALL_STUBS) {
      if (hostIncludes && !host.includes(hostIncludes)) continue;
      try {
        if (doc.querySelector(schema.itemSetSelector)) return schema;
      } catch {
      }
    }
    return null;
  }

  // extension/content/deep-text.ts
  function itemDetailUrl(item) {
    const componentHost = item.matches('[componentkey^="job-card-component-ref-"]') ? item : item.querySelector('[componentkey^="job-card-component-ref-"]');
    const componentKey = componentHost?.getAttribute("componentkey") ?? "";
    const newLayoutMatch = componentKey.match(/^job-card-component-ref-(\d+)$/);
    if (newLayoutMatch) {
      return `https://www.linkedin.com/jobs-guest/jobs/api/jobPosting/${newLayoutMatch[1]}`;
    }
    const idHost = item.matches("[data-occludable-job-id]") ? item : item.querySelector("[data-occludable-job-id]") ?? (item.matches("[data-job-id]") ? item : item.querySelector("[data-job-id]"));
    const jobId = idHost?.getAttribute("data-occludable-job-id") ?? idHost?.getAttribute("data-job-id");
    if (jobId && /^\d+$/.test(jobId)) {
      return `https://www.linkedin.com/jobs-guest/jobs/api/jobPosting/${jobId}`;
    }
    const jobLink = item.querySelector('a[href*="/jobs/view/"]');
    const m = (jobLink?.getAttribute("href") ?? "").match(/\/jobs\/view\/(\d+)/);
    if (m) return `https://www.linkedin.com/jobs-guest/jobs/api/jobPosting/${m[1]}`;
    const anchor = item.querySelector("a[href]");
    const href = anchor?.getAttribute("href") ?? "";
    if (href && !href.startsWith("#") && !href.startsWith("javascript:")) {
      try {
        const loc = item.ownerDocument?.defaultView?.location;
        const resolved = new URL(href, loc?.href);
        if (loc && resolved.origin !== loc.origin) return null;
        if (ACTION_LIKE_QUERY_RE.test(resolved.search)) return null;
        return resolved.toString();
      } catch {
        return null;
      }
    }
    return null;
  }
  var ACTION_LIKE_QUERY_RE = /(?:^|[?&])[^=&]*(?:action|delete|remove|logout|signout|sign-out|unsubscribe|confirm|approve|accept|dismiss|token|csrf)[^=&]*(?:=|&|$)/i;
  var NAMED_ENTITIES = {
    amp: "&",
    lt: "<",
    gt: ">",
    quot: '"',
    apos: "'",
    nbsp: " ",
    ndash: "\u2013",
    mdash: "\u2014",
    hellip: "\u2026",
    lsquo: "\u2018",
    rsquo: "\u2019",
    ldquo: "\u201C",
    rdquo: "\u201D"
  };
  function decodeCodePoint(cp) {
    try {
      return String.fromCodePoint(cp);
    } catch {
      return " ";
    }
  }
  function stripHtml(html) {
    return html.replace(/<(script|style|template)[^>]*>[\s\S]*?<\/\1>/gi, " ").replace(/<[^>]+>/g, " ").replace(/&#(\d+);/g, (_, d) => decodeCodePoint(parseInt(d, 10))).replace(/&#x([0-9a-f]+);/gi, (_, h) => decodeCodePoint(parseInt(h, 16))).replace(/&([a-z]+);/gi, (_, name) => NAMED_ENTITIES[name.toLowerCase()] ?? " ").replace(/\s+/g, " ").trim();
  }
  async function fetchDetailResult(url, fetcher = globalThis.fetch.bind(globalThis)) {
    try {
      const res = await fetcher(url, { credentials: "same-origin" });
      if (res.status === 429) return { text: null, rateLimited: true };
      if (!res.ok) return { text: null, rateLimited: false };
      const html = await res.text();
      const text = stripHtml(html);
      return { text: text.length > 0 ? text : null, rateLimited: false };
    } catch {
      return { text: null, rateLimited: false };
    }
  }
  var sharedTextCache = /* @__PURE__ */ new Map();
  var MAX_TEXT_CACHE_ENTRIES = 200;
  var sharedInFlight = /* @__PURE__ */ new Set();
  var sharedCooldown = { until: 0, consecutive: 0 };
  var DEFAULT_BACKOFF_MS = [4e3, 8e3, 16e3, 32e3, 6e4];
  var MAX_FETCH_ATTEMPTS = 4;
  var DeepTextScanner = class {
    onText;
    concurrency;
    spacingMs;
    fetchDetail;
    backoffMs;
    /** url → resolved text. Usually the shared module-level cache. */
    cache;
    /** urls currently being fetched — shared across instances. */
    inFlight = sharedInFlight;
    /** pending work: [item, url]. */
    queue = [];
    attempts = /* @__PURE__ */ new Map();
    active = 0;
    stopped = false;
    backoffTimer = null;
    constructor(opts) {
      this.onText = opts.onText;
      this.concurrency = opts.concurrency ?? 3;
      this.spacingMs = opts.spacingMs ?? 250;
      this.backoffMs = opts.backoffMs ?? DEFAULT_BACKOFF_MS;
      this.fetchDetail = opts.fetchDetail ?? (opts.fetchText ? async (u) => ({ text: await opts.fetchText(u), rateLimited: false }) : (u) => fetchDetailResult(u));
      this.cache = opts.cache ?? sharedTextCache;
    }
    /** Enqueue any items with a detail URL not already cached/in-flight. Items
     *  whose text is already cached are re-delivered to onText synchronously so
     *  a fresh evaluation picks them up without refetching. New work is ordered
     *  viewport-first: the origin's rate limit (~20 requests/window on
     *  LinkedIn) means we may only get a handful of fetches — spend them on
     *  the cards the user is looking at. */
    scan(items) {
      if (this.stopped) return;
      const fresh = [];
      for (const item of items) {
        const url = itemDetailUrl(item);
        if (!url) continue;
        const cached = this.cacheGet(url);
        if (cached !== void 0) {
          this.onText(item, cached);
          continue;
        }
        if (this.inFlight.has(url)) continue;
        if (this.queue.some(([, u]) => u === url)) continue;
        if ((this.attempts.get(url) ?? 0) >= MAX_FETCH_ATTEMPTS) continue;
        fresh.push([item, url]);
      }
      fresh.sort((a, b) => viewportDistance(a[0]) - viewportDistance(b[0]));
      this.queue.push(...fresh);
      this.pump();
    }
    stop() {
      this.stopped = true;
      this.queue.length = 0;
      if (this.backoffTimer !== null) {
        clearTimeout(this.backoffTimer);
        this.backoffTimer = null;
      }
    }
    pump() {
      if (this.stopped) return;
      const now = Date.now();
      if (now < sharedCooldown.until) {
        if (this.backoffTimer === null && this.queue.length > 0) {
          this.backoffTimer = setTimeout(() => {
            this.backoffTimer = null;
            this.pump();
          }, sharedCooldown.until - now + 50);
        }
        return;
      }
      while (!this.stopped && this.active < this.concurrency && this.queue.length > 0) {
        const next = this.queue.shift();
        if (!next) break;
        void this.run(next[0], next[1]);
      }
    }
    /** Read with LRU recency: Map iteration order is insertion order, so
     *  re-inserting on hit keeps the oldest-used entry first for eviction. */
    cacheGet(url) {
      const text = this.cache.get(url);
      if (text !== void 0) {
        this.cache.delete(url);
        this.cache.set(url, text);
      }
      return text;
    }
    cacheSet(url, text) {
      if (!this.cache.has(url) && this.cache.size >= MAX_TEXT_CACHE_ENTRIES) {
        const oldest = this.cache.keys().next();
        if (!oldest.done) this.cache.delete(oldest.value);
      }
      this.cache.set(url, text);
    }
    async run(item, url) {
      this.active += 1;
      this.inFlight.add(url);
      this.attempts.set(url, (this.attempts.get(url) ?? 0) + 1);
      try {
        const result = await this.fetchDetail(url);
        if (result.rateLimited) {
          const now = Date.now();
          if (now >= sharedCooldown.until) {
            const step = Math.min(sharedCooldown.consecutive, this.backoffMs.length - 1);
            sharedCooldown.consecutive += 1;
            sharedCooldown.until = now + (this.backoffMs[step] ?? 6e4);
          }
          if (!this.stopped && (this.attempts.get(url) ?? 0) < MAX_FETCH_ATTEMPTS) {
            this.queue.push([item, url]);
          }
        } else {
          sharedCooldown.consecutive = 0;
          if (result.text !== null) {
            this.cacheSet(url, result.text);
            if (!this.stopped) this.onText(item, result.text);
          }
        }
      } finally {
        this.inFlight.delete(url);
        this.active -= 1;
        if (this.spacingMs > 0) {
          setTimeout(() => this.pump(), this.spacingMs);
        } else {
          this.pump();
        }
      }
    }
  };
  function viewportDistance(item) {
    const top = item.getBoundingClientRect().top;
    return top >= 0 ? top : -top * 2;
  }

  // extension/content/suggest.ts
  var MIN_ITEMS = 2;
  var MAX_ITEM_FRACTION = 0.9;
  var MIN_ITEM_FRACTION = 0.15;
  var MIN_UNIGRAM_LEN = 4;
  var MIN_BIGRAM_WORD_LEN = 3;
  var STOPWORDS = /* @__PURE__ */ new Set([
    "the",
    "and",
    "for",
    "with",
    "you",
    "are",
    "this",
    "that",
    "from",
    "will",
    "have",
    "has",
    "had",
    "was",
    "were",
    "been",
    "being",
    "but",
    "not",
    "all",
    "any",
    "can",
    "our",
    "your",
    "their",
    "they",
    "them",
    "then",
    "than",
    "when",
    "where",
    "what",
    "which",
    "who",
    "why",
    "how",
    "its",
    "his",
    "her",
    "she",
    "him",
    "out",
    "into",
    "over",
    "more",
    "most",
    "some",
    "such",
    "only",
    "also",
    "just",
    "very",
    "about",
    "after",
    "before",
    "between",
    "each",
    "other",
    "there",
    "here",
    "while",
    "during",
    "both",
    "per",
    "via"
  ]);
  function isPureNumber(word) {
    return /^\d+$/.test(word);
  }
  function isLettersOnly(word) {
    return /^[a-zA-Z]+$/.test(word);
  }
  function suggestFromItems(items, detailText, existing, max = 8) {
    if (items.length < MIN_ITEMS) return [];
    const excluded = new Set(existing.map((p) => p.trim().toLowerCase()));
    const stats = /* @__PURE__ */ new Map();
    const record = (key, form, isBigram, seenThisItem) => {
      let s = stats.get(key);
      if (!s) {
        s = { docCount: 0, totalCount: 0, forms: /* @__PURE__ */ new Map(), isBigram };
        stats.set(key, s);
      }
      if (!seenThisItem.has(key)) {
        seenThisItem.add(key);
        s.docCount += 1;
      }
      s.totalCount += 1;
      s.forms.set(form, (s.forms.get(form) ?? 0) + 1);
    };
    for (const item of items) {
      const base = (item.textContent ?? "").replace(/\s+/g, " ").trim();
      const detail = detailText?.get(item);
      const corpus = detail ? `${base} ${detail.replace(/\s+/g, " ").trim()}` : base;
      const words = corpus.match(/[a-zA-Z0-9]+/g) ?? [];
      const seen = /* @__PURE__ */ new Set();
      for (let i = 0; i < words.length; i++) {
        const w = words[i];
        const lw = w.toLowerCase();
        if (isLettersOnly(w) && w.length >= MIN_UNIGRAM_LEN && !STOPWORDS.has(lw) && !excluded.has(lw)) {
          record(lw, w, false, seen);
        }
        const next = words[i + 1];
        if (next === void 0) continue;
        const lnext = next.toLowerCase();
        if (w.length >= MIN_BIGRAM_WORD_LEN && next.length >= MIN_BIGRAM_WORD_LEN && !isPureNumber(w) && !isPureNumber(next) && !STOPWORDS.has(lw) && !STOPWORDS.has(lnext)) {
          const key = `${lw} ${lnext}`;
          if (!excluded.has(key)) record(key, `${w} ${next}`, true, seen);
        }
      }
    }
    const ceiling = Math.floor(items.length * MAX_ITEM_FRACTION);
    const floor = Math.max(MIN_ITEMS, Math.ceil(items.length * MIN_ITEM_FRACTION));
    const kept = [...stats.entries()].filter(
      ([, s]) => s.docCount >= floor && s.docCount <= ceiling
    );
    kept.sort(([ka, a], [kb, b]) => {
      if (a.docCount !== b.docCount) return b.docCount - a.docCount;
      if (a.isBigram !== b.isBigram) return a.isBigram ? 1 : -1;
      if (a.totalCount !== b.totalCount) return b.totalCount - a.totalCount;
      return ka < kb ? -1 : ka > kb ? 1 : 0;
    });
    const selectedUnigrams = /* @__PURE__ */ new Set();
    const selected = [];
    for (const entry of kept) {
      if (selected.length >= max) break;
      const [key, s] = entry;
      if (s.isBigram && key.split(" ").some((w) => selectedUnigrams.has(w))) continue;
      if (!s.isBigram) selectedUnigrams.add(key);
      selected.push(entry);
    }
    return selected.map(([, s]) => {
      let bestForm = "";
      let bestCount = -1;
      for (const [form, count] of s.forms) {
        if (count > bestCount) {
          bestForm = form;
          bestCount = count;
        }
      }
      return bestForm;
    });
  }

  // extension/shared/saved-filters.ts
  var KEY_PREFIX = "nf:filters:";
  function keyFor(fingerprint) {
    return KEY_PREFIX + fingerprint;
  }
  function isFilterShape(x) {
    if (typeof x !== "object" || x === null) return false;
    const r = x;
    if (typeof r["id"] !== "string") return false;
    if (typeof r["fingerprint"] !== "string") return false;
    if (r["polarity"] !== "exclude" && r["polarity"] !== "keep") return false;
    if (typeof r["field"] !== "string") return false;
    if (typeof r["predicate"] !== "object" || r["predicate"] === null) return false;
    if (typeof r["deep"] !== "boolean") return false;
    if (typeof r["saved"] !== "boolean") return false;
    return true;
  }
  async function loadSavedFilters(fingerprint) {
    const key = keyFor(fingerprint);
    const r = await chrome.storage.sync.get(key);
    const raw = r[key];
    if (!Array.isArray(raw)) return [];
    return raw.filter(isFilterShape);
  }

  // extension/content/index.ts
  var LOG_PREFIX = "[sieve]";
  var TIMING_ON = (() => {
    try {
      return localStorage.getItem("nf-timing") === "1";
    } catch {
      return false;
    }
  })();
  function tlog(event, extra) {
    if (!TIMING_ON) return;
    const suffix = extra ? ` ${JSON.stringify(extra)}` : "";
    console.log(`[sieve-timing] ${event} @${Math.round(performance.now())}ms${suffix}`);
  }
  var ctx = null;
  function hasPhraseFilter(c) {
    return c.filters.some(
      (f) => f.field === ALL_TEXT_FIELD && f.predicate.op === "containsAny" && f.predicate.phrases.length > 0
    );
  }
  function maybeScanDescriptions(c) {
    if (!c.scanner) return;
    if (!hasPhraseFilter(c)) return;
    c.scanner.scan(c.items);
    if (c.rescanTimer !== null) return;
    c.rescanTimer = setTimeout(() => {
      c.rescanTimer = null;
      if (ctx !== c || !c.scanner || !hasPhraseFilter(c)) return;
      const missing = c.items.some((el) => el.isConnected && !c.detailText.has(el));
      if (missing) c.scanner.scan(c.items);
    }, 12e3);
  }
  async function hydrateSavedFilters(c) {
    try {
      const saved = await loadSavedFilters(c.schema.fingerprint);
      if (saved.length === 0) return;
      c.filters = saved;
      recompute(c);
      tlog("hydrateSavedFilters:applied", {
        filters: saved.length,
        filtered: c.summaries.filter((s) => s.state === "filtered").length
      });
      maybeScanDescriptions(c);
      pushToPanel({
        t: "pageDetected",
        v: MESSAGE_VERSION,
        layout: c.schema.layout,
        count: c.summaries.length,
        fingerprint: c.schema.fingerprint
      });
    } catch (err) {
      console.error("[sieve] loadSavedFilters failed:", err);
    }
  }
  function recompute(c) {
    const verdicts = evaluate(c.schema, c.items, c.filters, c.detailText, (err) => {
      pushToPanel({
        t: "filterError",
        v: MESSAGE_VERSION,
        filterId: err.filterId,
        message: err.message
      });
    });
    c.summaries = c.renderer.apply(verdicts);
    pushToPanel({ t: "itemStates", v: MESSAGE_VERSION, items: c.summaries });
  }
  function emitItemStates(c) {
    c.summaries = c.renderer.summaries();
    pushToPanel({ t: "itemStates", v: MESSAGE_VERSION, items: c.summaries });
  }
  function handlePanelMessage(msg) {
    if (!ctx) {
      if (msg.t === "getState") {
        const empty = { schema: null, filters: [], mode: "collapse", items: [] };
        return { t: "state", v: MESSAGE_VERSION, state: empty };
      }
      if (msg.t === "rediscover") {
        void tryDiscover({
          ...msg.hint !== void 0 ? { hint: msg.hint } : {},
          force: true,
          bypassStub: true
        });
        return { t: "ack", v: MESSAGE_VERSION };
      }
      if (msg.t === "spaNavigated") {
        handleSpaUrlChange();
        return { t: "ack", v: MESSAGE_VERSION };
      }
      if (msg.t === "getSuggestions") {
        return { t: "suggestions", v: MESSAGE_VERSION, phrases: [] };
      }
      return { t: "err", v: MESSAGE_VERSION, message: "no schema for this page" };
    }
    switch (msg.t) {
      case "getState": {
        const state = {
          schema: ctx.schema,
          filters: ctx.filters,
          mode: ctx.mode,
          items: ctx.summaries
        };
        return { t: "state", v: MESSAGE_VERSION, state };
      }
      case "setFilters":
        ctx.filters = msg.filters;
        recompute(ctx);
        maybeScanDescriptions(ctx);
        return { t: "ack", v: MESSAGE_VERSION };
      case "setDisplayMode":
        ctx.mode = msg.mode;
        ctx.renderer.setMode(msg.mode);
        return { t: "ack", v: MESSAGE_VERSION };
      case "setItemRestored":
        ctx.renderer.setRestored(msg.itemId, msg.restored);
        emitItemStates(ctx);
        return { t: "ack", v: MESSAGE_VERSION };
      case "rediscover":
        void tryDiscover({
          ...msg.hint !== void 0 ? { hint: msg.hint } : {},
          ...msg.force === true ? { force: true } : {},
          bypassStub: true
        });
        return { t: "ack", v: MESSAGE_VERSION };
      case "getSuggestions": {
        const existing = ctx.filters.flatMap(
          (f) => f.predicate.op === "containsAny" ? f.predicate.phrases : []
        );
        const phrases = suggestFromItems(
          ctx.items.filter((el) => el.isConnected),
          ctx.detailText,
          existing,
          msg.max
        );
        return { t: "suggestions", v: MESSAGE_VERSION, phrases };
      }
      case "spaNavigated":
        handleSpaUrlChange();
        return { t: "ack", v: MESSAGE_VERSION };
    }
  }
  function attachMessageBridge() {
    chrome.runtime.onMessage.addListener((raw, _sender, sendResponse) => {
      if (!isPanelToContent(raw)) return false;
      sendResponse(handlePanelMessage(raw));
      return false;
    });
  }
  async function roundTripPing() {
    try {
      const reply = await sendToSw({ t: "ping", v: MESSAGE_VERSION });
      console.log(`${LOG_PREFIX} SW round-trip:`, reply);
    } catch (err) {
      console.error(`${LOG_PREFIX} SW round-trip failed:`, err);
    }
  }
  function mount(schema, itemSet, opts = {}) {
    if (!opts.forceRemount && ctx !== null && ctx.itemSet === itemSet && itemSet.isConnected && ctx.schema.fingerprint === schema.fingerprint) {
      tlog("mount:skip-unchanged", { fp: schema.fingerprint });
      return;
    }
    tlog("mount:start", { fp: schema.fingerprint, source: schema.source });
    const carry = ctx && ctx.schema.fingerprint === schema.fingerprint ? { filters: ctx.filters, mode: ctx.mode } : null;
    if (ctx) {
      ctx.watcher?.stop();
      ctx.scanner?.stop();
      if (ctx.rescanTimer !== null) clearTimeout(ctx.rescanTimer);
      ctx.renderer.disconnect();
      ctx = null;
    }
    const renderer = new Renderer({
      schema,
      itemSet,
      onRestoreToggle: (id, restored) => {
        renderer.setRestored(id, restored);
        if (ctx) emitItemStates(ctx);
      }
    });
    if (carry) renderer.setMode(carry.mode);
    ctx = {
      schema,
      itemSet,
      renderer,
      items: findItems(schema, document, itemSet),
      filters: carry?.filters ?? [],
      mode: carry?.mode ?? "collapse",
      summaries: [],
      watcher: null,
      detailText: /* @__PURE__ */ new Map(),
      scanner: null,
      rescanTimer: null
    };
    let repaintQueued = false;
    ctx.scanner = new DeepTextScanner({
      onText: (item, text) => {
        if (!ctx) return;
        ctx.detailText.set(item, text);
        if (repaintQueued) return;
        repaintQueued = true;
        setTimeout(() => {
          repaintQueued = false;
          if (ctx) recompute(ctx);
        }, 150);
      }
    });
    tlog("mount:items", { items: ctx.items.length, filters: ctx.filters.length });
    recompute(ctx);
    tlog("mount:firstRecompute", {
      filtered: ctx.summaries.filter((s) => s.state === "filtered").length
    });
    pushToPanel({
      t: "pageDetected",
      v: MESSAGE_VERSION,
      layout: schema.layout,
      count: ctx.summaries.length,
      fingerprint: schema.fingerprint
    });
    ctx.watcher = new MutationWatcher({
      itemSet,
      itemSelector: schema.itemSelector,
      onItemsAdded: (added) => {
        if (!ctx) return;
        const next = new Set(ctx.items.filter((el) => el.isConnected));
        for (const el of added) next.add(el);
        ctx.items = [...next];
        for (const el of ctx.detailText.keys()) {
          if (!el.isConnected) ctx.detailText.delete(el);
        }
        recompute(ctx);
        maybeScanDescriptions(ctx);
      }
    });
    ctx.watcher.start();
    if (carry) {
      maybeScanDescriptions(ctx);
    } else {
      void hydrateSavedFilters(ctx);
    }
  }
  async function fetchSchemaViaSw(req) {
    const msg = {
      t: "discoverSchema",
      v: MESSAGE_VERSION,
      fingerprint: req.fingerprint,
      distilled: req.distilled,
      layout: req.layout
    };
    if (req.hint !== void 0) msg.hint = req.hint;
    if (req.force === true) msg.force = true;
    const reply = await sendToSw(msg);
    if (reply.t === "schema") return reply.schema;
    if (reply.t === "err") throw new Error(reply.message);
    throw new Error(`unexpected SW reply: ${reply.t}`);
  }
  var discoverState = {
    inFlight: false,
    succeeded: false,
    mutationObserver: null,
    giveUpTimer: null
  };
  async function attemptDiscover(opts) {
    const forceRemount = opts.bypassStub === true;
    if (opts.bypassStub !== true) {
      const stub = pickStubSchema();
      if (stub) {
        const stubItemSet = document.querySelector(stub.itemSetSelector);
        if (stubItemSet) {
          mount(stub, stubItemSet, { forceRemount });
          return true;
        }
      }
    }
    const discoverOpts = {};
    if (opts.hint !== void 0) discoverOpts.hint = opts.hint;
    if (opts.force === true) discoverOpts.force = true;
    try {
      const result = await discover(
        document,
        { fetchSchema: (r) => fetchSchemaViaSw(r) },
        discoverOpts
      );
      if (!result) return false;
      mount(result.schema, result.itemSet, { forceRemount });
      return true;
    } catch (err) {
      const local = buildLocalSchema(document);
      if (local) {
        console.warn(
          `${LOG_PREFIX} LLM discovery failed (${err instanceof Error ? err.message : String(err)}); using local detection.`
        );
        mount(local.schema, local.itemSet, { forceRemount });
        return true;
      }
      throw err;
    }
  }
  async function tryDiscover(opts = {}) {
    if (opts.force === true) {
      teardownDiscoverWatcher();
      discoverState.succeeded = false;
      discoverState.inFlight = false;
    }
    if (discoverState.inFlight || discoverState.succeeded) return;
    discoverState.inFlight = true;
    try {
      try {
        if (await attemptDiscover(opts)) {
          discoverState.succeeded = true;
          return;
        }
      } catch (err) {
      }
      installDiscoverWatcher(opts);
    } finally {
      discoverState.inFlight = false;
    }
  }
  var GIVE_UP_MS = 6e4;
  var MIN_MUTATION_RETRY_INTERVAL_MS = 750;
  function installDiscoverWatcher(opts) {
    if (discoverState.mutationObserver) return;
    let lastAttemptAt = 0;
    let retryQueued = false;
    const attempt = async () => {
      if (discoverState.succeeded) return;
      if (Date.now() - lastAttemptAt < MIN_MUTATION_RETRY_INTERVAL_MS) {
        if (retryQueued) return;
        retryQueued = true;
        setTimeout(() => {
          retryQueued = false;
          void attempt();
        }, MIN_MUTATION_RETRY_INTERVAL_MS);
        return;
      }
      lastAttemptAt = Date.now();
      try {
        if (await attemptDiscover(opts)) {
          discoverState.succeeded = true;
          teardownDiscoverWatcher();
        }
      } catch {
      }
    };
    const observer = new MutationObserver((records) => {
      for (const r of records) {
        if (r.addedNodes.length > 0) {
          void attempt();
          return;
        }
      }
    });
    observer.observe(document.body ?? document.documentElement, {
      childList: true,
      subtree: true
    });
    discoverState.mutationObserver = observer;
    discoverState.giveUpTimer = setTimeout(() => {
      if (!discoverState.succeeded) {
        pushToPanel({
          t: "discoverError",
          v: MESSAGE_VERSION,
          message: "no item-set detected after 60s \u2014 try Re-discover with a one-line hint about which list to filter."
        });
      }
      teardownDiscoverWatcher();
    }, GIVE_UP_MS);
  }
  function teardownDiscoverWatcher() {
    discoverState.mutationObserver?.disconnect();
    discoverState.mutationObserver = null;
    if (discoverState.giveUpTimer !== null) {
      clearTimeout(discoverState.giveUpTimer);
      discoverState.giveUpTimer = null;
    }
  }
  var lastSpaUrl = location.href;
  var spaDebounceTimer = null;
  function handleSpaUrlChange() {
    if (location.href === lastSpaUrl) return;
    lastSpaUrl = location.href;
    tlog("spaUrlChange:queued", { href: location.href });
    if (spaDebounceTimer !== null) clearTimeout(spaDebounceTimer);
    spaDebounceTimer = setTimeout(() => {
      spaDebounceTimer = null;
      tlog("spaUrlChange:fire-rediscover");
      console.log(`${LOG_PREFIX} url changed \u2192 re-detect (${location.href})`);
      discoverState.succeeded = false;
      teardownDiscoverWatcher();
      void tryDiscover({ force: true });
    }, 1200);
  }
  function installSpaNavigationWatcher() {
    for (const m of ["pushState", "replaceState"]) {
      const original = history[m];
      history[m] = function patched(...args) {
        const r = original.apply(this, args);
        setTimeout(handleSpaUrlChange, 0);
        return r;
      };
    }
    window.addEventListener("popstate", () => setTimeout(handleSpaUrlChange, 0));
  }
  function init() {
    const w = window;
    if (w.__nfContentInitialized) {
      console.log(`${LOG_PREFIX} content script already initialized \u2014 skipping re-init`);
      return;
    }
    w.__nfContentInitialized = true;
    tlog("init:start");
    attachMessageBridge();
    installSpaNavigationWatcher();
    const schema = pickStubSchema();
    if (schema) {
      const itemSet = document.querySelector(schema.itemSetSelector);
      if (itemSet) {
        mount(schema, itemSet);
        console.log(
          `${LOG_PREFIX} stub matched ${schema.fingerprint} (${ctx?.items.length ?? 0} items) at ${location.href}`
        );
      } else {
        console.log(
          `${LOG_PREFIX} stub schema picked (${schema.fingerprint}) but item-set selector not present yet; will retry`
        );
        void tryDiscover();
      }
    } else {
      console.log(`${LOG_PREFIX} no stub matched; running discovery on ${location.href}`);
      void tryDiscover();
    }
    void roundTripPing();
  }
  init();
})();
//# sourceMappingURL=content.js.map
