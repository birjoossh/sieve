"use strict";
(() => {
  // extension/panel/components/settings.ts
  function hostnameOf(origin) {
    try {
      return new URL(origin).hostname;
    } catch {
      return origin;
    }
  }
  function makeButton() {
    const btn = document.createElement("button");
    btn.dataset["action"] = "enable-site";
    btn.className = "enable-site btn";
    return btn;
  }
  function renderEnableButton(host, state2) {
    host.replaceChildren();
    const btn = makeButton();
    if (state2.origin === null) {
      const wrap2 = document.createElement("div");
      wrap2.className = "first-run";
      const title2 = document.createElement("h2");
      title2.className = "first-run-title";
      title2.textContent = "Hide what you don\u2019t want to see";
      wrap2.appendChild(title2);
      const body2 = document.createElement("p");
      body2.className = "first-run-body";
      body2.textContent = "Open a regular website tab \u2014 a job board, search results, a feed \u2014 and Negative Filter can hide the items you don\u2019t care about.";
      wrap2.appendChild(body2);
      btn.textContent = "No enableable site";
      btn.disabled = true;
      btn.dataset["enabled"] = "false";
      btn.classList.add("btn-secondary", "btn-block");
      wrap2.appendChild(btn);
      host.appendChild(wrap2);
      return;
    }
    const origin = state2.origin;
    const hostname = hostnameOf(origin);
    btn.disabled = false;
    if (state2.enabled) {
      const row = document.createElement("div");
      row.className = "site-row";
      const badge = document.createElement("span");
      badge.className = "badge badge-ok";
      badge.textContent = "Active";
      row.appendChild(badge);
      btn.textContent = `Disable on ${hostname}`;
      btn.dataset["enabled"] = "true";
      btn.classList.add("btn-ghost", "btn-sm");
      btn.onclick = () => state2.onDisable?.(origin);
      row.appendChild(btn);
      host.appendChild(row);
      return;
    }
    const wrap = document.createElement("div");
    wrap.className = "first-run";
    const title = document.createElement("h2");
    title.className = "first-run-title";
    title.textContent = "Hide what you don\u2019t want to see";
    wrap.appendChild(title);
    const body = document.createElement("p");
    body.className = "first-run-body";
    body.textContent = "Negative Filter hides items from list pages \u2014 job boards, search results, feeds \u2014 based on phrases and limits you choose. Turn it on for this site to start.";
    wrap.appendChild(body);
    btn.textContent = `Enable on ${hostname}`;
    btn.dataset["enabled"] = "false";
    btn.classList.add("btn-primary", "btn-block");
    btn.onclick = () => state2.onEnable?.(origin);
    wrap.appendChild(btn);
    const note = document.createElement("p");
    note.className = "hint";
    note.textContent = "If nothing changes right away, reload the tab once after enabling.";
    wrap.appendChild(note);
    host.appendChild(wrap);
  }

  // extension/panel/components/filter-list.ts
  function renderFilterList(host, state2) {
    host.replaceChildren();
    const h = document.createElement("h2");
    h.className = "section-h";
    h.textContent = "Filters";
    host.appendChild(h);
    if (!state2.enabled) {
      const p = document.createElement("p");
      p.className = "section-meta";
      p.textContent = "Filters become available once a list is detected on this page.";
      host.appendChild(p);
      return;
    }
    const polarity = state2.polarity ?? "exclude";
    const meta = document.createElement("p");
    meta.className = "section-meta";
    meta.textContent = polarity === "keep" ? "Show only items whose text contains any of these phrases:" : polarity === "off" ? "Filtering is off \u2014 your phrases are kept but not applied." : "Hide items whose text contains any of these phrases:";
    host.appendChild(meta);
    if (state2.onPolarityChange) {
      const onPolarityChange = state2.onPolarityChange;
      const seg = document.createElement("div");
      seg.className = "polarity-toggle";
      seg.dataset["role"] = "filter-polarity";
      seg.setAttribute("role", "group");
      seg.setAttribute("aria-label", "Filter polarity");
      const LABELS = {
        exclude: "Hide matches",
        keep: "Show only matches",
        off: "Off"
      };
      for (const p of ["exclude", "keep", "off"]) {
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "polarity-btn";
        btn.dataset["polarity"] = p;
        btn.dataset["input"] = "polarity";
        btn.textContent = LABELS[p];
        btn.setAttribute("aria-pressed", String(polarity === p));
        if (polarity === p) btn.classList.add("active");
        btn.onclick = () => onPolarityChange(p);
        seg.appendChild(btn);
      }
      host.appendChild(seg);
    }
    const chips = document.createElement("div");
    chips.className = "chips";
    chips.dataset["role"] = "phrase-chips";
    for (const phrase of state2.phrases) {
      const chip = document.createElement("span");
      chip.className = "chip";
      chip.dataset["phrase"] = phrase;
      const label = document.createElement("span");
      label.className = "chip-label";
      label.textContent = phrase;
      chip.appendChild(label);
      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "chip-remove";
      remove.dataset["action"] = "remove-phrase";
      remove.dataset["phrase"] = phrase;
      remove.setAttribute("aria-label", `remove ${phrase}`);
      remove.textContent = "\xD7";
      remove.onclick = () => state2.onChange(state2.phrases.filter((p) => p !== phrase));
      chip.appendChild(remove);
      chips.appendChild(chip);
    }
    host.appendChild(chips);
    const form = document.createElement("form");
    form.className = "phrase-form";
    form.dataset["role"] = "add-phrase";
    const input = document.createElement("input");
    input.type = "text";
    input.className = "phrase-input input";
    input.placeholder = "Add a phrase to hide\u2026";
    input.dataset["input"] = "phrase";
    input.setAttribute("aria-label", "Phrase to hide");
    input.autocomplete = "off";
    form.appendChild(input);
    const add = document.createElement("button");
    add.type = "submit";
    add.className = "phrase-add btn btn-secondary";
    add.textContent = "Add";
    form.appendChild(add);
    form.onsubmit = (e) => {
      e.preventDefault();
      const value = input.value.trim();
      if (value.length === 0) return;
      if (state2.phrases.includes(value)) {
        input.value = "";
        return;
      }
      state2.onChange([...state2.phrases, value]);
      input.value = "";
    };
    host.appendChild(form);
    if (state2.onSuggest) {
      const suggestRow = document.createElement("div");
      suggestRow.className = "suggest-row";
      suggestRow.dataset["role"] = "suggest-row";
      const suggestBtn = document.createElement("button");
      suggestBtn.type = "button";
      suggestBtn.className = "suggest-btn btn btn-ghost btn-sm";
      suggestBtn.dataset["action"] = "suggest-phrases";
      suggestBtn.textContent = state2.suggesting ? "\u2726 Suggesting\u2026" : "\u2726 Suggest phrases";
      suggestBtn.disabled = !!state2.suggesting;
      suggestBtn.onclick = () => state2.onSuggest?.();
      suggestRow.appendChild(suggestBtn);
      if (state2.suggestError) {
        const err = document.createElement("span");
        err.className = "suggest-error";
        err.dataset["role"] = "suggest-error";
        err.textContent = state2.suggestError;
        suggestRow.appendChild(err);
      }
      host.appendChild(suggestRow);
      if (state2.suggestions && state2.suggestions.length > 0) {
        const list = document.createElement("div");
        list.className = "suggest-list";
        list.dataset["role"] = "suggest-list";
        for (const s of state2.suggestions) {
          const pill = document.createElement("span");
          pill.className = "suggest-pill";
          pill.dataset["suggestion"] = s;
          const label = document.createElement("span");
          label.className = "suggest-label";
          label.textContent = s;
          pill.appendChild(label);
          const accept = document.createElement("button");
          accept.type = "button";
          accept.className = "suggest-accept";
          accept.dataset["action"] = "accept-suggestion";
          accept.dataset["suggestion"] = s;
          accept.setAttribute("aria-label", `accept ${s}`);
          accept.textContent = "+";
          accept.onclick = () => state2.onAcceptSuggestion?.(s);
          pill.appendChild(accept);
          list.appendChild(pill);
        }
        if (state2.onDismissSuggestions) {
          const dismiss = document.createElement("button");
          dismiss.type = "button";
          dismiss.className = "suggest-dismiss btn btn-ghost btn-sm";
          dismiss.dataset["action"] = "dismiss-suggestions";
          dismiss.textContent = "Dismiss";
          dismiss.onclick = () => state2.onDismissSuggestions?.();
          list.appendChild(dismiss);
        }
        host.appendChild(list);
      }
    }
    if (state2.onSave) {
      const actions = document.createElement("div");
      actions.className = "filter-actions";
      actions.dataset["role"] = "save-row";
      const saveBtn = document.createElement("button");
      saveBtn.type = "button";
      saveBtn.className = "filter-save btn btn-secondary btn-sm";
      saveBtn.dataset["action"] = "save-filters";
      saveBtn.textContent = "Save filters";
      saveBtn.onclick = () => state2.onSave?.();
      actions.appendChild(saveBtn);
      if (state2.onExport) {
        const exportBtn = document.createElement("button");
        exportBtn.type = "button";
        exportBtn.className = "filter-export btn btn-ghost btn-sm";
        exportBtn.dataset["action"] = "export-filters";
        exportBtn.textContent = "Export";
        exportBtn.onclick = () => state2.onExport?.();
        actions.appendChild(exportBtn);
      }
      if (state2.onImport) {
        const importLabel = document.createElement("label");
        importLabel.className = "filter-import btn btn-ghost btn-sm";
        importLabel.dataset["role"] = "import-row";
        importLabel.textContent = "Import\u2026";
        const importInput = document.createElement("input");
        importInput.type = "file";
        importInput.className = "visually-hidden";
        importInput.dataset["input"] = "import-file";
        importInput.accept = "application/json,.json";
        importInput.setAttribute("aria-label", "Import filters file");
        importInput.onchange = () => {
          const file = importInput.files?.[0];
          if (file) state2.onImport?.(file);
          importInput.value = "";
        };
        importLabel.appendChild(importInput);
        actions.appendChild(importLabel);
      }
      if (state2.onClearSaved && state2.savedExists) {
        const clearBtn = document.createElement("button");
        clearBtn.type = "button";
        clearBtn.className = "filter-clear-saved btn btn-danger btn-sm";
        clearBtn.dataset["action"] = "clear-saved-filters";
        clearBtn.textContent = "Clear saved";
        clearBtn.onclick = () => state2.onClearSaved?.();
        actions.appendChild(clearBtn);
      }
      if (state2.savedExists) {
        const badge = document.createElement("span");
        badge.className = "filter-saved-badge badge badge-accent";
        badge.dataset["role"] = "saved-badge";
        badge.textContent = "Saved";
        actions.appendChild(badge);
      }
      host.appendChild(actions);
    }
  }

  // extension/panel/components/hidden-list.ts
  function renderHiddenList(host, state2) {
    host.replaceChildren();
    const hidden = state2.items.filter(
      (i) => i.state === "filtered" || i.state === "restored"
    );
    const restoredCount = hidden.filter((i) => i.state === "restored").length;
    const allRestored = hidden.length > 0 && restoredCount === hidden.length;
    const allHidden = hidden.length > 0 && restoredCount === 0;
    const head = document.createElement("div");
    head.className = "hidden-head";
    const h = document.createElement("h2");
    h.className = "section-h";
    h.textContent = `Hidden (${hidden.length})`;
    head.appendChild(h);
    if (hidden.length === 0) {
      host.appendChild(head);
      const p = document.createElement("p");
      p.className = "section-meta";
      p.textContent = "Nothing is hidden yet \u2014 items that match your filters will show up here.";
      host.appendChild(p);
      return;
    }
    const bulk = document.createElement("div");
    bulk.className = "bulk-actions";
    const restoreAll = document.createElement("button");
    restoreAll.type = "button";
    restoreAll.className = "bulk-btn btn btn-ghost btn-sm";
    restoreAll.dataset["action"] = "restore-all";
    restoreAll.textContent = "Restore all";
    restoreAll.disabled = allRestored;
    restoreAll.onclick = () => state2.onSetAll(true);
    bulk.appendChild(restoreAll);
    const hideAll = document.createElement("button");
    hideAll.type = "button";
    hideAll.className = "bulk-btn btn btn-ghost btn-sm";
    hideAll.dataset["action"] = "hide-all";
    hideAll.textContent = "Hide all";
    hideAll.disabled = allHidden;
    hideAll.onclick = () => state2.onSetAll(false);
    bulk.appendChild(hideAll);
    head.appendChild(bulk);
    host.appendChild(head);
    const ul = document.createElement("ul");
    ul.className = "hidden-list";
    ul.dataset["role"] = "hidden-list";
    for (const item of hidden) {
      const li = document.createElement("li");
      li.className = `hidden-row state-${item.state}`;
      li.dataset["itemId"] = item.id;
      li.dataset["state"] = item.state;
      const main = document.createElement("div");
      main.className = "hidden-row-main";
      const label = document.createElement("span");
      label.className = "item-label";
      label.textContent = item.label ?? item.id;
      main.appendChild(label);
      if (item.reason !== void 0) {
        const reason = document.createElement("span");
        reason.className = "item-reason";
        reason.textContent = `matched \u201C${item.reason}\u201D`;
        main.appendChild(reason);
      }
      li.appendChild(main);
      const restored = item.state === "restored";
      const toggle = document.createElement("button");
      toggle.type = "button";
      toggle.className = "row-toggle btn btn-ghost btn-sm";
      toggle.dataset["action"] = restored ? "hide" : "restore";
      toggle.dataset["itemId"] = item.id;
      toggle.textContent = restored ? "hide" : "restore";
      toggle.setAttribute(
        "aria-label",
        `${restored ? "hide" : "restore"} ${item.label ?? item.id}`
      );
      toggle.onclick = () => state2.onSetItem(item.id, !restored);
      li.appendChild(toggle);
      ul.appendChild(li);
    }
    host.appendChild(ul);
  }

  // extension/panel/components/llm-settings.ts
  var PROVIDERS = ["anthropic", "openai"];
  var PROVIDER_LABEL = {
    anthropic: "Anthropic",
    openai: "OpenAI"
  };
  function fieldRow(spec, control) {
    const row = document.createElement("div");
    row.className = "field";
    const label = document.createElement("label");
    label.className = "field-label";
    label.htmlFor = spec.id;
    label.textContent = spec.label;
    control.id = spec.id;
    row.appendChild(label);
    row.appendChild(control);
    return row;
  }
  function renderLlmSettings(host, state2) {
    const prevOpen = host.querySelector('details[data-role="llm-settings"]')?.open ?? false;
    host.replaceChildren();
    const details = document.createElement("details");
    details.className = "ai-settings";
    details.dataset["role"] = "llm-settings";
    details.open = prevOpen;
    const summary = document.createElement("summary");
    summary.className = "ai-summary";
    summary.textContent = "AI settings (optional)";
    details.appendChild(summary);
    const body = document.createElement("div");
    body.className = "ai-body";
    const hint = document.createElement("p");
    hint.className = "hint";
    hint.textContent = "Add your own provider key to unlock named-field and numeric filter discovery, plus phrase suggestions. Free-text filtering works without it.";
    body.appendChild(hint);
    const select = document.createElement("select");
    select.className = "select";
    select.dataset["input"] = "provider";
    for (const p of PROVIDERS) {
      const opt = document.createElement("option");
      opt.value = p;
      opt.textContent = PROVIDER_LABEL[p];
      if (state2.current?.provider === p) opt.selected = true;
      select.appendChild(opt);
    }
    if (state2.current === null) {
      select.value = "anthropic";
    }
    body.appendChild(fieldRow({ id: "llm-provider", label: "Provider" }, select));
    const keyInput = document.createElement("input");
    keyInput.className = "input";
    keyInput.type = "password";
    keyInput.dataset["input"] = "api-key";
    keyInput.placeholder = "sk-\u2026";
    keyInput.value = state2.current?.apiKey ?? "";
    keyInput.autocomplete = "off";
    body.appendChild(fieldRow({ id: "llm-api-key", label: "API key" }, keyInput));
    const modelInput = document.createElement("input");
    modelInput.className = "input";
    modelInput.type = "text";
    modelInput.dataset["input"] = "model";
    modelInput.placeholder = "Provider default";
    modelInput.value = state2.current?.model ?? "";
    body.appendChild(fieldRow({ id: "llm-model", label: "Model (optional)" }, modelInput));
    const baseUrlInput = document.createElement("input");
    baseUrlInput.className = "input";
    baseUrlInput.type = "text";
    baseUrlInput.dataset["input"] = "base-url";
    baseUrlInput.placeholder = "https://api.openai.com or https://openrouter.ai/api";
    baseUrlInput.value = state2.current?.baseUrl ?? "";
    baseUrlInput.autocomplete = "off";
    const baseUrlRow = fieldRow({ id: "llm-base-url", label: "Base URL (optional)" }, baseUrlInput);
    const openRouterPreset = document.createElement("button");
    openRouterPreset.type = "button";
    openRouterPreset.className = "base-url-preset btn btn-ghost btn-sm";
    openRouterPreset.dataset["action"] = "use-openrouter";
    openRouterPreset.textContent = "Use OpenRouter";
    openRouterPreset.addEventListener("click", () => {
      baseUrlInput.value = "https://openrouter.ai/api";
      baseUrlInput.focus();
    });
    baseUrlRow.appendChild(openRouterPreset);
    const syncPreset = () => {
      openRouterPreset.hidden = select.value !== "openai";
    };
    select.addEventListener("change", syncPreset);
    syncPreset();
    body.appendChild(baseUrlRow);
    const buttons = document.createElement("div");
    buttons.className = "llm-actions";
    const saveBtn = document.createElement("button");
    saveBtn.type = "button";
    saveBtn.className = "llm-save btn btn-primary btn-sm";
    saveBtn.dataset["action"] = "save-llm-settings";
    saveBtn.textContent = "Save";
    saveBtn.addEventListener("click", () => {
      const next = {
        provider: select.value,
        apiKey: keyInput.value
      };
      const model = modelInput.value.trim();
      if (model !== "") next.model = model;
      const baseUrl = baseUrlInput.value.trim();
      if (baseUrl !== "") next.baseUrl = baseUrl;
      state2.onSave(next);
    });
    buttons.appendChild(saveBtn);
    if (state2.onClear) {
      const clearBtn = document.createElement("button");
      clearBtn.type = "button";
      clearBtn.className = "llm-clear btn btn-ghost btn-sm";
      clearBtn.dataset["action"] = "clear-llm-settings";
      clearBtn.textContent = "Clear";
      clearBtn.addEventListener("click", () => state2.onClear?.());
      buttons.appendChild(clearBtn);
    }
    const configured = state2.current !== null;
    const status = document.createElement("span");
    status.className = configured ? "llm-status is-saved" : "llm-status";
    status.dataset["role"] = "llm-status";
    status.textContent = configured ? "Key saved" : "No key saved";
    buttons.appendChild(status);
    body.appendChild(buttons);
    if (state2.spend && state2.current !== null && state2.current.apiKey.trim() !== "") {
      const usage = document.createElement("p");
      usage.className = "llm-spend";
      usage.dataset["role"] = "spend-usage";
      usage.textContent = `Usage: ${state2.spend.dailyUsed} / ${state2.spend.dailyCap} today \xB7 ${state2.spend.monthlyUsed} / ${state2.spend.monthlyCap} this month`;
      body.appendChild(usage);
      if (state2.spend.capReached) {
        const warn = document.createElement("p");
        warn.className = "llm-spend-warn";
        warn.dataset["role"] = "spend-cap-warning";
        warn.textContent = state2.spend.cappedPeriod === "day" ? "Daily spend cap reached \u2014 discovery calls are paused until tomorrow." : "Monthly spend cap reached \u2014 discovery calls are paused until next month.";
        body.appendChild(warn);
      }
    }
    details.appendChild(body);
    host.appendChild(details);
  }

  // extension/panel/components/numeric-filter.ts
  var OP_LABELS = {
    lessThan: "below",
    greaterThan: "above"
  };
  function renderNumericFilter(host, state2) {
    host.replaceChildren();
    const h = document.createElement("h2");
    h.className = "section-h";
    h.textContent = "Numeric filter";
    host.appendChild(h);
    if (!state2.enabled) {
      const p = document.createElement("p");
      p.className = "section-meta";
      p.textContent = "Available when the detected list has numeric fields.";
      host.appendChild(p);
      return;
    }
    const enableRow = document.createElement("label");
    enableRow.className = "numeric-enable";
    const enableInput = document.createElement("input");
    enableInput.type = "checkbox";
    enableInput.dataset["input"] = "numeric-enabled";
    enableInput.checked = state2.current.enabled;
    enableInput.onchange = () => {
      state2.onChange({ ...state2.current, enabled: enableInput.checked });
    };
    enableRow.appendChild(enableInput);
    const enableText = document.createElement("span");
    enableText.textContent = `Filter by ${state2.label}`;
    enableRow.appendChild(enableText);
    host.appendChild(enableRow);
    const row = document.createElement("div");
    row.className = "numeric-row";
    row.dataset["role"] = "numeric-row";
    const hideLabel = document.createElement("span");
    hideLabel.className = "numeric-hide-label";
    hideLabel.textContent = "Hide";
    row.appendChild(hideLabel);
    const opSelect = document.createElement("select");
    opSelect.className = "numeric-op select";
    opSelect.dataset["input"] = "numeric-op";
    opSelect.setAttribute("aria-label", `Hide ${state2.label} below or above`);
    for (const op of ["lessThan", "greaterThan"]) {
      const opt = document.createElement("option");
      opt.value = op;
      opt.textContent = OP_LABELS[op];
      if (op === state2.current.op) opt.selected = true;
      opSelect.appendChild(opt);
    }
    opSelect.onchange = () => {
      state2.onChange({ ...state2.current, op: opSelect.value });
    };
    row.appendChild(opSelect);
    const value = document.createElement("input");
    value.type = "number";
    value.className = "numeric-value input";
    value.dataset["input"] = "numeric-value";
    value.setAttribute("aria-label", `${state2.label} threshold`);
    value.value = String(state2.current.value);
    value.oninput = () => {
      const n = Number(value.value);
      if (value.value !== "" && Number.isFinite(n)) {
        state2.onChange({ ...state2.current, value: n });
      }
    };
    row.appendChild(value);
    host.appendChild(row);
  }

  // extension/panel/components/page-status.ts
  function renderPageStatus(host, state2) {
    host.replaceChildren();
    const h = document.createElement("h2");
    h.className = "section-h";
    h.textContent = "Page";
    host.appendChild(h);
    const status = document.createElement("p");
    status.className = "section-meta";
    status.dataset["role"] = state2.schema ? "page-detected" : "page-empty";
    if (state2.schema) {
      status.textContent = `Detected: ${state2.schema.layout} \xB7 ${state2.itemCount} item${state2.itemCount === 1 ? "" : "s"}`;
    } else {
      status.textContent = "No list detected yet.";
    }
    host.appendChild(status);
    if (state2.onRediscover) {
      const rediscoverHandler = state2.onRediscover;
      const rediscover = document.createElement("div");
      rediscover.className = "rediscover";
      rediscover.dataset["role"] = "rediscover";
      const help = document.createElement("p");
      help.className = "hint";
      help.textContent = state2.schema ? "Wrong or missing items? Re-run detection \u2014 a short hint about the layout helps." : "Point detection at the list \u2014 a short hint like \u201Cjob cards in the main column\u201D helps.";
      rediscover.appendChild(help);
      const row = document.createElement("div");
      row.className = "rediscover-row";
      const hintInput = document.createElement("input");
      hintInput.type = "text";
      hintInput.dataset["input"] = "rediscover-hint";
      hintInput.placeholder = "e.g. \u201Ctitle is in the h3\u201D";
      hintInput.className = "rediscover-hint input";
      hintInput.setAttribute("aria-label", "Re-discover hint");
      row.appendChild(hintInput);
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "rediscover-btn btn btn-secondary";
      btn.dataset["action"] = "rediscover";
      btn.textContent = "Re-discover";
      btn.addEventListener("click", () => {
        const hint = hintInput.value.trim();
        const payload = { force: true };
        if (hint !== "") payload.hint = hint;
        rediscoverHandler(payload);
      });
      row.appendChild(btn);
      rediscover.appendChild(row);
      host.appendChild(rediscover);
    }
  }

  // extension/shared/settings.ts
  var STORAGE_KEY = "nf:llm-settings";
  var PLAIN_HTTP_HOSTS = /* @__PURE__ */ new Set(["localhost", "127.0.0.1", "[::1]", "::1"]);
  function baseUrlIssue(raw) {
    let url;
    try {
      url = new URL(raw);
    } catch {
      return `"${raw}" is not a valid URL`;
    }
    if (url.protocol === "https:") return null;
    if (url.protocol === "http:" && PLAIN_HTTP_HOSTS.has(url.hostname)) return null;
    return `base URL must use https:// (http:// is allowed only for localhost / 127.0.0.1)`;
  }
  async function loadLlmSettings() {
    const r = await chrome.storage.local.get([STORAGE_KEY]);
    const v = r[STORAGE_KEY];
    if (!v || typeof v !== "object") return null;
    const obj = v;
    if (obj["provider"] !== "anthropic" && obj["provider"] !== "openai") return null;
    if (typeof obj["apiKey"] !== "string") return null;
    const out = {
      provider: obj["provider"],
      apiKey: obj["apiKey"]
    };
    if (typeof obj["model"] === "string" && obj["model"].trim() !== "") {
      out.model = obj["model"];
    }
    if (typeof obj["baseUrl"] === "string" && obj["baseUrl"].trim() !== "") {
      out.baseUrl = obj["baseUrl"].trim();
    }
    return out;
  }
  async function saveLlmSettings(settings) {
    await chrome.storage.local.set({ [STORAGE_KEY]: settings });
  }
  async function clearLlmSettings() {
    await chrome.storage.local.remove(STORAGE_KEY);
  }

  // extension/shared/saved-filters.ts
  var KEY_PREFIX = "nf:filters:";
  function keyFor(fingerprint) {
    return KEY_PREFIX + fingerprint;
  }
  function isFilterShape(x) {
    if (typeof x !== "object" || x === null) return false;
    const r = x;
    if (typeof r["id"] !== "string") return false;
    if (typeof r["fingerprint"] !== "string") return false;
    if (r["polarity"] !== "exclude" && r["polarity"] !== "keep") return false;
    if (typeof r["field"] !== "string") return false;
    if (typeof r["predicate"] !== "object" || r["predicate"] === null) return false;
    if (typeof r["deep"] !== "boolean") return false;
    if (typeof r["saved"] !== "boolean") return false;
    return true;
  }
  async function loadSavedFilters(fingerprint) {
    const key = keyFor(fingerprint);
    const r = await chrome.storage.sync.get(key);
    const raw = r[key];
    if (!Array.isArray(raw)) return [];
    return raw.filter(isFilterShape);
  }
  async function saveFilters(fingerprint, filters) {
    const saved = filters.map((f) => ({ ...f, saved: true }));
    await chrome.storage.sync.set({ [keyFor(fingerprint)]: saved });
  }
  async function clearSavedFilters(fingerprint) {
    await chrome.storage.sync.remove(keyFor(fingerprint));
  }

  // extension/shared/filter-io.ts
  var FILTER_EXPORT_VERSION = 1;
  function serializeExport(sets, now) {
    const env = {
      v: FILTER_EXPORT_VERSION,
      exportedAt: now,
      sets
    };
    return JSON.stringify(env, null, 2);
  }
  function parseExport(raw) {
    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch (err) {
      throw new Error(`import: not valid JSON \u2014 ${err instanceof Error ? err.message : err}`);
    }
    if (typeof parsed !== "object" || parsed === null) {
      throw new Error("import: top-level value is not an object");
    }
    const r = parsed;
    if (r["v"] !== FILTER_EXPORT_VERSION) {
      throw new Error(`import: unsupported version ${String(r["v"])}`);
    }
    if (typeof r["sets"] !== "object" || r["sets"] === null) {
      throw new Error('import: missing "sets" object');
    }
    const sets = r["sets"];
    const out = {};
    for (const [fp, value] of Object.entries(sets)) {
      if (!Array.isArray(value)) continue;
      out[fp] = value;
    }
    return {
      v: FILTER_EXPORT_VERSION,
      exportedAt: typeof r["exportedAt"] === "number" ? r["exportedAt"] : 0,
      sets: out
    };
  }

  // extension/background/spend.ts
  var DEFAULT_CAPS = { daily: 50, monthly: 1e3 };
  var STORAGE_KEY2 = "nf:spend-ledger";
  var MS_PER_DAY = 24 * 60 * 60 * 1e3;
  function epochDay(now) {
    const offsetMs = new Date(now).getTimezoneOffset() * 6e4;
    return Math.floor((now - offsetMs) / MS_PER_DAY);
  }
  function epochMonth(now) {
    const d = new Date(now);
    return d.getFullYear() * 12 + d.getMonth();
  }
  function emptyLedger(now) {
    return {
      dailyEpoch: epochDay(now),
      dailyCount: 0,
      monthlyEpoch: epochMonth(now),
      monthlyCount: 0
    };
  }
  function rollLedger(ledger, now) {
    const d = epochDay(now);
    const m = epochMonth(now);
    let next = ledger;
    if (d !== ledger.dailyEpoch) {
      next = { ...next, dailyEpoch: d, dailyCount: 0 };
    }
    if (m !== ledger.monthlyEpoch) {
      next = { ...next, monthlyEpoch: m, monthlyCount: 0 };
    }
    return next;
  }
  function checkLedger(ledger, caps, now) {
    const rolled = rollLedger(ledger, now);
    if (rolled.dailyCount >= caps.daily) {
      return { ok: false, reason: "spend-cap-reached", period: "day" };
    }
    if (rolled.monthlyCount >= caps.monthly) {
      return { ok: false, reason: "spend-cap-reached", period: "month" };
    }
    return { ok: true };
  }
  async function loadLedger(now = Date.now()) {
    const r = await chrome.storage.local.get(STORAGE_KEY2);
    const raw = r[STORAGE_KEY2];
    if (!raw || typeof raw !== "object") return emptyLedger(now);
    const obj = raw;
    if (typeof obj["dailyEpoch"] !== "number" || typeof obj["dailyCount"] !== "number" || typeof obj["monthlyEpoch"] !== "number" || typeof obj["monthlyCount"] !== "number") {
      return emptyLedger(now);
    }
    return rollLedger(
      {
        dailyEpoch: obj["dailyEpoch"],
        dailyCount: obj["dailyCount"],
        monthlyEpoch: obj["monthlyEpoch"],
        monthlyCount: obj["monthlyCount"]
      },
      now
    );
  }
  async function getSpendStatus(now = Date.now(), caps = DEFAULT_CAPS) {
    const ledger = rollLedger(await loadLedger(now), now);
    const check = checkLedger(ledger, caps, now);
    return {
      dailyUsed: ledger.dailyCount,
      dailyCap: caps.daily,
      monthlyUsed: ledger.monthlyCount,
      monthlyCap: caps.monthly,
      capReached: !check.ok,
      cappedPeriod: check.ok ? null : check.period
    };
  }

  // extension/shared/deep-prefs.ts
  var STORAGE_KEY3 = "nf:deep-warning-dismissed";
  async function isDeepWarningDismissed() {
    const r = await chrome.storage.local.get(STORAGE_KEY3);
    return r[STORAGE_KEY3] === true;
  }
  async function dismissDeepWarning() {
    await chrome.storage.local.set({ [STORAGE_KEY3]: true });
  }

  // extension/panel/components/deep-toggle.ts
  function renderDeepToggle(host, state2) {
    host.replaceChildren();
    if (!state2.enabled) return;
    const row = document.createElement("label");
    row.className = "deep-toggle";
    row.dataset["role"] = "deep-toggle-row";
    const input = document.createElement("input");
    input.type = "checkbox";
    input.dataset["input"] = "deep-scan";
    input.checked = state2.deepOn;
    input.onchange = () => state2.onToggleDeep(input.checked);
    row.appendChild(input);
    const text = document.createElement("span");
    text.className = "deep-toggle-text";
    const title = document.createElement("span");
    title.textContent = "Deep scan";
    text.appendChild(title);
    const sub = document.createElement("span");
    sub.className = "hint";
    sub.textContent = "Also checks each item\u2019s detail page (opens hidden tabs).";
    text.appendChild(sub);
    row.appendChild(text);
    host.appendChild(row);
    if (state2.modalOpen) {
      const modal = document.createElement("div");
      modal.className = "deep-modal";
      modal.dataset["role"] = "deep-warning-modal";
      modal.setAttribute("role", "dialog");
      modal.setAttribute("aria-modal", "true");
      modal.setAttribute("aria-labelledby", "deep-modal-title");
      const title2 = document.createElement("h3");
      title2.className = "deep-modal-title";
      title2.id = "deep-modal-title";
      title2.textContent = "Deep scan opens hidden tabs";
      modal.appendChild(title2);
      const body = document.createElement("p");
      body.className = "deep-modal-body";
      body.textContent = "Deep filters fetch each item\u2019s detail page in a hidden background tab. Some sites prohibit automated access in their Terms of Service \u2014 using deep scan there may violate those terms. You alone are responsible for compliance with the sites you visit.";
      modal.appendChild(body);
      const dismiss = document.createElement("button");
      dismiss.type = "button";
      dismiss.className = "deep-modal-dismiss btn btn-primary";
      dismiss.dataset["action"] = "dismiss-deep-warning";
      dismiss.textContent = "I understand";
      dismiss.onclick = () => state2.onDismissWarning();
      modal.appendChild(dismiss);
      host.appendChild(modal);
    }
  }

  // extension/panel/components/error-panel.ts
  var TITLES = {
    "missing-schema": "No filterable list on this page",
    "spend-cap": "Spend cap reached",
    "llm-error": "LLM call failed",
    "unsafe-regex": "Filter regex rejected",
    "import-error": "Filter import problem"
  };
  var HINTS = {
    "missing-schema": "Use Re-discover (above) with a one-line hint like \u201Cjob cards in the main column\u201D to teach the layout.",
    "spend-cap": "Discovery calls are paused until the cap window resets. Use saved filters in the meantime.",
    "llm-error": "Re-try; if it persists, recheck your provider key under LLM provider.",
    "unsafe-regex": "The filter regex was rejected by the safety pre-check (length or nested quantifier). Tighten the pattern.",
    "import-error": "Some filters in the file were skipped or failed to save. Re-export from the source profile and retry."
  };
  function renderErrorPanel(host, state2) {
    host.replaceChildren();
    if (state2.errors.length === 0) return;
    const h = document.createElement("h2");
    h.className = "section-h";
    h.textContent = "Heads up";
    host.appendChild(h);
    for (const err of state2.errors) {
      const row = document.createElement("div");
      row.className = `panel-error error-${err.kind}`;
      row.dataset["error"] = err.kind;
      row.setAttribute("role", "status");
      const title = document.createElement("strong");
      title.className = "panel-error-title";
      title.textContent = TITLES[err.kind];
      row.appendChild(title);
      const msg = document.createElement("p");
      msg.className = "panel-error-message";
      msg.textContent = err.message;
      row.appendChild(msg);
      const hint = document.createElement("p");
      hint.className = "panel-error-hint";
      hint.textContent = HINTS[err.kind];
      row.appendChild(hint);
      host.appendChild(row);
    }
  }

  // extension/shared/types.ts
  var MESSAGE_VERSION = 1;
  var ALL_TEXT_FIELD = "*";
  function hasShape(x) {
    return typeof x === "object" && x !== null && "t" in x && "v" in x;
  }
  function hasStringField(x, key) {
    return key in x && typeof x[key] === "string";
  }
  function isSwToPanel(x) {
    if (!hasShape(x)) return false;
    if (x.v !== MESSAGE_VERSION) return false;
    const r = x;
    switch (x.t) {
      case "pong":
      case "ack":
        return true;
      case "err":
        return hasStringField(x, "message");
      case "schema":
        return typeof r["schema"] === "object" && r["schema"] !== null;
      case "suggestions":
        return Array.isArray(r["phrases"]);
      default:
        return false;
    }
  }
  function isContentReply(x) {
    if (!hasShape(x)) return false;
    if (x.v !== MESSAGE_VERSION) return false;
    const r = x;
    switch (x.t) {
      case "ack":
        return true;
      case "err":
        return hasStringField(x, "message");
      case "state":
        return typeof r["state"] === "object" && r["state"] !== null;
      case "suggestions":
        return Array.isArray(r["phrases"]);
      default:
        return false;
    }
  }
  function isContentToPanel(x) {
    if (!hasShape(x)) return false;
    if (x.v !== MESSAGE_VERSION) return false;
    const r = x;
    switch (x.t) {
      case "itemStates":
        return Array.isArray(r["items"]);
      case "pageDetected":
        return hasStringField(x, "fingerprint") && typeof r["count"] === "number";
      case "discoverError":
        return hasStringField(x, "message");
      case "filterError":
        return hasStringField(x, "filterId") && hasStringField(x, "message");
      default:
        return false;
    }
  }
  function scriptIdFor(origin) {
    return `nf:${origin}`;
  }
  function originMatchPattern(origin) {
    return `${origin}/*`;
  }
  async function sendToSw(msg) {
    const reply = await chrome.runtime.sendMessage(msg);
    if (!isSwToPanel(reply)) {
      throw new Error(`SW returned malformed reply: ${JSON.stringify(reply)}`);
    }
    return reply;
  }
  async function sendToContent(tabId, msg) {
    const reply = await chrome.tabs.sendMessage(tabId, msg);
    if (!isContentReply(reply)) {
      throw new Error(`content returned malformed reply: ${JSON.stringify(reply)}`);
    }
    return reply;
  }

  // extension/panel/panel.ts
  var SLICE1_FILTER_ID = "panel-phrase-filter";
  var NUMERIC_FILTER_ID = "panel-numeric-filter";
  function numericFieldOf(schema) {
    if (!schema) return null;
    for (const [name, spec] of Object.entries(schema.fields)) {
      if (spec.kind === "number") return name;
    }
    return null;
  }
  var NUMERIC_DEFAULT = {
    enabled: false,
    op: "lessThan",
    value: 100
  };
  var state = {
    activeTabId: null,
    origin: null,
    enabled: false,
    schema: null,
    phrases: [],
    polarity: "exclude",
    numeric: { ...NUMERIC_DEFAULT },
    mode: "collapse",
    items: [],
    llmSettings: null,
    savedExists: false,
    spend: null,
    suggesting: false,
    suggestions: [],
    suggestError: null,
    discoverError: null,
    filterError: null,
    importError: null,
    deepOn: false,
    deepWarningDismissed: false,
    deepModalOpen: false
  };
  var ENABLEABLE_PROTOCOLS = /* @__PURE__ */ new Set(["http:", "https:"]);
  function originOf(tab) {
    if (!tab?.url) return null;
    try {
      const url = new URL(tab.url);
      if (!ENABLEABLE_PROTOCOLS.has(url.protocol)) return null;
      return url.origin;
    } catch {
      return null;
    }
  }
  async function activeContentTab() {
    const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    return tabs[0];
  }
  async function isOriginEnabled(origin) {
    const id = scriptIdFor(origin);
    const scripts = await chrome.scripting.getRegisteredContentScripts({ ids: [id] });
    return scripts.length > 0;
  }
  function buildFilters(schema, phrases, polarity, numeric) {
    if (!schema) return [];
    const out = [];
    if (phrases.length > 0 && polarity !== "off") {
      out.push({
        id: SLICE1_FILTER_ID,
        fingerprint: schema.fingerprint,
        polarity,
        field: ALL_TEXT_FIELD,
        predicate: { op: "containsAny", phrases },
        deep: false,
        saved: false
      });
    }
    const numericField = numericFieldOf(schema);
    if (numeric.enabled && numericField !== null) {
      out.push({
        id: NUMERIC_FILTER_ID,
        fingerprint: schema.fingerprint,
        polarity: "exclude",
        field: numericField,
        predicate: numeric.op === "lessThan" ? { op: "lessThan", value: numeric.value } : { op: "greaterThan", value: numeric.value },
        deep: false,
        saved: false
      });
    }
    return out;
  }
  async function pushFilters() {
    if (state.activeTabId === null) return;
    state.filterError = null;
    const filters = buildFilters(state.schema, state.phrases, state.polarity, state.numeric);
    try {
      await sendToContent(state.activeTabId, {
        t: "setFilters",
        v: MESSAGE_VERSION,
        filters
      });
    } catch (err) {
      console.error("[sieve] setFilters failed:", err);
    }
  }
  async function pushPhrases(phrases) {
    state.phrases = phrases;
    await pushFilters();
    render();
  }
  async function pushNumeric(next) {
    state.numeric = next;
    await pushFilters();
    render();
  }
  async function pushPolarity(next) {
    state.polarity = next;
    await pushFilters();
    render();
  }
  async function pushItemRestored(id, restored) {
    if (state.activeTabId === null) return;
    try {
      await sendToContent(state.activeTabId, {
        t: "setItemRestored",
        v: MESSAGE_VERSION,
        itemId: id,
        restored
      });
    } catch (err) {
      console.error("[sieve] setItemRestored failed:", err);
    }
  }
  async function pushAllRestored(restored) {
    const targets = state.items.filter((i) => restored ? i.state === "filtered" : i.state === "restored").map((i) => i.id);
    await Promise.all(targets.map((id) => pushItemRestored(id, restored)));
  }
  async function handleEnable(origin) {
    const granted = await chrome.permissions.request({
      origins: [originMatchPattern(origin)]
    });
    if (!granted) return;
    const reply = await sendToSw({ t: "enableDomain", v: MESSAGE_VERSION, origin });
    if (reply.t === "err") {
      console.error("[sieve] enableDomain failed:", reply.message);
      return;
    }
    try {
      const tab = await activeContentTab();
      if (tab?.id !== void 0 && tab.url && new URL(tab.url).origin === origin) {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id, allFrames: false },
          files: ["content.js"]
        });
      }
    } catch (err) {
      console.warn("[negative-filter] active-tab inject skipped:", err);
    }
    void refresh();
  }
  async function handleDisable(origin) {
    const reply = await sendToSw({ t: "disableDomain", v: MESSAGE_VERSION, origin });
    if (reply.t === "err") {
      console.error("[sieve] disableDomain failed:", reply.message);
      return;
    }
    await chrome.permissions.remove({ origins: [originMatchPattern(origin)] }).catch(() => void 0);
    void refresh();
  }
  async function refresh() {
    const prevOrigin = state.origin;
    const prevPhrases = state.phrases;
    const prevNumeric = state.numeric;
    const tab = await activeContentTab();
    state.activeTabId = tab?.id ?? null;
    state.origin = originOf(tab);
    state.enabled = state.origin === null ? false : await isOriginEnabled(state.origin);
    state.llmSettings = await loadLlmSettings();
    if (state.activeTabId !== null && state.enabled) {
      try {
        const reply = await sendToContent(state.activeTabId, {
          t: "getState",
          v: MESSAGE_VERSION
        });
        if (reply.t === "state") {
          state.schema = reply.state.schema;
          state.mode = reply.state.mode;
          state.items = reply.state.items;
          const phraseFilter = reply.state.filters.find(
            (f) => f.id === SLICE1_FILTER_ID && f.predicate.op === "containsAny"
          );
          if (phraseFilter && phraseFilter.predicate.op === "containsAny") {
            state.phrases = [...phraseFilter.predicate.phrases];
            state.polarity = phraseFilter.polarity === "keep" ? "keep" : "exclude";
          } else if (!(state.polarity === "off" && prevOrigin === state.origin)) {
            state.phrases = [];
          }
          const numericFilter = reply.state.filters.find((f) => f.id === NUMERIC_FILTER_ID);
          if (numericFilter && (numericFilter.predicate.op === "lessThan" || numericFilter.predicate.op === "greaterThan")) {
            state.numeric = {
              enabled: true,
              op: numericFilter.predicate.op,
              value: numericFilter.predicate.value
            };
          } else {
            state.numeric = { ...NUMERIC_DEFAULT };
          }
          const sameOrigin = prevOrigin !== null && prevOrigin === state.origin;
          const contentLostFilters = state.phrases.length === 0 && prevPhrases.length > 0;
          const contentLostNumeric = !state.numeric.enabled && prevNumeric.enabled;
          if (state.schema && sameOrigin && (contentLostFilters || contentLostNumeric)) {
            if (contentLostFilters) state.phrases = prevPhrases;
            if (contentLostNumeric) state.numeric = prevNumeric;
            void pushFilters();
          }
        } else if (reply.t === "err") {
          state.schema = null;
          state.items = [];
        }
      } catch {
        state.schema = null;
        state.items = [];
      }
    } else {
      state.schema = null;
      state.items = [];
      state.phrases = [];
    }
    try {
      state.deepWarningDismissed = await isDeepWarningDismissed();
    } catch {
      state.deepWarningDismissed = false;
    }
    try {
      state.spend = await getSpendStatus();
    } catch {
      state.spend = null;
    }
    if (state.schema) {
      try {
        const saved = await loadSavedFilters(state.schema.fingerprint);
        state.savedExists = saved.length > 0;
      } catch {
        state.savedExists = false;
      }
    } else {
      state.savedExists = false;
    }
    render();
  }
  var SUGGEST_DISPLAY_MAX = 8;
  var SUGGEST_LLM_CANDIDATES = 24;
  async function handleSuggest() {
    if (state.suggesting) return;
    if (state.activeTabId === null || state.schema === null) {
      state.suggestError = "Suggestions need a detected list on this page.";
      render();
      return;
    }
    const hasKey = state.llmSettings !== null && state.llmSettings.apiKey.trim() !== "";
    state.suggesting = true;
    state.suggestError = null;
    render();
    try {
      const reply = await sendToContent(state.activeTabId, {
        t: "getSuggestions",
        v: MESSAGE_VERSION,
        max: hasKey ? SUGGEST_LLM_CANDIDATES : SUGGEST_DISPLAY_MAX
      });
      if (reply.t === "suggestions") {
        let phrases = reply.phrases;
        if (hasKey && phrases.length > 0) {
          try {
            const curated = await sendToSw({
              t: "suggestPhrases",
              v: MESSAGE_VERSION,
              existing: state.phrases,
              candidates: phrases
            });
            if (curated.t === "suggestions" && curated.phrases.length > 0) {
              phrases = curated.phrases;
            } else if (curated.t === "err") {
              console.warn("[sieve] LLM suggestion curation failed:", curated.message);
            }
          } catch (err) {
            console.warn("[sieve] LLM suggestion curation failed:", err);
          }
        }
        state.suggestions = phrases.slice(0, SUGGEST_DISPLAY_MAX);
      } else if (reply.t === "err") {
        state.suggestError = "Suggestions need a detected list on this page.";
      }
    } catch (err) {
      state.suggestError = err instanceof Error ? err.message : String(err);
    } finally {
      state.suggesting = false;
      render();
    }
  }
  function decorateFetchError(message, pattern) {
    if (!/failed to fetch/i.test(message)) return message;
    if (pattern === null) return message;
    return `${message} \u2014 likely missing host permission for ${pattern}. Click Save in LLM settings and accept the prompt.`;
  }
  function handleAcceptSuggestion(phrase) {
    if (state.phrases.includes(phrase)) {
      state.suggestions = state.suggestions.filter((s) => s !== phrase);
      render();
      return;
    }
    state.suggestions = state.suggestions.filter((s) => s !== phrase);
    void pushPhrases([...state.phrases, phrase]);
  }
  function handleDismissSuggestions() {
    state.suggestions = [];
    state.suggestError = null;
    render();
  }
  function handleToggleDeep(next) {
    state.deepOn = next;
    if (next && !state.deepWarningDismissed) {
      state.deepModalOpen = true;
    }
    render();
  }
  async function handleDismissDeepWarning() {
    try {
      await dismissDeepWarning();
    } catch (err) {
      console.error("[sieve] dismissDeepWarning failed:", err);
    }
    state.deepWarningDismissed = true;
    state.deepModalOpen = false;
    render();
  }
  async function handleSaveFilters() {
    if (!state.schema) return;
    const filters = buildFilters(state.schema, state.phrases, state.polarity, state.numeric);
    await saveFilters(state.schema.fingerprint, filters);
    state.savedExists = true;
    render();
  }
  async function handleExportFilters() {
    const all = await chrome.storage.sync.get(null);
    const sets = {};
    for (const [k, v] of Object.entries(all)) {
      if (!k.startsWith("nf:filters:")) continue;
      if (!Array.isArray(v)) continue;
      sets[k.replace(/^nf:filters:/, "")] = v;
    }
    const json = serializeExport(sets, Date.now());
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `sieve-export-${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1e3);
  }
  async function handleImportFilters(file) {
    let env;
    try {
      const text = await file.text();
      env = parseExport(text);
    } catch (err) {
      state.importError = err instanceof Error ? err.message : String(err);
      render();
      return;
    }
    const result = { setsImported: 0, filtersImported: 0, warnings: [] };
    for (const [fp, set] of Object.entries(env.sets)) {
      const valid = set.filter(isFilterShape);
      if (valid.length < set.length) {
        result.warnings.push(`${fp}: dropped ${set.length - valid.length} malformed filter(s)`);
      }
      if (valid.length === 0) continue;
      try {
        await saveFilters(fp, valid);
        result.setsImported += 1;
        result.filtersImported += valid.length;
      } catch (err) {
        result.warnings.push(
          `${fp}: save failed \u2014 ${err instanceof Error ? err.message : String(err)}`
        );
      }
    }
    state.importError = result.warnings.length > 0 ? result.warnings.join("; ") : null;
    console.log(
      `[sieve] import: ${result.filtersImported} filter(s) across ${result.setsImported} set(s)` + (result.warnings.length > 0 ? `; ${result.warnings.length} warning(s)` : "")
    );
    void refresh();
  }
  async function handleClearSavedFilters() {
    if (!state.schema) return;
    await clearSavedFilters(state.schema.fingerprint);
    state.savedExists = false;
    render();
  }
  var PROVIDER_DEFAULT_BASE = {
    anthropic: "https://api.anthropic.com",
    openai: "https://api.openai.com"
  };
  function endpointOriginPattern(s) {
    const raw = s.baseUrl && s.baseUrl.trim() !== "" ? s.baseUrl : PROVIDER_DEFAULT_BASE[s.provider];
    try {
      return `${new URL(raw).origin}/*`;
    } catch {
      return null;
    }
  }
  async function handleSaveLlmSettings(next) {
    if (next.baseUrl !== void 0 && next.baseUrl.trim() !== "") {
      const issue = baseUrlIssue(next.baseUrl.trim());
      if (issue !== null) {
        state.discoverError = `LLM settings not saved: ${issue}.`;
        render();
        return;
      }
    }
    const pattern = endpointOriginPattern(next);
    let permissionGranted = null;
    if (pattern !== null) {
      try {
        permissionGranted = await chrome.permissions.request({ origins: [pattern] });
      } catch (err) {
        console.error("[negative-filter] LLM host permission request failed:", err);
      }
    }
    await saveLlmSettings(next);
    state.llmSettings = next;
    if (permissionGranted === false && pattern !== null) {
      state.discoverError = `Permission for ${pattern} was not granted \u2014 LLM calls will fail with "Failed to fetch". Click Save again and accept the Chrome permission prompt.`;
    } else {
      state.discoverError = null;
      state.suggestError = null;
    }
    render();
  }
  async function handleClearLlmSettings() {
    await clearLlmSettings();
    state.llmSettings = null;
    render();
  }
  function humanizeFieldName(field) {
    return field.split(/[_\-\s]+/).filter((w) => w.length > 0).map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
  }
  function render() {
    const active = state.origin !== null && state.enabled;
    for (const id of ["page-status", "filter-list", "numeric-filter", "deep-toggle", "hidden-list"]) {
      const el = document.getElementById(id);
      if (el) el.hidden = !active;
    }
    const settingsHost = document.getElementById("settings");
    if (settingsHost) {
      renderEnableButton(settingsHost, {
        origin: state.origin,
        enabled: state.enabled,
        onEnable: handleEnable,
        onDisable: handleDisable
      });
    }
    const llmHost = document.getElementById("llm-settings");
    if (llmHost) {
      renderLlmSettings(llmHost, {
        current: state.llmSettings,
        onSave: (next) => void handleSaveLlmSettings(next),
        onClear: () => void handleClearLlmSettings(),
        ...state.spend ? { spend: state.spend } : {}
      });
    }
    const pageHost = document.getElementById("page-status");
    if (pageHost) {
      renderPageStatus(pageHost, {
        schema: state.schema,
        itemCount: state.items.length,
        // Slice 3.5 + production wire-up: send rediscover to content,
        // which runs detect/distill/fetchSchema via SW and emits the
        // resulting pageDetected (or discoverError) push.
        onRediscover: (payload) => {
          void (async () => {
            if (state.activeTabId === null) return;
            try {
              await sendToContent(state.activeTabId, {
                t: "rediscover",
                v: MESSAGE_VERSION,
                ...payload.hint !== void 0 ? { hint: payload.hint } : {},
                force: payload.force
              });
            } catch (err) {
              console.error("[sieve] rediscover failed:", err);
            }
          })();
        }
      });
    }
    const filterHost = document.getElementById("filter-list");
    if (filterHost) {
      renderFilterList(filterHost, {
        enabled: state.enabled && state.schema !== null,
        phrases: state.phrases,
        polarity: state.polarity,
        onPolarityChange: (p) => void pushPolarity(p),
        onChange: (p) => void pushPhrases(p),
        onSave: () => void handleSaveFilters(),
        onClearSaved: () => void handleClearSavedFilters(),
        savedExists: state.savedExists,
        onExport: () => void handleExportFilters(),
        onImport: (f) => void handleImportFilters(f),
        onSuggest: () => void handleSuggest(),
        suggestions: state.suggestions,
        suggesting: state.suggesting,
        ...state.suggestError ? { suggestError: state.suggestError } : {},
        onAcceptSuggestion: handleAcceptSuggestion,
        onDismissSuggestions: handleDismissSuggestions
      });
    }
    const errors = [];
    if (state.enabled && state.schema === null) {
      errors.push({
        kind: "missing-schema",
        message: "We didn't detect a list on this page yet."
      });
    }
    if (state.spend?.capReached) {
      errors.push({
        kind: "spend-cap",
        message: state.spend.cappedPeriod === "day" ? `${state.spend.dailyUsed}/${state.spend.dailyCap} calls used today.` : `${state.spend.monthlyUsed}/${state.spend.monthlyCap} calls used this month.`
      });
    }
    if (state.suggestError) {
      errors.push({ kind: "llm-error", message: state.suggestError });
    }
    if (state.discoverError) {
      errors.push({ kind: "llm-error", message: state.discoverError });
    }
    if (state.filterError) {
      errors.push({ kind: "unsafe-regex", message: state.filterError });
    }
    if (state.importError) {
      errors.push({ kind: "import-error", message: state.importError });
    }
    const errorHost = document.getElementById("error-panel");
    if (errorHost) renderErrorPanel(errorHost, { errors });
    const numericHost = document.getElementById("numeric-filter");
    if (numericHost) {
      const numericField = numericFieldOf(state.schema);
      renderNumericFilter(numericHost, {
        enabled: state.enabled && numericField !== null,
        current: state.numeric,
        label: humanizeFieldName(numericField ?? "value"),
        onChange: (next) => void pushNumeric(next)
      });
    }
    const deepHost = document.getElementById("deep-toggle");
    if (deepHost) {
      renderDeepToggle(deepHost, {
        enabled: state.enabled && state.schema !== null,
        deepOn: state.deepOn,
        warningDismissed: state.deepWarningDismissed,
        modalOpen: state.deepModalOpen,
        onToggleDeep: handleToggleDeep,
        onDismissWarning: () => void handleDismissDeepWarning()
      });
    }
    const hiddenHost = document.getElementById("hidden-list");
    if (hiddenHost) {
      renderHiddenList(hiddenHost, {
        items: state.items,
        onSetItem: (id, restored) => void pushItemRestored(id, restored),
        onSetAll: (restored) => void pushAllRestored(restored)
      });
    }
  }
  chrome.runtime.onMessage.addListener((raw, sender, _sendResponse) => {
    if (!isContentToPanel(raw)) return false;
    const senderTabId = sender.tab?.id;
    if (senderTabId !== void 0 && senderTabId !== state.activeTabId) return false;
    switch (raw.t) {
      case "itemStates":
        state.items = raw.items;
        render();
        break;
      case "pageDetected":
        state.discoverError = null;
        void refresh();
        break;
      case "discoverError": {
        const pattern = state.llmSettings ? endpointOriginPattern(state.llmSettings) : null;
        state.discoverError = decorateFetchError(raw.message, pattern);
        render();
        break;
      }
      case "filterError":
        state.filterError = `Filter "${raw.filterId}" was skipped: ${raw.message}`;
        render();
        break;
    }
    return false;
  });
  void refresh();
  chrome.tabs.onActivated.addListener(() => {
    void refresh();
  });
  chrome.tabs.onUpdated.addListener((id, info) => {
    if (id !== state.activeTabId) return;
    if (info.status === "complete" || info.url !== void 0) {
      void refresh();
    }
  });
})();
//# sourceMappingURL=panel.js.map
