// extension/shared/types.ts
var MESSAGE_VERSION = 1;
function hasShape(x) {
  return typeof x === "object" && x !== null && "t" in x && "v" in x;
}
function hasStringField(x, key) {
  return key in x && typeof x[key] === "string";
}
function isPanelMsg(x) {
  if (!hasShape(x)) return false;
  if (x.v !== MESSAGE_VERSION) return false;
  const r = x;
  switch (x.t) {
    case "ping":
      return true;
    case "enableDomain":
    case "disableDomain":
      return hasStringField(x, "origin");
    case "discoverSchema":
      return hasStringField(x, "fingerprint") && hasStringField(x, "distilled") && (r["layout"] === "list" || r["layout"] === "carousel" || r["layout"] === "grid");
    case "suggestPhrases":
      return Array.isArray(r["existing"]) && Array.isArray(r["candidates"]);
    default:
      return false;
  }
}
function isContentToPanel(x) {
  if (!hasShape(x)) return false;
  if (x.v !== MESSAGE_VERSION) return false;
  const r = x;
  switch (x.t) {
    case "itemStates":
      return Array.isArray(r["items"]);
    case "pageDetected":
      return hasStringField(x, "fingerprint") && typeof r["count"] === "number";
    case "discoverError":
      return hasStringField(x, "message");
    default:
      return false;
  }
}
function scriptIdFor(origin) {
  return `nf:${origin}`;
}
function originMatchPattern(origin) {
  return `${origin}/*`;
}

// extension/background/spend.ts
var DEFAULT_CAPS = { daily: 50, monthly: 1e3 };
var STORAGE_KEY = "nf:spend-ledger";
var MS_PER_DAY = 24 * 60 * 60 * 1e3;
function epochDay(now) {
  return Math.floor(now / MS_PER_DAY);
}
function epochMonth(now) {
  const d = new Date(now);
  return d.getUTCFullYear() * 12 + d.getUTCMonth();
}
function emptyLedger(now) {
  return {
    dailyEpoch: epochDay(now),
    dailyCount: 0,
    monthlyEpoch: epochMonth(now),
    monthlyCount: 0
  };
}
function rollLedger(ledger, now) {
  const d = epochDay(now);
  const m = epochMonth(now);
  let next = ledger;
  if (d !== ledger.dailyEpoch) {
    next = { ...next, dailyEpoch: d, dailyCount: 0 };
  }
  if (m !== ledger.monthlyEpoch) {
    next = { ...next, monthlyEpoch: m, monthlyCount: 0 };
  }
  return next;
}
function checkLedger(ledger, caps, now) {
  const rolled = rollLedger(ledger, now);
  if (rolled.dailyCount >= caps.daily) {
    return { ok: false, reason: "spend-cap-reached", period: "day" };
  }
  if (rolled.monthlyCount >= caps.monthly) {
    return { ok: false, reason: "spend-cap-reached", period: "month" };
  }
  return { ok: true };
}
function incrementLedger(ledger, now) {
  const rolled = rollLedger(ledger, now);
  return {
    ...rolled,
    dailyCount: rolled.dailyCount + 1,
    monthlyCount: rolled.monthlyCount + 1
  };
}
async function loadLedger(now = Date.now()) {
  const r = await chrome.storage.local.get(STORAGE_KEY);
  const raw = r[STORAGE_KEY];
  if (!raw || typeof raw !== "object") return emptyLedger(now);
  const obj = raw;
  if (typeof obj["dailyEpoch"] !== "number" || typeof obj["dailyCount"] !== "number" || typeof obj["monthlyEpoch"] !== "number" || typeof obj["monthlyCount"] !== "number") {
    return emptyLedger(now);
  }
  return rollLedger(
    {
      dailyEpoch: obj["dailyEpoch"],
      dailyCount: obj["dailyCount"],
      monthlyEpoch: obj["monthlyEpoch"],
      monthlyCount: obj["monthlyCount"]
    },
    now
  );
}
async function saveLedger(ledger) {
  await chrome.storage.local.set({ [STORAGE_KEY]: ledger });
}
function chromeStorageSpendChecker(caps = DEFAULT_CAPS) {
  return {
    async canSpend(now) {
      const ledger = await loadLedger(now);
      return checkLedger(ledger, caps, now);
    },
    async recordSpend(now) {
      const ledger = await loadLedger(now);
      await saveLedger(incrementLedger(ledger, now));
    }
  };
}
var SpendCapError = class extends Error {
  reason = "spend-cap-reached";
  period;
  constructor(period) {
    super(`spend-cap-reached:${period}`);
    this.name = "SpendCapError";
    this.period = period;
  }
};

// extension/background/llm.ts
var SchemaParseError = class extends Error {
  reason;
  raw;
  constructor(reason, raw) {
    super(`SchemaParseError: ${reason}`);
    this.name = "SchemaParseError";
    this.reason = reason;
    this.raw = raw === void 0 ? void 0 : raw.slice(0, 500);
  }
};
var DEFAULT_MODEL = {
  anthropic: "claude-sonnet-4-5",
  openai: "gpt-4o"
};
var VALID_LAYOUTS = /* @__PURE__ */ new Set(["list", "carousel", "grid"]);
var VALID_FIELD_KINDS = /* @__PURE__ */ new Set([
  "text",
  "number",
  "date",
  "enum",
  "flag"
]);
function buildPrompt(distilled, hint) {
  const hintLine = hint && hint.trim() !== "" ? `
User hint: ${hint.trim()}
` : "";
  return `You are inspecting the structure of a web page to write CSS selectors that pick out a list of similar items.

Output ONLY a single JSON object \u2014 no prose, no markdown fences \u2014 matching this shape exactly:

{
  "layout": "list" | "carousel" | "grid",
  "itemSetSelector": <CSS selector for the outer container>,
  "itemSelector": <CSS selector for one repeating item within the container>,
  "fields": {
    "<fieldName>": { "kind": "text"|"number"|"date"|"enum"|"flag", "selector": <CSS selector inside one item> }
  },
  "detailLinkSelector"?: <CSS selector for the anchor \u2192 detail page>,
  "detailFieldSelectors"?: { "<fieldName>": <CSS selector on the detail page> }
}

The skeleton below has had text content redacted (\`\u2026\`) and per-item attributes (data-*, ids, styles) stripped. Class names and structure are intact \u2014 base your selectors on those.

Skeleton:
${distilled}
${hintLine}`;
}
function extractJsonObject(text) {
  const trimmed = text.trim();
  const fence = trimmed.match(/^```(?:json)?\s*([\s\S]*?)\s*```\s*$/);
  if (fence?.[1]) return fence[1].trim();
  const first = trimmed.indexOf("{");
  const last = trimmed.lastIndexOf("}");
  if (first >= 0 && last > first) return trimmed.slice(first, last + 1);
  return trimmed;
}
function isNonEmptyString(x) {
  return typeof x === "string" && x.trim() !== "";
}
function isFieldSpec(x) {
  if (typeof x !== "object" || x === null) return false;
  const r = x;
  if (!isNonEmptyString(r["selector"])) return false;
  if (typeof r["kind"] !== "string" || !VALID_FIELD_KINDS.has(r["kind"])) {
    return false;
  }
  if ("deep" in r && r["deep"] !== void 0 && typeof r["deep"] !== "boolean") {
    return false;
  }
  return true;
}
function isStringRecord(x) {
  if (typeof x !== "object" || x === null) return false;
  for (const v of Object.values(x)) {
    if (typeof v !== "string") return false;
  }
  return true;
}
function validateSchemaShape(obj, fingerprint, now, raw) {
  if (typeof obj !== "object" || obj === null) {
    throw new SchemaParseError("response is not a JSON object", raw);
  }
  const r = obj;
  if (typeof r["layout"] !== "string" || !VALID_LAYOUTS.has(r["layout"])) {
    throw new SchemaParseError(`invalid layout: ${JSON.stringify(r["layout"])}`, raw);
  }
  if (!isNonEmptyString(r["itemSetSelector"])) {
    throw new SchemaParseError("itemSetSelector missing or empty", raw);
  }
  if (!isNonEmptyString(r["itemSelector"])) {
    throw new SchemaParseError("itemSelector missing or empty", raw);
  }
  if (typeof r["fields"] !== "object" || r["fields"] === null) {
    throw new SchemaParseError("fields missing or not an object", raw);
  }
  const fields = {};
  for (const [name, spec] of Object.entries(r["fields"])) {
    if (!isFieldSpec(spec)) {
      throw new SchemaParseError(`field "${name}" has invalid FieldSpec`, raw);
    }
    fields[name] = spec;
  }
  if (Object.keys(fields).length === 0) {
    throw new SchemaParseError("fields object is empty", raw);
  }
  const schema = {
    fingerprint,
    layout: r["layout"],
    itemSetSelector: r["itemSetSelector"],
    itemSelector: r["itemSelector"],
    fields,
    source: "llm",
    discoveredAt: now
  };
  if (isNonEmptyString(r["detailLinkSelector"])) {
    schema.detailLinkSelector = r["detailLinkSelector"];
  }
  if (isStringRecord(r["detailFieldSelectors"])) {
    schema.detailFieldSelectors = r["detailFieldSelectors"];
  }
  return schema;
}
function joinUrl(base, path) {
  return `${base.replace(/\/+$/, "")}/${path.replace(/^\/+/, "")}`;
}
async function callAnthropic(prompt, opts, fetcher) {
  const base = opts.baseUrl ?? "https://api.anthropic.com";
  const res = await fetcher(joinUrl(base, "/v1/messages"), {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": opts.apiKey,
      authorization: `Bearer ${opts.apiKey}`,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true"
    },
    body: JSON.stringify({
      model: opts.model ?? DEFAULT_MODEL.anthropic,
      max_tokens: 1024,
      messages: [{ role: "user", content: prompt }]
    })
  });
  if (!res.ok) {
    const body = await res.text().catch(() => "");
    throw new SchemaParseError(`Anthropic ${res.status}: ${body.slice(0, 200)}`, body);
  }
  const json = await res.json();
  const text = (json.content ?? []).filter((b) => b.type === "text" && typeof b.text === "string").map((b) => b.text).join("");
  if (text === "") {
    throw new SchemaParseError("Anthropic response had no text content", JSON.stringify(json));
  }
  return { text };
}
async function callOpenAI(prompt, opts, fetcher) {
  const base = opts.baseUrl ?? "https://api.openai.com";
  const res = await fetcher(joinUrl(base, "/v1/chat/completions"), {
    method: "POST",
    headers: {
      "content-type": "application/json",
      authorization: `Bearer ${opts.apiKey}`
    },
    body: JSON.stringify({
      model: opts.model ?? DEFAULT_MODEL.openai,
      messages: [{ role: "user", content: prompt }]
    })
  });
  if (!res.ok) {
    const body = await res.text().catch(() => "");
    throw new SchemaParseError(`OpenAI ${res.status}: ${body.slice(0, 200)}`, body);
  }
  const json = await res.json();
  const text = json.choices?.[0]?.message?.content ?? "";
  if (text === "") {
    throw new SchemaParseError("OpenAI response had no content", JSON.stringify(json));
  }
  return { text };
}
async function discoverSchema(distilled, opts) {
  const fetcher = opts.fetcher ?? globalThis.fetch;
  const now = opts.now ?? Date.now;
  if (opts.spend) {
    const check = await opts.spend.canSpend(now());
    if (!check.ok) throw new SpendCapError(check.period);
  }
  const prompt = buildPrompt(distilled, opts.hint);
  const result = opts.provider === "anthropic" ? await callAnthropic(prompt, opts, fetcher) : await callOpenAI(prompt, opts, fetcher);
  const jsonText = extractJsonObject(result.text);
  let parsed;
  try {
    parsed = JSON.parse(jsonText);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    throw new SchemaParseError(`response is not valid JSON: ${msg}`, result.text);
  }
  const schema = validateSchemaShape(parsed, opts.fingerprint, now(), result.text);
  if (opts.spend) await opts.spend.recordSpend(now());
  return schema;
}
var SUGGEST_PROMPT_HEADER = `You curate filter phrases for a browser extension that hides items from a list the user is browsing. The candidates below are the most frequently recurring words and word pairs across the list's items, extracted locally.

Output ONLY a single JSON object with this exact shape:
{ "suggestions": ["phrase one", "phrase two", ...] }

Pick up to 8 candidates that read as meaningful, filterable topics, brands, or categories \u2014 drop UI chrome, generic verbs, and fragments. Keep each phrase exactly as written in the candidate list. Order from most to least useful. Don't repeat anything in "existing".`;
function buildSuggestPrompt(opts) {
  const existing = opts.existing.length === 0 ? "(none yet)" : opts.existing.join(", ");
  return `${SUGGEST_PROMPT_HEADER}

Candidates: ${opts.candidates.join(", ")}
Existing phrases: ${existing}`;
}
function parseSuggestions(raw) {
  const obj = JSON.parse(extractJsonObject(raw));
  if (!Array.isArray(obj.suggestions)) {
    throw new SchemaParseError("suggestions field missing or not an array", raw);
  }
  const out = [];
  for (const v of obj.suggestions) {
    if (typeof v !== "string") continue;
    const trimmed = v.trim();
    if (trimmed.length > 0 && trimmed.length <= 80) out.push(trimmed);
  }
  return out;
}
async function suggestPhrases(opts) {
  const fetcher = opts.fetcher ?? globalThis.fetch;
  const now = opts.now ?? Date.now;
  if (opts.spend) {
    const check = await opts.spend.canSpend(now());
    if (!check.ok) throw new SpendCapError(check.period);
  }
  const prompt = buildSuggestPrompt(opts);
  const callOpts = {
    provider: opts.provider,
    apiKey: opts.apiKey,
    // Suggestions are fingerprint-agnostic. We pass a synthetic value
    // so we can reuse the provider plumbing without forking it.
    fingerprint: "suggest",
    ...opts.model !== void 0 ? { model: opts.model } : {},
    ...opts.baseUrl !== void 0 ? { baseUrl: opts.baseUrl } : {},
    fetcher
  };
  const result = opts.provider === "anthropic" ? await callAnthropic(prompt, callOpts, fetcher) : await callOpenAI(prompt, callOpts, fetcher);
  let suggestions;
  try {
    suggestions = parseSuggestions(result.text);
  } catch (err) {
    if (err instanceof SchemaParseError) throw err;
    const msg = err instanceof Error ? err.message : String(err);
    throw new SchemaParseError(`suggestions response is not valid JSON: ${msg}`, result.text);
  }
  if (opts.spend) await opts.spend.recordSpend(now());
  const seen = new Set(opts.existing.map((p) => p.toLowerCase()));
  const out = [];
  for (const s of suggestions) {
    const k = s.toLowerCase();
    if (seen.has(k)) continue;
    seen.add(k);
    out.push(s);
  }
  return out;
}

// extension/background/cache.ts
var STORAGE_KEY_PREFIX = "nf:schema:";
var storageKey = (fingerprint) => `${STORAGE_KEY_PREFIX}${fingerprint}`;
function chromeStorageSchemaCache() {
  return {
    async get(fingerprint) {
      const key = storageKey(fingerprint);
      const result = await chrome.storage.local.get([key]);
      const value = result[key];
      return value && typeof value === "object" ? value : null;
    },
    async set(fingerprint, schema) {
      await chrome.storage.local.set({ [storageKey(fingerprint)]: schema });
    }
  };
}
async function getOrDiscover(req, deps) {
  if (!req.force) {
    const cached = await deps.cache.get(req.fingerprint);
    if (cached) return cached;
  }
  const settings = await deps.loadSettings();
  const llm = deps.llm ?? discoverSchema;
  const llmOpts = {
    provider: settings.provider,
    apiKey: settings.apiKey,
    fingerprint: req.fingerprint
  };
  if (settings.model !== void 0) llmOpts.model = settings.model;
  if (settings.baseUrl !== void 0) llmOpts.baseUrl = settings.baseUrl;
  if (req.hint !== void 0) llmOpts.hint = req.hint;
  if (deps.fetcher !== void 0) llmOpts.fetcher = deps.fetcher;
  if (deps.now !== void 0) llmOpts.now = deps.now;
  if (deps.spend !== void 0) llmOpts.spend = deps.spend;
  const schema = await llm(req.distilled, llmOpts);
  await deps.cache.set(req.fingerprint, schema);
  return schema;
}

// extension/shared/settings.ts
var STORAGE_KEY2 = "nf:llm-settings";
async function loadLlmSettings() {
  const r = await chrome.storage.local.get([STORAGE_KEY2]);
  const v = r[STORAGE_KEY2];
  if (!v || typeof v !== "object") return null;
  const obj = v;
  if (obj["provider"] !== "anthropic" && obj["provider"] !== "openai") return null;
  if (typeof obj["apiKey"] !== "string") return null;
  const out = {
    provider: obj["provider"],
    apiKey: obj["apiKey"]
  };
  if (typeof obj["model"] === "string" && obj["model"].trim() !== "") {
    out.model = obj["model"];
  }
  if (typeof obj["baseUrl"] === "string" && obj["baseUrl"].trim() !== "") {
    out.baseUrl = obj["baseUrl"].trim();
  }
  return out;
}

// extension/background/sw.ts
var CONTENT_SCRIPT_FILE = "content.js";
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => void 0);
void chrome.action.setBadgeBackgroundColor({ color: "#059669" }).catch(() => void 0);
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.url === void 0) return;
  void chrome.tabs.sendMessage(tabId, { t: "spaNavigated", v: MESSAGE_VERSION, url: changeInfo.url }).catch(() => void 0);
});
async function registerForOrigin(origin) {
  const id = scriptIdFor(origin);
  const existing = await chrome.scripting.getRegisteredContentScripts({ ids: [id] });
  if (existing.length > 0) return;
  await chrome.scripting.registerContentScripts([
    {
      id,
      matches: [originMatchPattern(origin)],
      js: [CONTENT_SCRIPT_FILE],
      runAt: "document_idle",
      world: "ISOLATED"
    }
  ]);
}
async function unregisterForOrigin(origin) {
  const id = scriptIdFor(origin);
  const existing = await chrome.scripting.getRegisteredContentScripts({ ids: [id] });
  if (existing.length === 0) return;
  await chrome.scripting.unregisterContentScripts({ ids: [id] });
}
async function handle(msg) {
  switch (msg.t) {
    case "ping":
      return { t: "pong", v: MESSAGE_VERSION };
    case "enableDomain":
      await registerForOrigin(msg.origin);
      return { t: "ack", v: MESSAGE_VERSION };
    case "disableDomain":
      await unregisterForOrigin(msg.origin);
      return { t: "ack", v: MESSAGE_VERSION };
    case "discoverSchema": {
      const settings = await loadLlmSettings();
      if (!settings || settings.apiKey.trim() === "") {
        return {
          t: "err",
          v: MESSAGE_VERSION,
          message: 'no-api-key: add a provider key in the panel under "LLM provider".'
        };
      }
      const req = {
        fingerprint: msg.fingerprint,
        distilled: msg.distilled
      };
      if (msg.hint !== void 0) req.hint = msg.hint;
      if (msg.force) req.force = true;
      try {
        const schema = await getOrDiscover(req, {
          cache: chromeStorageSchemaCache(),
          // Enforced inside discoverSchema: canSpend BEFORE the provider
          // fetch (blocked call costs zero network), recordSpend only after
          // a validated schema. Cache hits never touch the meter.
          spend: chromeStorageSpendChecker(),
          loadSettings: async () => {
            const s = {
              provider: settings.provider,
              apiKey: settings.apiKey
            };
            if (settings.model !== void 0) s.model = settings.model;
            if (settings.baseUrl !== void 0) s.baseUrl = settings.baseUrl;
            return s;
          }
        });
        return { t: "schema", v: MESSAGE_VERSION, schema };
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        return { t: "err", v: MESSAGE_VERSION, message };
      }
    }
    case "suggestPhrases": {
      const settings = await loadLlmSettings();
      if (!settings || settings.apiKey.trim() === "") {
        return {
          t: "err",
          v: MESSAGE_VERSION,
          message: 'no-api-key: add a provider key in the panel under "LLM provider".'
        };
      }
      try {
        const phrases = await suggestPhrases({
          provider: settings.provider,
          apiKey: settings.apiKey,
          existing: msg.existing,
          candidates: msg.candidates,
          ...settings.model !== void 0 ? { model: settings.model } : {},
          ...settings.baseUrl !== void 0 ? { baseUrl: settings.baseUrl } : {},
          spend: chromeStorageSpendChecker()
        });
        return { t: "suggestions", v: MESSAGE_VERSION, phrases };
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        return { t: "err", v: MESSAGE_VERSION, message };
      }
    }
  }
}
chrome.runtime.onMessage.addListener((raw, _sender, sendResponse) => {
  if (isContentToPanel(raw) && raw.t === "itemStates") {
    const tabId = _sender.tab?.id;
    if (tabId !== void 0) {
      const hidden = raw.items.filter((i) => i.state === "filtered").length;
      void chrome.action.setBadgeText({ tabId, text: hidden > 0 ? String(hidden) : "" }).catch(() => void 0);
    }
    return false;
  }
  if (!isPanelMsg(raw)) {
    return false;
  }
  handle(raw).then((reply) => sendResponse(reply)).catch((err) => {
    const message = err instanceof Error ? err.message : String(err);
    const reply = { t: "err", v: MESSAGE_VERSION, message };
    sendResponse(reply);
  });
  return true;
});
//# sourceMappingURL=background.js.map
